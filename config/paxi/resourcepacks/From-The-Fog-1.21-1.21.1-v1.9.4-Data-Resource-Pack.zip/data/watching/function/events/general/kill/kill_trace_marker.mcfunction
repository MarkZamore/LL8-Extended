forceload remove ~ ~
kill @s