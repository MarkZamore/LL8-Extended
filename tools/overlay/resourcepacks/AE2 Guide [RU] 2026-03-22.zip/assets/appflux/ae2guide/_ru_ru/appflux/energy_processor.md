---
navigation:
  parent: appflux/appflux-index.md
  title: Энергетический процессор
  icon: appflux:energy_processor
categories:
- flux materials
item_ids:
- appflux:energy_processor
- appflux:printed_energy_processor
- appflux:energy_processor_press
---

# Энергетический процессор

<Row>
<ItemImage id="appflux:energy_processor" scale="4"></ItemImage>
<ItemImage id="appflux:energy_processor_press" scale="4"></ItemImage>
<ItemImage id="appflux:printed_energy_processor" scale="4"></ItemImage>
</Row>

Энергетический процессор управляет потоками энергии в МЭ-системе. Все энергетические устройства
Applied Flux требуют энергетический процессор для маршрутизации энергии.
