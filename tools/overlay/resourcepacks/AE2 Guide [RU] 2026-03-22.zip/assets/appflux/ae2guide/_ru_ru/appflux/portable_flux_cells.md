---
navigation:
  parent: appflux/appflux-index.md
  title: Переносные ячейки Flux
  icon: appflux:fe_1k_portable_cell
categories:
- flux cells
item_ids:
- appflux:fe_1k_portable_cell
- appflux:fe_4k_portable_cell
- appflux:fe_16k_portable_cell
- appflux:fe_64k_portable_cell
- appflux:fe_256k_portable_cell
- appflux:fe_1m_portable_cell
- appflux:fe_4m_portable_cell
- appflux:fe_16m_portable_cell
- appflux:fe_64m_portable_cell
- appflux:fe_256m_portable_cell
---

# Переносные ячейки Flux

<Column>
  <Row>
    <ItemImage id="appflux:fe_1k_portable_cell" scale="4" />
    <ItemImage id="appflux:fe_4k_portable_cell" scale="4" />
    <ItemImage id="appflux:fe_16k_portable_cell" scale="4" />
    <ItemImage id="appflux:fe_64k_portable_cell" scale="4" />
    <ItemImage id="appflux:fe_256k_portable_cell" scale="4" />
  </Row>
  <Row>
    <ItemImage id="appflux:fe_1m_portable_cell" scale="4" />
    <ItemImage id="appflux:fe_4m_portable_cell" scale="4" />
    <ItemImage id="appflux:fe_16m_portable_cell" scale="4" />
    <ItemImage id="appflux:fe_64m_portable_cell" scale="4" />
    <ItemImage id="appflux:fe_256m_portable_cell" scale="4" />
  </Row>
</Column>

Переносные ячейки FE имеют вчетверо меньшую ёмкость по сравнению с обычными [ячейками FE](./flux_cells.md).

Однако в переносные ячейки FE можно установить <ItemLink id="appflux:induction_card"/> — тогда они
будут автоматически заряжать предметы в вашем инвентаре.
