---
navigation:
  parent: appflux/appflux-index.md
  title: Кристалл красного камня
  icon: appflux:redstone_crystal
categories:
- flux materials
item_ids:
- appflux:redstone_crystal
- appflux:charged_redstone
- appflux:charged_redstone_block
---

# Кристалл красного камня

<Row>
<ItemImage id="appflux:redstone_crystal" scale="4"></ItemImage>
<ItemImage id="appflux:charged_redstone" scale="4"></ItemImage>
</Row>
<Row>
<BlockImage id="appflux:charged_redstone_block" scale="4"></BlockImage>
</Row>

*«Пш-шш!!»*

Красный камень — хороший проводник для хранения энергии, но в рассыпчатом виде его не удержать в ячейке.

В сочетании с флюисовым кристаллом и светокамнем блок красного камня кристаллизуется в кристаллы
красного камня. Они хранят огромное количество энергии, занимая при этом совсем мало места.
