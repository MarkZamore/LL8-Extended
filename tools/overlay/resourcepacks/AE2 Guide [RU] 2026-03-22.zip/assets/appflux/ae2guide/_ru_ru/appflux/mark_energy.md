---
navigation:
  parent: appflux/appflux-index.md
  title: Отметить FE
categories:
- flux tricks
---

# Как отметить FE в слоте конфигурации

Если нужно выводить энергию через <ItemLink id="ae2:export_bus"/>, необходимо отметить FE в слоте
конфигурации шины.

Кликните правой кнопкой мыши на слот с любым контейнером для энергии, чтобы отметить FE.

![FE_MARK](../pic/fe_mark.png)
