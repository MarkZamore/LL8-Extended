---
navigation:
  parent: appflux/appflux-index.md
  title: Аксессор Flux
  icon: appflux:flux_accessor
categories:
- flux accessor
item_ids:
- appflux:flux_accessor
- appflux:part_flux_accessor
---

# Аксессор Flux

<Row>
<BlockImage id="appflux:flux_accessor" scale="8"></BlockImage>
<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/flux_accessor.snbt"></ImportStructure>
</GameScene>
</Row>

Аксессор Flux принимает и отдаёт энергию, хранящуюся в МЭ-сети. По умолчанию ограничений на
скорость ввода/вывода нет — это можно изменить в конфиге Appflux.

Аксессор работает в двух режимах: быстром и обычном. В **быстром режиме** энергия выдаётся каждый
тик — это может вызывать лаги при интенсивном использовании. В **обычном режиме** выдача энергии
зависит от запаса у потребителя, что не создаёт проблем с производительностью.

* Примечание: «энергия» здесь — FE, хранящееся в [ячейках FE](./flux_cells.md), а не энергия
в [ячейках энергии AE2](ae2:items-blocks-machines/energy_cells.md).
