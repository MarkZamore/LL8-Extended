---
navigation:
    title: Applied Flux
    position: 70
---

# Храните энергию в ячейках!

Applied Flux позволяет управлять энергетической системой через AE.

## Ячейки Flux
<CategoryIndex category="flux cells"></CategoryIndex>

## Материалы
<CategoryIndex category="flux materials"></CategoryIndex>

## Аксессор Flux
<CategoryIndex category="flux accessor"></CategoryIndex>

## Хитрости
<CategoryIndex category="flux tricks"></CategoryIndex>
