---
navigation:
  parent: ae2wtlib/ae2wtlib-index.md
  title: Беспроводной терминал крафта
  icon: ae2:wireless_crafting_terminal
  position: 100
categories:
- ae2wtlib
item_ids:
  - ae2:wireless_crafting_terminal
---

# Беспроводной терминал крафта

<ItemImage id="ae2:wireless_crafting_terminal" scale="3" />

<ItemLink id="ae2:wireless_crafting_terminal" /> — [беспроводная](wireless_terminals.md) версия
<ItemLink id="ae2:crafting_terminal" />. AE2WTLib добавляет автоматическое
[пополнение](restock.md) из МЭ-сети и позволяет функции «взять блок» брать предметы из сети.
При наличии <ItemLink id="ae2wtlib:magnet_card" /> также работает как магнит.

Можно объединить с другими [беспроводными терминалами](wireless_terminals.md) в
<ItemLink id="ae2wtlib:wireless_universal_terminal" />.

AE2WTLib расширяет функцию `Pick Block` (взять блок) Minecraft — предмет будет браться из сети,
если его нет в инвентаре (и будет помещаться в сеть, если текущий слот заполнен).

## Интерфейс

См. [Терминалы](ae2:items-blocks-machines/terminals.md)

## Улучшения

<ItemLink id="ae2:wireless_crafting_terminal" /> поддерживает следующие
[улучшения](ae2:items-blocks-machines/upgrade_cards.md):

*   <ItemLink id="ae2:energy_card" /> — увеличивает ёмкость батареи
*   <ItemLink id="ae2wtlib:quantum_bridge_card" /> — снимает ограничение дальности, работает даже
    через измерения и автоматически заряжает терминал из МЭ-сети
*   <ItemLink id="ae2wtlib:magnet_card" /> — добавляет функцию магнита

## Рецепт

<RecipeFor id="ae2:wireless_crafting_terminal" />
