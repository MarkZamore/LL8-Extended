---
navigation:
  parent: ae2wtlib/ae2wtlib-index.md
  title: Карта квантового моста
  icon: ae2wtlib:quantum_bridge_card
  position: 210
categories:
- ae2wtlib
item_ids:
- ae2wtlib:quantum_bridge_card
---

# Карта квантового моста

<ItemImage id="ae2wtlib:quantum_bridge_card" scale="3" />

Карта квантового моста — [карта улучшений](ae2:items-blocks-machines/upgrade_cards.md) для
[беспроводных терминалов AE2WTLib](wireless_terminals.md). Позволяет привязать
[беспроводной терминал](wireless_terminals.md) к
[квантовому мосту](ae2:items-blocks-machines/quantum_bridge.md).

Вставьте карту квантового моста и <ItemLink id="ae2:quantum_entangled_singularity" /> в беспроводной
терминал, а вторую сингулярность из пары — в
[квантовый мост](ae2:items-blocks-machines/quantum_bridge.md), подключённый к вашей сети.

После этого беспроводной терминал получит квантовую связь: он будет работать из любого места, даже
через измерения (при условии, что чанки с сетью загружены, например через
<ItemLink id="ae2:spatial_anchor" />), и автоматически заряжаться из сети.
(убедитесь, что в сети достаточно
[запаса энергии](ae2:items-blocks-machines/energy_cells.md))

## Рецепт

<RecipeFor id="ae2wtlib:quantum_bridge_card" />
