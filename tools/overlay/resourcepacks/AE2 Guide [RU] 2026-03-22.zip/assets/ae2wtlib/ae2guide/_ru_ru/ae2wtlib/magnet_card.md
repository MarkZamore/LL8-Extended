---
navigation:
  parent: ae2wtlib/ae2wtlib-index.md
  title: Карта магнита
  icon: ae2wtlib:magnet_card
  position: 220
categories:
- ae2wtlib
item_ids:
- ae2wtlib:magnet_card
---

# Карта магнита

<ItemImage id="ae2wtlib:magnet_card" scale="3" />

<ItemLink id="ae2wtlib:magnet_card" /> — [карта улучшений](ae2:items-blocks-machines/upgrade_cards.md)
для <ItemLink id="ae2:wireless_crafting_terminal" />, добавляющая функцию магнита. Включается и
отключается в интерфейсе терминала или через назначенную клавишу.

Карта магнита делает две вещи:

1. Подбирает предметы в увеличенном радиусе (настраивается, по умолчанию — 16 блоков)
2. Помещает подобранные предметы в МЭ-систему вместо инвентаря

Обе функции переключаются независимо друг от друга и имеют отдельные фильтры (фильтр подбора
и фильтр вставки). Каждый фильтр может работать в режиме белого или чёрного списка.

## Рецепт

<RecipeFor id="ae2wtlib:magnet_card" />
