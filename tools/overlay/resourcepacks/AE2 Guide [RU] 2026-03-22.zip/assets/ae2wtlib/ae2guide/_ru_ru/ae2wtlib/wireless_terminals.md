---
navigation:
  parent: ae2wtlib/ae2wtlib-index.md
  title: Беспроводные терминалы AE2WTLib
  icon: ae2wtlib:wireless_universal_terminal
  position: 10
categories:
- ae2wtlib
item_ids:
  - ae2wtlib:wireless_pattern_encoding_terminal
  - ae2wtlib:wireless_pattern_access_terminal
---

# Беспроводные терминалы

<ItemGrid>
  <ItemIcon id="ae2wtlib:wireless_universal_terminal" />
  <ItemIcon id="ae2:wireless_crafting_terminal" />
  <ItemIcon id="ae2wtlib:wireless_pattern_encoding_terminal" />
  <ItemIcon id="ae2wtlib:wireless_pattern_access_terminal" />
</ItemGrid>

В дополнение к <ItemLink id="ae2:energy_card" />, все беспроводные терминалы AE2WTLib поддерживают
<ItemLink id="ae2wtlib:quantum_bridge_card" /> и могут быть объединены в
<ItemLink id="ae2wtlib:wireless_universal_terminal" />.

Как и <ItemLink id="ae2:wireless_terminal" /> из базового AE2, терминалы открываются по клавише
и могут быть помещены в слот кюрио (если установлен мод, реализующий Curio API).

Привязка к сети выполняется так же, как у обычного <ItemLink id="ae2:wireless_terminal" /> — через
<ItemLink id="ae2:wireless_access_point" />.

## Беспроводной универсальный терминал

<ItemImage id="ae2wtlib:wireless_universal_terminal" scale="3" />

<ItemLink id="ae2wtlib:wireless_universal_terminal" /> — объединение нескольких беспроводных терминалов
в один предмет.

## Беспроводной терминал крафта

<ItemImage id="ae2:wireless_crafting_terminal" scale="3" />

<ItemLink id="ae2:wireless_crafting_terminal" /> — беспроводная версия терминала крафта.
Имеет [дополнительные возможности](wireless_crafting_terminal.md) по сравнению с базовым AE2.

## Беспроводной терминал кодирования шаблонов

<ItemImage id="ae2wtlib:wireless_pattern_encoding_terminal" scale="3" />

Беспроводная версия <ItemLink id="ae2:pattern_encoding_terminal" />.

<RecipeFor id="ae2wtlib:wireless_pattern_encoding_terminal" />

## Беспроводной терминал доступа к шаблонам

<ItemImage id="ae2wtlib:wireless_pattern_access_terminal" scale="3" />

Беспроводная версия <ItemLink id="ae2:pattern_access_terminal" />.

<RecipeFor id="ae2wtlib:wireless_pattern_access_terminal" />

## Терминалы из аддонов

Большинство беспроводных терминалов из других аддонов также работают с
<ItemLink id="ae2wtlib:wireless_universal_terminal" />.

## Терминалы, несовместимые с универсальным

<ItemLink id="ae2:wireless_terminal" /> нельзя добавить в <ItemLink id="ae2wtlib:wireless_universal_terminal" />,
так как он не даст никакого преимущества перед <ItemLink id="ae2:wireless_crafting_terminal" />.
Он также не поддерживает <ItemLink id="ae2wtlib:quantum_bridge_card" />.
