---
navigation:
  parent: ae2wtlib/ae2wtlib-index.md
  title: Беспроводной универсальный терминал
  icon: ae2wtlib:wireless_universal_terminal
  position: 20
categories:
- ae2wtlib
item_ids:
  - ae2wtlib:wireless_universal_terminal
---

# Беспроводной универсальный терминал

<ItemImage id="ae2wtlib:wireless_universal_terminal" scale="3" />

<ItemLink id="ae2wtlib:wireless_universal_terminal" /> — объединение нескольких
[беспроводных терминалов](wireless_terminals.md) в один предмет.

В него можно объединить все беспроводные терминалы AE2WTLib.

<ItemLink id="ae2:wireless_terminal" /> из базового AE2 объединить с
<ItemLink id="ae2wtlib:wireless_universal_terminal" /> ***НЕЛЬЗЯ***.

## Интерфейс

<ItemLink id="ae2wtlib:wireless_universal_terminal" /> добавляет в интерфейс кнопку, которая при
левом клике (или правом) переключает на следующий (или предыдущий)
[беспроводной терминал](wireless_terminals.md).

## Улучшения

<ItemLink id="ae2wtlib:wireless_universal_terminal" /> принимает те же улучшения, что и установленные
[беспроводные терминалы](wireless_terminals.md). Каждый установленный терминал добавляет 2 слота для улучшений.

## Запас энергии

При объединении терминалов их запасы энергии суммируются — универсальный терминал с двумя
терминалами имеет вдвое больший запас, чем обычный [беспроводной терминал](wireless_terminals.md).
