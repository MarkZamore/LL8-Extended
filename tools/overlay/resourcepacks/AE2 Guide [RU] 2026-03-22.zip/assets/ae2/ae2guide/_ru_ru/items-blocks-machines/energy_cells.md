---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Ячейки энергии
  icon: energy_cell
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:energy_cell
- ae2:dense_energy_cell
- ae2:creative_energy_cell
---

# Ячейки энергии

<Row gap="20">
  <BlockImage id="energy_cell" scale="8" p:fullness="4" />

  <BlockImage id="dense_energy_cell" scale="8" p:fullness="4" />

  <BlockImage id="creative_energy_cell" scale="8" />
</Row>

Ячейки энергии увеличивают запас [энергии](../ae2-mechanics/energy.md) в сети. Буфер энергии сглаживает
пики потребления при массовых операциях, а большой запас позволяет работать без генерации (например,
ночью при солнечных панелях) или покрывать огромное мгновенное потребление
[пространственного хранилища](../ae2-mechanics/spatial-io.md).

## Индикаторы заряда

<Row>
<BlockImage id="energy_cell" scale="4" p:fullness="0" />
<BlockImage id="energy_cell" scale="4" p:fullness="1" />
<BlockImage id="energy_cell" scale="4" p:fullness="2" />
<BlockImage id="energy_cell" scale="4" p:fullness="3" />
<BlockImage id="energy_cell" scale="4" p:fullness="4" />
</Row>

Полоски на боку ячейки показывают её заряд:

*   0 — менее 25%
*   1 — от 25% до 50%
*   2 — от 50% до 75%
*   3 — от 75% до 99%
*   4 — более 99%

## Виды ячеек

*   <ItemLink id="energy_cell" /> вмещает 200 000 AE. Одной ячейки достаточно для большинства случаев.
*   <ItemLink id="dense_energy_cell" /> вмещает 1 600 000 AE — для работы от накопленной энергии или
    покрытия огромного потребления больших установок [пространственного хранилища](../ae2-mechanics/spatial-io.md).
*   <ItemLink id="creative_energy_cell" /> — творческий предмет для тестирования.

## Рецепты

<Row>
  <RecipeFor id="energy_cell" />

  <RecipeFor id="dense_energy_cell" />
</Row>
