---
navigation:
  parent: example-setups/example-setups-index.md
  title: «Трубная» подсеть для предметов/жидкостей
  icon: storage_bus
---

# «Трубная» подсеть для предметов/жидкостей

Простой метод имитации трубы для предметов и жидкостей с помощью [устройств](../ae2-mechanics/devices.md)
AE2. Полезно для всего, для чего обычно используются трубы, включая возврат результата крафта
в <ItemLink id="pattern_provider" />.

Есть два основных метода:

## Шина импорта → шина хранения

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/import_storage_pipe.snbt" />

<BoxAnnotation color="#dddddd" min="3.7 0 0" max="4 1 1">
        (1) Шина импорта: можно настроить фильтр.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 0 0" max="1.3 1 1">
        (2) Шина хранения: можно настроить фильтр. Должна быть единственным хранилищем в сети.
  </BoxAnnotation>

<DiamondAnnotation pos="4.5 0.5 0.5" color="#00ff00">
        Источник
    </DiamondAnnotation>

<DiamondAnnotation pos="0.5 0.5 0.5" color="#00ff00">
        Назначение
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

<ItemLink id="import_bus" /> (1) тянет предметы из исходного инвентаря и пытается сохранить в
[сетевом хранилище](../ae2-mechanics/import-export-storage.md). Так как единственное хранилище —
<ItemLink id="storage_bus" /> (2), предметы попадают в целевой инвентарь. Энергия через
<ItemLink id="quartz_fiber" />. Оба устройства можно фильтровать.

## Шина хранения → шина экспорта

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/storage_export_pipe.snbt" />

<BoxAnnotation color="#dddddd" min="3.7 0 0" max="4 1 1">
        (1) Шина хранения: можно фильтровать. Единственное хранилище в сети.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 0 0" max="1.3 1 1">
        (2) Шина экспорта: обязательно фильтровать.
  </BoxAnnotation>

<DiamondAnnotation pos="4.5 0.5 0.5" color="#00ff00">
        Источник
    </DiamondAnnotation>

<DiamondAnnotation pos="0.5 0.5 0.5" color="#00ff00">
        Назначение
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

<ItemLink id="export_bus" /> тянет предметы из фильтра из [сетевого хранилища](../ae2-mechanics/import-export-storage.md).
Единственное хранилище — <ItemLink id="storage_bus" />, поэтому предметы берутся из исходного инвентаря.
Шина экспорта должна быть отфильтрована.

## Схема, которая НЕ работает (шина импорта → шина экспорта)

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/import_export_pipe.snbt" />

<BoxAnnotation color="#dd3333" min="3.7 0 0" max="4 1 1">
        Шина импорта: некуда импортировать — нет хранилища.
  </BoxAnnotation>

<BoxAnnotation color="#dd3333" min="1 0 0" max="1.3 1 1">
        Шина экспорта: нечего экспортировать — нет хранилища.
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Схема с одной шиной импорта и одной шиной экспорта не работает — **нет хранилища**.

## Ввод и вывод через одну грань

Если машина принимает ввод и позволяет извлечь результат через одну грань (как <ItemLink id="charger" />),
можно объединить оба метода:

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/import_storage_export_pipe.snbt" />

<BoxAnnotation color="#dddddd" min="4 1 1" max="5 1.3 2">
        (1) Шина импорта: можно фильтровать.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="2 1 1" max="3 1.3 2">
        (2) Шина хранения: единственное хранилище в сети.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="0 1 1" max="1 1.3 2">
        (3) Шина экспорта: обязательно фильтровать.
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Интерфейсы

<ItemLink id="interface" /> тоже взаимодействует с [сетевым хранилищем](../ae2-mechanics/import-export-storage.md).
Ненастроенный интерфейс отдаёт предметы в хранилище (как шина импорта → шина хранения). Настроенный
на хранение предмет — тянет из хранилища (как шина хранения → шина экспорта).

<GameScene zoom="6" background="transparent">
<ImportStructure src="../assets/assemblies/interface_pipes.snbt" />

<BoxAnnotation color="#dddddd" min="3.7 0 0" max="4 1 1">
        Интерфейс
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 0 0" max="1.3 1 1">
        Шина хранения
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Один к нескольким и несколько к одному

Можно использовать несколько шин импорта, экспорта и хранения одновременно:

<GameScene zoom="3" background="transparent">
<ImportStructure src="../assets/assemblies/many_to_many_pipe.snbt" />
<IsometricCamera yaw="185" pitch="30" />
</GameScene>

## Подача в несколько мест

Для отправки ингредиентов от одного поставщика шаблонов в несколько мест используйте
<ItemLink id="interface" /> (поставщик должен быть направленным или плоским):

<GameScene zoom="6" background="transparent">
<ImportStructure src="../assets/assemblies/provider_interface_storage.snbt" />

<BoxAnnotation color="#dddddd" min="2.7 0 1" max="3 1 2">
        Интерфейс (должен быть плоским, не полноблочным)
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 0 0" max="1.3 1 4">
        Шины хранения
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="0 0 0" max="1 1 4">
        Места для подачи (несколько машин или сторон)
  </BoxAnnotation>

<IsometricCamera yaw="185" pitch="30" />
</GameScene>
