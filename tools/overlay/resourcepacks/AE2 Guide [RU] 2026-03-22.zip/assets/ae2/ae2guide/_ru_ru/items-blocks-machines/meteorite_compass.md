---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Метеоритный компас
  icon: meteorite_compass
  position: 410
categories:
- tools
item_ids:
- ae2:meteorite_compass
---

# Метеоритный компас

<ItemImage id="meteorite_compass" scale="4" />

Метеоритный компас указывает на ближайший <ItemLink id="mysterious_cube" />, то есть на ближайший
[метеорит](../ae2-mechanics/meteorites.md). Один из первых предметов AE2, которые стоит скрафтить.

## Рецепт

<RecipeFor id="meteorite_compass" />
