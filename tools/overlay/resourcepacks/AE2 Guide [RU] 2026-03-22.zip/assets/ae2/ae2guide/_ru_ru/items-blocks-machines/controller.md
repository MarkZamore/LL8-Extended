---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Контроллер
  icon: controller
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:controller
---

# Контроллер

<BlockImage id="controller" p:state="online" scale="8" />

Контроллер — узел маршрутизации [МЭ-сети](../ae2-mechanics/me-network-connections.md). Без него сеть
является «одноранговой» и поддерживает не более 8 [устройств](../ae2-mechanics/devices.md), использующих каналы.

Нельзя иметь 2 контроллера в одной [МЭ-сети](../ae2-mechanics/me-network-connections.md).

Контроллер обеспечивает 32 [канала](../ae2-mechanics/channels.md) на каждую сторону.

Контроллер потребляет 6 AE/т на каждый блок. Каждый блок хранит 8000 AE, поэтому для больших сетей
может потребоваться дополнительное хранилище энергии. Подробнее — на странице [Энергия](../ae2-mechanics/energy.md).

Мультиблочные контроллеры строятся достаточно свободно.

<GameScene zoom="2" background="transparent">
  <ImportStructure src="../assets/assemblies/controllers.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Однако есть несколько правил:

1.  Все блоки контроллера в [МЭ-сети](../ae2-mechanics/me-network-connections.md) должны быть соединены,
    иначе они станут красными.
2.  Размер контроллера должен быть в пределах 7×7×7, иначе он станет красным.
3.  Контроллер может иметь не более 2 соседних блоков по одной оси. При нарушении этого правила
    блок отключится и станет красным.

<GameScene zoom="2" background="transparent">
  <ImportStructure src="../assets/assemblies/controller_rules.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Если все правила соблюдены и питание подключено, контроллер должен светиться и переливаться цветами.

Клик правой кнопкой по контроллеру открывает тот же интерфейс, что и <ItemLink id="network_tool" />.

## Рецепт

<RecipeFor id="controller" />
