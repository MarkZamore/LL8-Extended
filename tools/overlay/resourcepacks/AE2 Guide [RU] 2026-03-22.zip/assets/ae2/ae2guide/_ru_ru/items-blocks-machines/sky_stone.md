---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Небесный камень
  icon: sky_stone_block
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:sky_stone_block
- ae2:smooth_sky_stone_block
---

# Небесный камень

<BlockImage id="sky_stone_block" scale="8" />

Материал, из которого сделаны [метеориты](../ae2-mechanics/meteorites.md). Используется в рецептах
<ItemLink id="sky_stone_tank" />, <ItemLink id="not_so_mysterious_cube" />, <ItemLink id="cell_component_256k" />
и, самое главное, <ItemLink id="controller" />.

## Рецепты

Направьте плоскость уничтожения вверх на максимальной высоте мира для получения пыли небесного камня.

<RecipeFor id="sky_stone_block" />

<RecipeFor id="smooth_sky_stone_block" />
