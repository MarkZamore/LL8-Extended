---
navigation:
  title: "Дополнение: AE2 Import Export Card"
  icon: ae2importexportcard:export_card
  position: 150
categories:
  - tools
item_ids:
- ae2importexportcard:export_card
- ae2importexportcard:import_card
---

# AE2 Import Export Card

<Row>
  <ItemImage id="ae2importexportcard:export_card" scale="2" />
  <ItemImage id="ae2importexportcard:import_card" scale="2" />
</Row>

Карточки импорта и экспорта позволяют перемещать предметы между инвентарём игрока и ME-системой.

## Карточка импорта

<ItemImage id="ae2importexportcard:import_card" scale="2" />

Карточка импорта берёт предметы из определённых слотов инвентаря и отправляет их в ME-систему.

![Import Card](diagrams/import_card.png)

Нажатие на слот ставит галочку. Предмет в отмеченном слоте будет импортирован в ME. Перетащите предметы из инвентаря наверх для настройки фильтра.

### Улучшения

Карточка импорта поддерживает следующие [улучшения](items-blocks-machines/upgrade_cards.md):

*   <ItemLink id="fuzzy_card" /> — фильтрация по уровню прочности и/или игнорирование NBT
*   <ItemLink id="inverter_card" /> — переключение фильтра с белого списка на чёрный

### Рецепт

<RecipeFor id="ae2importexportcard:import_card" />

## Карточка экспорта

<ItemImage id="ae2importexportcard:export_card" scale="2" />

Работает так же, но в обратную сторону — извлекает предметы из ME в инвентарь.

![Export Card](diagrams/export_card.png)

Перетащите предмет из инвентаря в слот наверху, затем нажмите на слот инвентаря чтобы задать нужное количество. ПКМ сбрасывает до X.

### Улучшения

Карточка экспорта поддерживает следующие [улучшения](items-blocks-machines/upgrade_cards.md):

*   <ItemLink id="fuzzy_card" /> — фильтрация по уровню прочности и/или игнорирование NBT
*   <ItemLink id="speed_card" /> — улучшает скорость передачи от 1 до целого стака
*   <ItemLink id="crafting_card" /> — автоматически запрашивает крафт отсутствующих предметов

### Рецепт

<RecipeFor id="ae2importexportcard:export_card" />
