---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Процессорный блок крафта (хранилище, ускоритель, монитор, блок)
  icon: 1k_crafting_storage
  position: 210
categories:
- devices
item_ids:
- ae2:1k_crafting_storage
- ae2:4k_crafting_storage
- ae2:16k_crafting_storage
- ae2:64k_crafting_storage
- ae2:256k_crafting_storage
- ae2:crafting_accelerator
- ae2:crafting_monitor
- ae2:crafting_unit
---

# Процессорный блок крафта

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/crafting_cpus.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

<Row>
  <BlockImage id="1k_crafting_storage" scale="4" />

  <BlockImage id="crafting_accelerator" scale="4" />

  <BlockImage id="crafting_monitor" scale="4" />

  <BlockImage id="crafting_unit" scale="4" />
</Row>

Процессорные блоки управляют запросами и заданиями крафта. Хранят промежуточные ингредиенты при
многошаговых заданиях, определяют максимальный объём задания и отчасти его скорость. Подробнее —
в разделе [Автокрафт](../ae2-mechanics/autocrafting.md).

Каждый процессорный блок обрабатывает 1 запрос или задание. Для одновременного крафта вычислительного
процессора и 256 гладкого камня потребуется 2 мультиблока.

Можно настроить источник запросов: от игроков, от автоматики (шины экспорта и интерфейсы) или от обоих.

Клик правой кнопкой открывает интерфейс статуса крафта с прогрессом текущего задания.

## Настройки

*   Процессорный блок можно настроить на приём запросов только от игроков, только от автоматики
    (<ItemLink id="export_bus" /> с <ItemLink id="crafting_card" />) или от обоих.

## Конструкция

Процессорные блоки — мультиблоки, должны быть сплошными прямоугольными параллелепипедами без пустот.
Состоят из нескольких компонентов.

Каждый блок должен содержать как минимум 1 хранилище крафта (минимальный рабочий вариант — один блок
хранилища крафта 1К).

# Блок крафта

<BlockImage id="crafting_unit" scale="4" />

(Опционально) Блоки крафта просто заполняют пространство, делая блок сплошным прямоугольным
параллелепипедом. Также являются базовым компонентом для других частей.

<RecipeFor id="crafting_unit" />

# Хранилище крафта

<Row>
  <BlockImage id="1k_crafting_storage" scale="4" />

  <BlockImage id="4k_crafting_storage" scale="4" />

  <BlockImage id="16k_crafting_storage" scale="4" />

  <BlockImage id="64k_crafting_storage" scale="4" />

  <BlockImage id="256k_crafting_storage" scale="4" />
</Row>

(Обязательно) Доступно во всех стандартных размерах (1К, 4К, 16К, 64К, 256К). Хранит ингредиенты
и промежуточные материалы крафта — для больших заданий нужно больше хранилища.

<Column>
  <Row>
    <RecipeFor id="1k_crafting_storage" />

    <RecipeFor id="4k_crafting_storage" />

    <RecipeFor id="16k_crafting_storage" />
  </Row>

  <Row>
    <RecipeFor id="64k_crafting_storage" />

    <RecipeFor id="256k_crafting_storage" />
  </Row>
</Column>

# Ускоритель крафта

<BlockImage id="crafting_accelerator" scale="4" />

(Опционально) Ускорители заставляют систему чаще отправлять партии ингредиентов от
<ItemLink id="pattern_provider" />, ускоряя тактирование блока. Это позволяет, например, поставщику
шаблонов, окружённому <ItemLink id="molecular_assembler" />, равномерно загружать все сборщики.

Некоторые сложные рецепты имеют шаги, выполнимые параллельно — например, одновременное изготовление
досок и книг для книжных полок. В интерфейсе статуса они отображаются как «в очереди». Каждый
дополнительный ускоритель позволяет выполнять ещё один такой шаг параллельно. Впрочем, ускорители
обычно нужны просто для скорости вставки, а не для параллелизации шагов.

<RecipeFor id="crafting_accelerator" />

# Монитор крафта

<BlockImage id="crafting_monitor" scale="4" />

(Опционально) Монитор крафта отображает текущее задание процессорного блока.
Экран можно покрасить с помощью <ItemLink id="color_applicator" />.

<RecipeFor id="crafting_monitor" />
