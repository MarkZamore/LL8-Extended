---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Фасады
  icon: facade
  icon_components:
    "ae2:facade_item": "minecraft:stone"
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:facade
---

# Фасады

Фасады делают базу аккуратнее, скрывая кабели под текстурой блоков.

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/facades_1.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Фасады закрывают все стороны кабеля, но дают проходить [субчастям](../ae2-mechanics/cable-subparts.md)
и соединениям кабелей.

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/facades_2.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Используйте их творчески — улучшайте эстетику базы или создавайте блоки с разными текстурами на гранях.

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="../assets/assemblies/facades_3.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Скрытие фасадов

Фасады скрываются при удержании <a href="network_tool.md">сетевого инструмента</a> в любой руке.

Можно взаимодействовать с блоками за скрытыми фасадами, не снимая их.

## Рецепт

Поместите нужный блок в центр 4 <ItemLink id="cable_anchor" />.

![Рецепт фасада](../assets/diagrams/facade_recipe.png)
