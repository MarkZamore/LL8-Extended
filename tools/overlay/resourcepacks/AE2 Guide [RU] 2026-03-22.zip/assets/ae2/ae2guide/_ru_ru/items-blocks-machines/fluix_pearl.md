---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Флюисовый жемчуг
  icon: fluix_pearl
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:fluix_pearl
---

# Флюисовый жемчуг

<ItemImage id="fluix_pearl" scale="4" />

Жемчуг Эндера, покрытый <ItemLink id="fluix_crystal" />. Используется при производстве нескольких
компонентов AE2.

## Рецепт

<RecipeFor id="fluix_pearl" />
