---
navigation:
  parent: example-setups/example-setups-index.md
  title: Автоматизация зарядника
  icon: charger
---

# Автоматизация зарядника

Поскольку используется <ItemLink id="pattern_provider" />, эта схема предназначена для интеграции
в [автокрафт](../ae2-mechanics/autocrafting.md). Для автономного зарядника используйте воронки и сундуки.

Автоматизация <ItemLink id="charger" /> проста: <ItemLink id="pattern_provider" /> подаёт ингредиент
в зарядник, затем [трубная подсеть](pipe-subnet.md) или другая труба возвращает результат в поставщика.

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/charger_automation.snbt" />

<BoxAnnotation color="#dddddd" min="1 0 0" max="2 1 1">
        (1) Поставщик шаблонов: стандартная конфигурация с нужными шаблонами обработки. Также питает зарядник.
        ![Шаблон зарядника](../assets/diagrams/charger_pattern_small.png)
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="0 1 0" max="1 1.3 1">
        (2) Шина импорта: стандартная конфигурация.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 1 0" max="2 1.3 1">
        (3) Шина хранения: стандартная конфигурация.
  </BoxAnnotation>

<DiamondAnnotation pos="4 0.5 0.5" color="#00ff00">
        К основной сети
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Настройки

* <ItemLink id="pattern_provider" /> (1) — стандартная конфигурация с нужными <ItemLink id="processing_pattern" />.
  Также питает зарядник через сетевое соединение.

  ![Шаблон зарядника](../assets/diagrams/charger_pattern.png)

* <ItemLink id="import_bus" /> (2) — стандартная конфигурация.
* <ItemLink id="storage_bus" /> (3) — стандартная конфигурация.

## Как работает

1. <ItemLink id="pattern_provider" /> подаёт ингредиенты в <ItemLink id="charger" />.
2. Зарядник заряжает предмет.
3. <ItemLink id="import_bus" /> в зелёной подсети извлекает результат из зарядника и пытается
   поместить в [сетевое хранилище](../ae2-mechanics/import-export-storage.md).
4. Единственное хранилище в зелёной подсети — <ItemLink id="storage_bus" />, которая кладёт предметы
   в поставщик шаблонов, возвращая их в основную сеть.
