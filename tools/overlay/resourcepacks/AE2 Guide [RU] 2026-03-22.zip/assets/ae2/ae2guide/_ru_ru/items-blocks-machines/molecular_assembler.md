---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Молекулярный сборщик
  icon: molecular_assembler
  position: 310
categories:
- machines
item_ids:
- ae2:molecular_assembler
---

# Молекулярный сборщик

<BlockImage id="molecular_assembler" scale="8" />

Молекулярный сборщик принимает вложенные предметы, выполняет операцию, заданную соседним
<ItemLink id="pattern_provider" /> или вставленным шаблоном, и выталкивает результат в соседние инвентари.

Этот сборщик содержит шаблон крафта «1 дубовое бревно = 4 дубовые доски». При подаче брёвен
через воронку он крафтит доски и бросает их в нижнюю воронку.

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/standalone_assembler.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Основное применение

Главное применение — рядом с <ItemLink id="pattern_provider" />. Поставщики шаблонов имеют особое
поведение: передают информацию о шаблоне вместе с ингредиентами соседним сборщикам. Так как сборщики
выбрасывают результаты в соседние инвентари (то есть в возвратные слоты поставщика), одного сборщика
на поставщике достаточно для автоматизации.

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/assembler_tower.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Улучшения

*   <ItemLink id="speed_card" />

## Рецепт

<RecipeFor id="molecular_assembler" />

## Примечание

Optifine ломает функцию «выброс в соседние инвентари», поэтому большинство установок крафта
со сборщиками перестают работать.
