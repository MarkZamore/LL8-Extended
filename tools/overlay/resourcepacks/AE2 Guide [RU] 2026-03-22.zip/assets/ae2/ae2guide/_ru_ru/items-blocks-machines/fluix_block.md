---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Блок флюиса
  icon: fluix_block
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:fluix_block
---

# Блок флюиса

<BlockImage id="fluix_block" scale="8" />

Блок-хранилище для <ItemLink id="fluix_crystal" />. Используется в рецептах некоторых машин.

## Рецепт

<RecipeFor id="fluix_block" />
