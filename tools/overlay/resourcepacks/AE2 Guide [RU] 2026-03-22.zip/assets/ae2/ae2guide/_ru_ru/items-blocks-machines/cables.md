---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Кабели
  icon: fluix_glass_cable
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:white_glass_cable
- ae2:orange_glass_cable
- ae2:magenta_glass_cable
- ae2:light_blue_glass_cable
- ae2:yellow_glass_cable
- ae2:lime_glass_cable
- ae2:pink_glass_cable
- ae2:gray_glass_cable
- ae2:light_gray_glass_cable
- ae2:cyan_glass_cable
- ae2:purple_glass_cable
- ae2:blue_glass_cable
- ae2:brown_glass_cable
- ae2:green_glass_cable
- ae2:red_glass_cable
- ae2:black_glass_cable
- ae2:fluix_glass_cable
- ae2:white_covered_cable
- ae2:orange_covered_cable
- ae2:magenta_covered_cable
- ae2:light_blue_covered_cable
- ae2:yellow_covered_cable
- ae2:lime_covered_cable
- ae2:pink_covered_cable
- ae2:gray_covered_cable
- ae2:light_gray_covered_cable
- ae2:cyan_covered_cable
- ae2:purple_covered_cable
- ae2:blue_covered_cable
- ae2:brown_covered_cable
- ae2:green_covered_cable
- ae2:red_covered_cable
- ae2:black_covered_cable
- ae2:fluix_covered_cable
- ae2:white_covered_dense_cable
- ae2:orange_covered_dense_cable
- ae2:magenta_covered_dense_cable
- ae2:light_blue_covered_dense_cable
- ae2:yellow_covered_dense_cable
- ae2:lime_covered_dense_cable
- ae2:pink_covered_dense_cable
- ae2:gray_covered_dense_cable
- ae2:light_gray_covered_dense_cable
- ae2:cyan_covered_dense_cable
- ae2:purple_covered_dense_cable
- ae2:blue_covered_dense_cable
- ae2:brown_covered_dense_cable
- ae2:green_covered_dense_cable
- ae2:red_covered_dense_cable
- ae2:black_covered_dense_cable
- ae2:fluix_covered_dense_cable
- ae2:white_smart_cable
- ae2:orange_smart_cable
- ae2:magenta_smart_cable
- ae2:light_blue_smart_cable
- ae2:yellow_smart_cable
- ae2:lime_smart_cable
- ae2:pink_smart_cable
- ae2:gray_smart_cable
- ae2:light_gray_smart_cable
- ae2:cyan_smart_cable
- ae2:purple_smart_cable
- ae2:blue_smart_cable
- ae2:brown_smart_cable
- ae2:green_smart_cable
- ae2:red_smart_cable
- ae2:black_smart_cable
- ae2:fluix_smart_cable
- ae2:white_smart_dense_cable
- ae2:orange_smart_dense_cable
- ae2:magenta_smart_dense_cable
- ae2:light_blue_smart_dense_cable
- ae2:yellow_smart_dense_cable
- ae2:lime_smart_dense_cable
- ae2:pink_smart_dense_cable
- ae2:gray_smart_dense_cable
- ae2:light_gray_smart_dense_cable
- ae2:cyan_smart_dense_cable
- ae2:purple_smart_dense_cable
- ae2:blue_smart_dense_cable
- ae2:brown_smart_dense_cable
- ae2:green_smart_dense_cable
- ae2:red_smart_dense_cable
- ae2:black_smart_dense_cable
- ae2:fluix_smart_dense_cable
---

# Кабели

<GameScene zoom="3" background="transparent">
  <ImportStructure src="../assets/assemblies/cables.snbt" />
  <IsometricCamera yaw="180" pitch="30" />
</GameScene>

Хотя МЭ-сети создаются и смежными МЭ-совместимыми машинами, кабели — основной способ расширить
МЭ-сеть на большие расстояния.

Кабели разных цветов помогают исключить соединение соседних кабелей, позволяя распределять
[каналы](../ae2-mechanics/channels.md) эффективнее. Они также влияют на цвет подключённых терминалов —
не обязательно делать все терминалы фиолетовыми. Флюисовые кабели соединяются с кабелями любого цвета.

Важно: **КАНАЛЫ НИКАК НЕ СВЯЗАНЫ С ЦВЕТОМ КАБЕЛЯ**

## Важное замечание

**Если вы новичок в AE2 и не знакомы с каналами — используйте умный кабель и плотный умный кабель везде,
где можно. Они показывают, как каналы маршрутизируются в сети, делая их поведение понятным.**

## Ещё одно замечание

**Это не трубы для предметов, жидкостей, энергии и т.п.** У кабелей нет внутреннего инвентаря,
поставщики шаблонов и машины не «вталкивают» в них ничего — они только соединяют [устройства](../ae2-mechanics/devices.md)
AE2 в сеть.

## Стеклянный кабель

<GameScene zoom="6" background="transparent">
<ImportStructure src="../assets/assemblies/fluix_glass_cable.snbt" />
<IsometricCamera yaw="195" pitch="30" />
</GameScene>

<ItemLink id="fluix_glass_cable" /> — самый простой в изготовлении кабель, передаёт питание и до 8
[каналов](../ae2-mechanics/channels.md). Доступен в 17 цветах, по умолчанию — флюисовый, красится любым из 16 красителей.

Чтобы скрафтить цветной кабель, окружите краситель 8 кабелями того же типа (цвет кабелей не важен, но
тип должен совпадать: стеклянные, умные и т.д.). Также можно красить кабели в мире совместимой
кистью для покраски.

Крафт любого цветного кабеля с ведром воды — снимает краситель.

Можно обернуть кабель шерстью, получив <ItemLink id="fluix_covered_cable" />, или скрафтить
<ItemLink id="fluix_smart_cable" /> для лучшего отображения загрузки [каналов](../ae2-mechanics/channels.md).

<RecipeFor id="fluix_glass_cable" />

<RecipeFor id="blue_glass_cable" />

## Покрытый кабель

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/fluix_covered_cable.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Покрытый вариант кабеля не даёт игровых преимуществ перед <ItemLink id="fluix_glass_cable" />.
Это альтернативный эстетический выбор, если вам нравится покрытый вид.

Красится так же, как <ItemLink id="fluix_glass_cable" />. Четыре <ItemLink id="fluix_covered_cable" />
можно скрафтить с редстоуном и светокамнем для получения <ItemLink id="fluix_covered_dense_cable" />.

<Recipe id="network/cables/covered_fluix" />

<RecipeFor id="blue_covered_cable" />

## Плотный кабель

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/fluix_covered_dense_cable.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Кабель повышенной ёмкости: передаёт 32 канала вместо 8 у стандартного. Однако не поддерживает
субчасти — перед установкой шин и панелей нужно перейти с плотного на обычный кабель
(например, <ItemLink id="fluix_glass_cable" /> или <ItemLink id="fluix_smart_cable" />).

Плотные кабели слегка перекрывают поведение «кратчайшего пути» каналов: каналы идут кратчайшим путём
к плотному кабелю, а затем кратчайшим путём через него к контроллеру.

<Recipe id="network/cables/dense_covered_fluix" />

<RecipeFor id="blue_covered_dense_cable" />

## Умный кабель

<Row>
<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/fluix_smart_cable.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>
<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/fluix_smart_dense_cable.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>
</Row>

Внешне похожи на <ItemLink id="fluix_covered_cable" />, но выполняют диагностическую функцию:
визуализируют использование каналов — они отображаются как светящиеся цветные линии вдоль чёрной
полосы на кабеле. Для обычных умных кабелей первые четыре канала показаны линиями цвета кабеля,
следующие четыре — белыми. На плотном умном кабеле каждая полоска соответствует 4 каналам.

На сетях с <ItemLink id="controller" /> линии на кабелях показывают точный путь каналов.

На одноранговых сетях умные кабели показывают общее количество используемых каналов в сети,
а не количество каналов через конкретный кабель.

Красятся так же, как <ItemLink id="fluix_glass_cable" />.

<Recipe id="network/cables/smart_fluix" />

<Recipe id="network/cables/dense_smart_fluix" />

<RecipeFor id="blue_smart_cable" />
