---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Цветущий истинный кварц
  icon: flawless_budding_quartz
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:flawless_budding_quartz
- ae2:flawed_budding_quartz
- ae2:chipped_budding_quartz
- ae2:damaged_budding_quartz
- ae2:small_quartz_bud
- ae2:medium_quartz_bud
- ae2:large_quartz_bud
- ae2:quartz_cluster
---

# Цветущий истинный кварц

(см. также [Выращивание кварца](../ae2-mechanics/certus-growth.md))

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/budding_blocks.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Бутоны истинного кварца прорастают из цветущих блоков истинного кварца, аналогично аметисту.
Их можно найти в [метеоритах](../ae2-mechanics/meteorites.md). Существует 4 уровня цветущих блоков:
Безупречный, Несовершенный, Треснутый и Повреждённый. Проще всего определить тип с помощью модов вроде
HWYLA, Jade, The One Probe и т.п. (или экрана F3).

У несовершенных, треснутых и повреждённых блоков каждый раз, когда бутон вырастает на одну стадию,
есть шанс деградировать на один уровень — вплоть до обычного <ItemLink id="quartz_block" />.

Безупречные цветущие блоки не деградируют и являются бесконечным источником кварца.

При добыче обычной киркой цветущие блоки деградируют на 1 уровень. При добыче киркой с шёлковым касанием
деградации нет — кроме безупречных. **Это означает, что безупречные цветущие блоки нельзя подобрать
и переместить киркой.** Вместо этого можно использовать [пространственное хранилище](../ae2-mechanics/spatial-io.md).

## Рецепты

Несовершенные, треснутые и повреждённые цветущие блоки крафтятся бросанием предыдущего уровня
(или <ItemLink id="quartz_block" />) в воду вместе с одним или несколькими
<ItemLink id="charged_certus_quartz_crystal" />.

Безупречные цветущие блоки нельзя скрафтить, их можно только найти в мире.

<Row>
  <RecipeFor id="damaged_budding_quartz" />

  <RecipeFor id="chipped_budding_quartz" />

  <RecipeFor id="flawed_budding_quartz" />
</Row>
