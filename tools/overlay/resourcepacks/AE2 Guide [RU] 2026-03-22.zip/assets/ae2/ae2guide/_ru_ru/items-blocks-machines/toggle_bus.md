---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Шина переключения
  icon: toggle_bus
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:toggle_bus
- ae2:inverted_toggle_bus
---

# Шина переключения

<GameScene zoom="8" background="transparent">
<ImportStructure src="../assets/assemblies/toggle_bus.snbt" />
<IsometricCamera yaw="195" pitch="30" />
</GameScene>

Шина, работающая как <ItemLink id="fluix_glass_cable" /> или другие кабели, но позволяющая
переключать состояние соединения через редстоун. Это позволяет отключать секции
[МЭ-сети](../ae2-mechanics/me-network-connections.md).

При подаче редстоун-сигнала соединение включается. <ItemLink id="inverted_toggle_bus" /> работает
наоборот — при сигнале отключает соединение.

Переключение может вызвать перезагрузку сети.

Являются [субчастями кабеля](../ae2-mechanics/cable-subparts.md).

## Рецепты

<RecipeFor id="toggle_bus" />

<RecipeFor id="inverted_toggle_bus" />
