---
navigation:
  title: Содержание
  position: 0
---

![Logo](assets/logo.png)

# Что такое Applied Energistics 2?

# Как пользоваться этим руководством

* Откройте боковую панель слева — там находится оглавление
* На многих страницах есть интерактивные сцены. Если рядом со сценой есть кнопки ![Plus](assets/diagrams/plus.png)
и ![Minus](assets/diagrams/minus.png) (масштаб), можно вращать и перемещать камеру.
Удерживайте левую кнопку мыши и тяните — для вращения, правую кнопку мыши и тяните — для перемещения.

# Что такое Applied Energistics 2?

Applied Energistics 2 добавляет компоненты и механики для организации логистики и хранения ресурсов. Вы можете заменить
огромную комнату с сундуками компактной МЭ-сетью, но это лишь начало. Applied Energistics создан для взаимодействия с
другими модами в сборке и позволяет их автоматизировать. Можно настроить систему так, чтобы одним нажатием
сразу крафтились все промежуточные компоненты и финальный предмет сложной цепочки крафта, поддерживать определённое
количество предметов на складе с автоматическим пополнением, или просто перемещать ресурсы по базе.

* [Начало работы](getting-started.md)
* [Советы и хитрости](tips-and-tricks.md)
* [Механики AE2](ae2-mechanics/ae2-mechanics-index.md)
* [Примеры схем](example-setups/example-setups-index.md)
* [Предметы, блоки и машины](items-blocks-machines/items-blocks-machines-index.md)

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="assets/assemblies/autocraft_setup_greebles.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>
