---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Материальная пушка
  icon: matter_cannon
  position: 410
categories:
- tools
item_ids:
- ae2:matter_cannon
---

# Материальная пушка

<ItemImage id="matter_cannon" scale="4" />

Портативная рельсовая пушка, стреляющая маленькими предметами — <ItemLink id="matter_ball" /> и
металлическими самородками. Урон зависит от предмета: «тяжёлые» вроде золотых самородков (10 урона)
наносят больше, чем лёгкие шарики материи (2 урона). Базовое потребление — 1600 AE за выстрел.

При включённом параметре «matterCannonBlockDamage» пушка ломает блоки в зависимости от их прочности
и урона боеприпаса.

Энергию восстанавливать в <ItemLink id="charger" />.

Пушка работает как [ячейка хранения](storage_cells.md) — удобнее всего заполнять магазин, вставив
пушку в слот ячейки в <ItemLink id="chest" />.

## Улучшения

*   <ItemLink id="fuzzy_card" /> фильтрация по прочности/NBT
*   <ItemLink id="inverter_card" /> переключает фильтр с белого на чёрный список
*   <ItemLink id="speed_card" /> увеличивает расход энергии — более мощные выстрелы
*   <ItemLink id="void_card" /> уничтожает вставляемые предметы при заполнении. Задайте разделы!
*   <ItemLink id="energy_card" /> увеличивает ёмкость батареи

## Рецепт

<RecipeFor id="matter_cannon" />
