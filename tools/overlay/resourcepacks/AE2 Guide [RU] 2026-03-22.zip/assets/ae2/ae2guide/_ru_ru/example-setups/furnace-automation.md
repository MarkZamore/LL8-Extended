---
navigation:
  parent: example-setups/example-setups-index.md
  title: Автоматизация печи
  icon: minecraft:furnace
---

# Автоматизация печи

Поскольку используется <ItemLink id="pattern_provider" />, эта схема предназначена для интеграции
в [автокрафт](../ae2-mechanics/autocrafting.md). Для автономной печи используйте воронки.

Печь сложнее простых машин: требует подачи с двух разных сторон и извлечения с третьей. Плавимый
предмет — сверху, топливо — сбоку, результат — снизу.

Это можно сделать через поставщик сверху, шину экспорта сбоку и шину импорта снизу, но расходует
3 [канала](../ae2-mechanics/channels.md). Вот как сделать это 1 каналом:

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/furnace_automation.snbt" />

<BoxAnnotation color="#dddddd" min="1 0 0" max="2 1 1">
        (1) Поставщик шаблонов: направленный вариант (гаечным ключом) с нужными шаблонами.
        ![Шаблон железа](../assets/diagrams/furnace_pattern_small.png)
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 1 0" max="2 1.3 1">
        (2) Интерфейс: стандартная конфигурация.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 1 0" max="1.3 2 1">
        (3) Шина хранения №1: фильтр на уголь.
        <ItemImage id="minecraft:coal" scale="2" />
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="0 2 0" max="1 2.3 1">
        (4) Шина хранения №2: чёрный список угля (карта-инвертер).
        <Row><ItemImage id="minecraft:coal" scale="2" /><ItemImage id="inverter_card" scale="2" /></Row>
  </BoxAnnotation>

<DiamondAnnotation pos="4 0.5 0.5" color="#00ff00">
        К основной сети
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Настройки

* <ItemLink id="pattern_provider" /> (1) — направленный (гаечным ключом), с нужными шаблонами обработки.

  ![Шаблон железа](../assets/diagrams/furnace_pattern.png)

* <ItemLink id="interface" /> (2) — стандартная конфигурация.
* Первая <ItemLink id="storage_bus" /> (3) — фильтр на уголь (или другое топливо).
* Вторая <ItemLink id="storage_bus" /> (4) — чёрный список топлива через <ItemLink id="inverter_card" />.

## Как работает

1. <ItemLink id="pattern_provider" /> подаёт ингредиенты в <ItemLink id="interface" />.
   (Фактически, как оптимизация, напрямую через шины хранения — предметы никогда не входят в интерфейс.)
2. Интерфейс без настроенного хранения пытается отдать предметы в [сетевое хранилище](../ae2-mechanics/import-export-storage.md).
3. Единственное хранилище в зелёной подсети — шины хранения. Шина с углём кладёт уголь в слот топлива
   сбоку, шина без угля кладёт плавимый предмет сверху.
4. Печь плавит.
5. Воронка извлекает результат снизу и кладёт в возвратные слоты поставщика.
