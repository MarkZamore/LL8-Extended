---
navigation:
  parent: example-setups/example-setups-index.md
  title: Продвинутая ферма кварца
  icon: certus_quartz_crystal
  position: 120
---

# Продвинутая ферма истинного кварца

По сути — [полуавтоматическая ферма](semiauto-certus-farm.md), но полностью интегрированная в МЭ-систему.
Вместо ручного обновления блоков используются [автоматизация зарядника](charger-automation.md) и
[автоматизация бросания в воду](throw-in-water-automation.md).

Оценку скоростей смотри в [Выращивание кварца](../ae2-mechanics/certus-growth.md).

**СЛОЖНАЯ ПОСТРОЙКА — ВРАЩАЙТЕ КАМЕРУ ДЛЯ ПРОСМОТРА**

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/advanced_certus_farm.snbt" />

  <BoxAnnotation color="#ddaaaa" min="3.7 2 1" max="4 3 2">
        (1) Плоскость уничтожения №1: можно зачаровать удачей.
  </BoxAnnotation>

  <BoxAnnotation color="#ddaaaa" min="2 2 1.7" max="3 3 2">
        (2) Шина хранения №1: фильтр на кристалл истинного кварца.
        <ItemImage id="certus_quartz_crystal" scale="2" />
  </BoxAnnotation>

  <DiamondAnnotation pos="3 2.5 1.5" color="#ff0000">
    Подсеть разрушения кластеров
  </DiamondAnnotation>

  <BoxAnnotation color="#aaddaa" min="3.7 1 1" max="4 2 2">
        (3) Плоскость уничтожения №2: шёлковое касание обязательно.
  </BoxAnnotation>

  <BoxAnnotation color="#aaddaa" min="2 1 1.7" max="3 2 2">
        (4) Шина хранения №2: фильтр на блок истинного кварца.
        <BlockImage id="quartz_block" scale="2" />
  </BoxAnnotation>

  <DiamondAnnotation pos="3 1.5 1.5" color="#00ff00">
    Подсеть разрушения блоков
  </DiamondAnnotation>

  <BoxAnnotation color="#ffddaa" min="4 0.7 1" max="5 1 2">
        (5) Плоскость формирования: стандартная конфигурация.
  </BoxAnnotation>

  <BoxAnnotation color="#ffddaa" min="2 0.7 2" max="3 1 3">
        (6) Шина импорта: фильтр на несовершенный цветущий кварц.
        <BlockImage id="flawed_budding_quartz" scale="2" />
  </BoxAnnotation>

  <DiamondAnnotation pos="3 0.5 1.5" color="#ddcc00">
    Подсеть размещения блоков
  </DiamondAnnotation>

  <BoxAnnotation color="#aaaadd" min="1.7 2 2" max="2 3 3">
        (7) Шина хранения №3: фильтр на кристалл. Высокий приоритет.
        <ItemImage id="certus_quartz_crystal" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#aaaadd" min="2 1 2" max="3 2 3">
        (8) Интерфейс: хранит 1 несовершенный цветущий кварц, имеет карту изготовления.
        <Row><BlockImage id="flawed_budding_quartz" scale="2" /> <ItemImage id="crafting_card" scale="2" /></Row>
  </BoxAnnotation>

<DiamondAnnotation pos="1.5 0.5 0" color="#00ff00">
        К основной сети, автоматизации зарядника и бросания в воду
    </DiamondAnnotation>

  <IsometricCamera yaw="165" pitch="5" />
</GameScene>

## Как работает

**Разрушение кластеров / блоков:** аналогично полуавтоматической ферме.

**Разрушение истощённых блоков:** кладёт <ItemLink id="quartz_block" /> в интерфейс (8), откуда
[автоматизация бросания в воду](throw-in-water-automation.md) делает новый <ItemLink id="flawed_budding_quartz" />.

**Размещение блоков:** шина импорта (6) берёт блок из интерфейса (8), плоскость формирования размещает его.

**На основной сети:** интерфейс (8) с <ItemLink id="crafting_card" /> автоматически запрашивает
новый несовершенный цветущий кварц через автокрафт при необходимости.
