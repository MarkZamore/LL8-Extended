---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Зарядник
  icon: charger
  position: 310
categories:
- machines
item_ids:
- ae2:charger
---

# Зарядник

<BlockImage id="charger" scale="8" />

Зарядник позволяет заряжать поддерживаемые инструменты и <ItemLink id="certus_quartz_crystal" />.

Питание подводится сверху или снизу — через [кабели](cables.md) AE2 или кабели питания других модов.
Принимает как энергию AE2 (AE), так и Forge Energy (FE). Предметы можно вставлять и извлекать с любой
стороны. Извлечь можно только результаты — так что фильтры для защиты от случайного извлечения кристаллов
вместо заряженных не нужны. Можно поворачивать с помощью <ItemLink id="certus_quartz_wrench" />
для удобства автоматизации.

Позволяет создавать <ItemLink id="charged_certus_quartz_crystal" /> из <ItemLink id="certus_quartz_crystal" />
и <ItemLink id="meteorite_compass" /> из <ItemLink id="minecraft:compass" />.

Чтобы зарядить вручную, установите <ItemLink id="crank" /> сверху или снизу и кликайте правой кнопкой
до полной зарядки.

Также является рабочим столом для [Исследователя флюиса](fluix_researcher.md).

## Простая автоматизация

В качестве примера: возможность поворота позволяет полуавтоматизировать зарядники так:

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/charger_hopper.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Рецепт

<RecipeFor id="charger" />
