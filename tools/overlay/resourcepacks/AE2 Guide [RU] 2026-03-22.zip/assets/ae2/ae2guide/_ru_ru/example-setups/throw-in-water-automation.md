---
navigation:
  parent: example-setups/example-setups-index.md
  title: Автоматизация бросания в воду
  icon: fluix_crystal
---

# Автоматизация рецептов бросания в воду

Поскольку используется <ItemLink id="pattern_provider" />, эта схема для интеграции в [автокрафт](../ae2-mechanics/autocrafting.md).

Некоторые рецепты требуют бросания предметов в воду. Автоматизируется через <ItemLink id="formation_plane" />
и <ItemLink id="annihilation_plane" />. Используйте вместе с [автоматизацией зарядника](charger-automation.md)
для получения <ItemLink id="charged_certus_quartz_crystal" />.

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/throw_in_water.snbt" />

<BoxAnnotation color="#dddddd" min="2 0 1" max="3 1 2">
        (1) Поставщик шаблонов: стандартная конфигурация с нужными шаблонами.
        ![Флюис](../assets/diagrams/fluix_pattern_small.png) ![Несовершенный цветущий](../assets/diagrams/flawed_budding_pattern_small.png)
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1.7 0 1" max="2 1 2">
        (2) Интерфейс: стандартная конфигурация.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 .7 1" max="2 1 2">
        (3) Плоскость формирования: режим бросания предметов.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 2 1" max="2 2.3 2">
        (4) Плоскость уничтожения: без настроек.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="2 1 1" max="3 1.3 2">
        (5) Шина хранения: фильтр на результаты шаблонов.
        <Row><ItemImage id="fluix_crystal" scale="2" /><BlockImage id="flawless_budding_quartz" scale="2" /></Row>
  </BoxAnnotation>

  <IsometricCamera yaw="180" pitch="0" />
</GameScene>

## Настройки

* <ItemLink id="pattern_provider" /> (1) с шаблонами обработки (от сырья напрямую):
  ![Флюис](../assets/diagrams/fluix_pattern.png)
  ![Несовершенный цветущий](../assets/diagrams/flawed_budding_pattern.png)
* <ItemLink id="interface" /> (2) — стандартная конфигурация.
* <ItemLink id="formation_plane" /> (3) — режим бросания предметов.
* <ItemLink id="annihilation_plane" /> (4) — без настроек.
* <ItemLink id="storage_bus" /> (5) — фильтр на результаты.

## Как работает

1. Поставщик подаёт ингредиенты в интерфейс зелёной подсети.
2. Интерфейс (без настроенного хранения) отдаёт их в сетевое хранилище.
3. Единственное хранилище в зелёной подсети — плоскость формирования, которая бросает предметы в воду.
4. Плоскость уничтожения в оранжевой подсети пытается подобрать предметы, но пока они трансформируются
   — не может (шина хранения фильтрует только результаты).
5. После трансформации плоскость подбирает результаты.
6. Шина хранения кладёт их в поставщик, возвращая в сеть.
