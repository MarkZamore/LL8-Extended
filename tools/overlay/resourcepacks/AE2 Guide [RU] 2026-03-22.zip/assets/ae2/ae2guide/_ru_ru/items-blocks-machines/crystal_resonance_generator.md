---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Кристальный резонирующий генератор
  icon: crystal_resonance_generator
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:crystal_resonance_generator
---

# Кристальный резонирующий генератор

<BlockImage id="crystal_resonance_generator" scale="8" />

Устройство генерирует энергию для МЭ-сети без топлива. Из-за вибраций кристаллов в каждой сети
может работать только один такой генератор. Вибрации распространяются даже через <ItemLink id="quartz_fiber" />.

**Скорость генерации:** <ae2:ConfigValue name="crystalResonanceGeneratorRate"/> AE/т

## Рецепты

<RecipeFor id="crystal_resonance_generator" />
