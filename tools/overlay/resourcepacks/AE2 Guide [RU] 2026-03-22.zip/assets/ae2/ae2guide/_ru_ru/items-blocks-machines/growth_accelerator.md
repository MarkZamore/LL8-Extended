---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Ускоритель роста
  icon: growth_accelerator
  position: 310
categories:
- machines
item_ids:
- ae2:growth_accelerator
---

# Ускоритель роста

<BlockImage id="growth_accelerator" p:powered="true" scale="8"/>

Ускоритель роста резко ускоряет [рост](../ae2-mechanics/certus-growth.md) кварца или аметиста при
установке рядом с цветущим блоком. Любопытно, что он также ускоряет рост различных растений.

Работает добавлением «случайных тиков» к соседним блокам в дополнение к естественным. Теоретически
1 ускоритель должен ускорять рост ~в 90 раз, эффект суммируется.

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/growth_accelerator.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Питание — сверху или снизу, через [кабели](cables.md) AE2 или кабели питания других модов.
Принимает AE или Forge Energy (FE).

Для ручного питания установите <ItemLink id="crank" /> сверху или снизу и кликайте правой кнопкой.

Верх и низ можно определить по розовым флюисовым деталям на них.

<GameScene zoom="6" background="transparent">
<ImportStructure src="../assets/assemblies/accelerator_connections.snbt" />
<IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Рецепт

<RecipeFor id="growth_accelerator" />
