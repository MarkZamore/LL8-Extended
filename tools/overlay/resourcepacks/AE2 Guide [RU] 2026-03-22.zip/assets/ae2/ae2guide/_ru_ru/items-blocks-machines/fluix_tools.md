---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Инструменты из флюиса
  icon: fluix_pickaxe
  position: 410
categories:
- tools
item_ids:
- ae2:fluix_axe
- ae2:fluix_hoe
- ae2:fluix_shovel
- ae2:fluix_pickaxe
- ae2:fluix_sword
---

# Инструменты из флюиса

<Row>
  <ItemImage id="fluix_axe" scale="4" />
  <ItemImage id="fluix_hoe" scale="4" />
  <ItemImage id="fluix_shovel" scale="4" />
  <ItemImage id="fluix_pickaxe" scale="4" />
  <ItemImage id="fluix_sword" scale="4" />
</Row>

Инструменты из [флюиса](fluix_crystal.md) аналогичны железным, но имеют втрое большую прочность
и чуть больший урон и скорость добычи.

Все инструменты из флюиса действуют как минимум с удачей/добычей 1 — полезно до получения доступа
к столу зачарований.

Потребуется <ItemLink id="fluix_upgrade_smithing_template" />.

## Рецепты

<Column>
  <Row>
    <RecipeFor id="fluix_axe" />
    <RecipeFor id="fluix_hoe" />
    <RecipeFor id="fluix_shovel" />
  </Row>
  <Row>
    <RecipeFor id="fluix_pickaxe" />
    <RecipeFor id="fluix_sword" />
  </Row>
</Column>
