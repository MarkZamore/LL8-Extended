---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: P2P-тоннели
  icon: me_p2p_tunnel
  position: 210
categories:
- devices
item_ids:
- ae2:me_p2p_tunnel
- ae2:redstone_p2p_tunnel
- ae2:item_p2p_tunnel
- ae2:fluid_p2p_tunnel
- ae2:fe_p2p_tunnel
- ae2:light_p2p_tunnel
---

# Тоннели Point-to-Point (P2P)

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/p2p_tunnels.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

P2P-тоннели позволяют перемещать предметы, жидкости, редстоун-сигналы, энергию, свет и
[каналы](../ae2-mechanics/channels.md) по сети, не взаимодействуя с ней напрямую. Существует много
вариантов, каждый переносит только свой тип. По сути это порталы, напрямую соединяющие две грани
блоков на расстоянии. Направленные: есть чётко определённые входы и выходы.

![Портал](../assets/assemblies/p2p_portal.png)

Например, воронка, направленная в предметный P2P, будет работать так, как если бы она была напрямую
соединена с бочкой.

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/p2p_hopper_barrel.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Однако две бочки рядом друг с другом передавать предметы не будут.

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/p2p_barrel_barrel.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Существуют и другие варианты — например, редстоуновый P2P:

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/p2p_redstone.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

И МЭ P2P, переносящий каналы:

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/p2p_channels.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Типы P2P-тоннелей и настройка

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/p2p_tunnels.snbt" />
  <IsometricCamera yaw="180" pitch="90" />
</GameScene>

Только МЭ P2P-тоннель крафтится напрямую. Остальные получаются правым кликом по тоннелю с нужным предметом:
- МЭ P2P — правый клик любым [кабелем](../items-blocks-machines/cables.md)
- Редстоуновый P2P — правый клик различными редстоун-компонентами
- Предметный P2P — правый клик сундуком или воронкой
- Жидкостный P2P — правый клик ведром или бутылкой
- Энергетический P2P — правый клик почти любым предметом с энергией
- Световой P2P — правый клик факелом или светокамнем

Некоторые типы имеют особенности. МЭ P2P-тоннели не могут передавать каналы через другие МЭ P2P-тоннели.
Энергетические P2P-тоннели берут косвенную комиссию 2,5% на FE, увеличивая своё
[потребление энергии](../ae2-mechanics/energy.md).

## Главное применение P2P

Самый распространённый случай — МЭ P2P для уплотнения передачи [каналов](../ae2-mechanics/channels.md).
Вместо пучка плотных кабелей один плотный кабель несёт много каналов.

В этом примере 8 входов МЭ P2P берут 256 каналов (8×32) от <ItemLink id="controller" /> и 8 выходов
передают их куда нужно. Каждый тоннель — вход или выход — занимает 1 канал. Поскольку тоннели на
выделенной [подсети](../ae2-mechanics/subnetworks.md), каналы основной сети не расходуются.

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="../assets/assemblies/p2p_compact_channels.snbt" />

  <BoxAnnotation color="#dddddd" min="1.3 1.3 6.3" max="2 2.7 6.7">
        Кварцевое волокно передаёт энергию между основной сетью и подсетью P2P.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="4.1 0 5.7" max="5 2.3 6.4">
        Тоннельный вход можно ставить прямо на контроллер или подключать кабелем.
  </BoxAnnotation>

  <IsometricCamera yaw="225" pitch="30" />
</GameScene>

## Вложенность

Нельзя использовать это для передачи бесконечных каналов через один кабель. Каналы МЭ P2P не проходят
через другие МЭ P2P. Обратите внимание: внешний слой МЭ P2P на красных кабелях не работает. Это
касается только МЭ P2P — другие типы могут проходить через МЭ P2P.

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/p2p_nesting.snbt" />
  <IsometricCamera yaw="225" pitch="30" />
</GameScene>

## Связывание

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/p2p_linking_frequency.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Концы P2P-тоннеля связываются с помощью <ItemLink id="memory_card" />.
- Shift+правый клик — сгенерировать новую частоту связи (этот тоннель станет входом).
- Правый клик — вставить частоту (этот тоннель станет выходом).

Можно иметь несколько выходов, но у МЭ P2P-тоннелей каналы входа делятся между выходами — дублирование невозможно.

## Рецепт

<RecipeFor id="me_p2p_tunnel" />
