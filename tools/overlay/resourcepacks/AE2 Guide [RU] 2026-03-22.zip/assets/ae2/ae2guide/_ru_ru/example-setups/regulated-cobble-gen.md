---
navigation:
  parent: example-setups/example-setups-index.md
  title: Генератор булыжника с регулировкой
  icon: minecraft:cobblestone
---

# Генератор булыжника с автоматической регулировкой

Автоматизировать генератор булыжника просто — направьте <ItemLink id="annihilation_plane" /> в
стандартный ванильный генератор. Но это постепенно забьёт сеть булыжником. Нужна регулировка.

Из-за особенностей работы плоскостей (они работают как шины импорта) нельзя просто поставить
<ItemLink id="level_emitter" /> и <ItemLink id="export_bus" /> с <ItemLink id="redstone_card" />.
Нужен обходной путь.

Решение: <ItemLink id="toggle_bus" /> на [подсети](../ae2-mechanics/subnetworks.md) — тогда при переключении
перезагружается только подсеть, не основная.

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="../assets/assemblies/regulated_cobble_gen.snbt" />

<BoxAnnotation color="#dddddd" min="3 2 2" max="7 2.3 3">
        (1) Плоскости уничтожения: можно зачаровать эффективностью и стойкостью для снижения расхода энергии.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2 2 2" max="2.3 3 3">
        (2) Шина хранения: стандартная конфигурация.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.3 2.3 2" max="2.7 2.7 2.3">
        (3) Шина переключения: ВАЖНО — на стороне подсети, не основной сети.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.3 3 2.3" max="2.7 3.3 2.7">
        (4) Излучатель уровня: булыжник, нужное количество, режим «Излучать ниже лимита».
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 2 3" max="2 3 2">
        (5) Интерфейс: стандартная конфигурация.
  </BoxAnnotation>

<DiamondAnnotation pos="0 2.5 1.5" color="#00ff00">
        К основной сети
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Как работает

1. Генератор производит булыжник.
2. Плоскости уничтожения ломают его.
3. Шина хранения кладёт булыжник в интерфейс → в основную сеть.
4. Когда количество превышает лимит — излучатель перестаёт посылать сигнал, шина переключения отключается.
5. Подсеть теряет питание → плоскости останавливаются.
