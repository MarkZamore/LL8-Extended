---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Беспроводные терминалы
  icon: wireless_crafting_terminal
  position: 410
categories:
- tools
item_ids:
- ae2:wireless_terminal
- ae2:wireless_crafting_terminal
---

# Беспроводные терминалы

<Row>
  <ItemImage id="wireless_terminal" scale="4" />
  <ItemImage id="wireless_crafting_terminal" scale="4" />
</Row>

Беспроводные терминалы — переносные версии проводных [терминалов](terminals.md). Интерфейс идентичен,
но вместо слотов для <ItemLink id="view_cell" /> — слоты для [карт улучшений](upgrade_cards.md).

Для привязки к сети: вставьте терминал в верхний правый слот <ItemLink id="wireless_access_point" />
(слот с картинкой терминала и стрелкой).

Должны находиться в зоне действия <ItemLink id="wireless_access_point" />.

Зарядка — в <ItemLink id="charger" />.

# Беспроводной терминал

<ItemImage id="wireless_terminal" scale="4" />

Просмотр и доступ к [сетевому хранилищу](../ae2-mechanics/import-export-storage.md) и
[автокрафту](../ae2-mechanics/autocrafting.md) из любой точки в зоне действия точки доступа.

## Улучшения

*   <ItemLink id="energy_card" /> увеличивает ёмкость батареи

## Рецепт

<RecipeFor id="wireless_terminal" />

# Беспроводной терминал крафта

<ItemImage id="wireless_crafting_terminal" scale="4" />

Как беспроводной терминал, но с сеткой крафта, автоматически пополняемой из сетевого хранилища.
Осторожно с Shift+кликом на результат!

## Улучшения

*   <ItemLink id="energy_card" /> увеличивает ёмкость батареи

## Рецепт

<RecipeFor id="wireless_crafting_terminal" />
