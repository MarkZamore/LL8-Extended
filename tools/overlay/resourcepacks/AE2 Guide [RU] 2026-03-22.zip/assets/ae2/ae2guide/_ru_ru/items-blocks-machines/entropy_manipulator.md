---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Манипулятор энтропии
  icon: entropy_manipulator
  position: 410
categories:
- tools
item_ids:
- ae2:entropy_manipulator
---

# Манипулятор энтропии

<ItemImage id="entropy_manipulator" scale="4" />

Манипулятор энтропии позволяет нагревать и охлаждать предметы: правый клик — нагрев, Shift+правый
клик — охлаждение. Умеет немного: испарять или замораживать воду, застывание лавы в обсидиан,
плавку брёвен в уголь и булыжника в камень прямо в мире.

Если конкретного действия для блока нет — работает как кремень со сталью.

Энергию можно восстановить в <ItemLink id="charger" />.

## Рецепт

<RecipeFor id="entropy_manipulator" />
