---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Квантовый мост
  icon: quantum_ring
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:quantum_link
- ae2:quantum_ring
---

# Квантовый сетевой мост

![Сформированный квантовый сетевой мост](../assets/diagrams/quantum_bridge_demonstration.png)

Квантовые сетевые мосты расширяют [сеть](../ae2-mechanics/me-network-connections.md) на бесконечные
расстояния и даже между измерениями. Передают 32 канала (независимо от того, как подключены кабели
к граням) — фактически беспроводной [плотный кабель](cables.md#dense-cable).

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/quantum_bridge_internal_structure_1.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/quantum_bridge_internal_structure_2.snbt" />
  <BoxAnnotation color="#33dd33" min="1 1 1" max="6 2 3">
        Воображаемый кабель между двумя конечными точками
  </BoxAnnotation>
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

**Обе стороны должны быть загружены** — нужен <ItemLink id="spatial_anchor" /> или другой загрузчик
чанков, если стороны далеко друг от друга.

# Квантовое кольцо

<BlockImage id="quantum_ring" scale="8" />

Восемь таких блоков вокруг <ItemLink id="quantum_link" /> создают квантовый сетевой мост. Только
4 кольца, смежных с камерой связи, принимают сетевые соединения — угловые блоки к кабелям
не подключаются.

## Рецепт

<RecipeFor id="quantum_ring" />

# Камера квантовой связи

<BlockImage id="quantum_link" scale="8" />

Один такой блок, окружённый <ItemLink id="quantum_ring" />, создаёт квантовый мост. Не подключается
к кабелям и регистрируется в сети только при полностью собранном мосту.

Инвентарь содержит один слот для <ItemLink id="quantum_entangled_singularity" /> и доступен для
автоматизации.

## Рецепт

<RecipeFor id="quantum_link" />
