---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Ячейка просмотра
  icon: view_cell
  position: 410
categories:
- tools
item_ids:
- ae2:view_cell
---

# Ячейка просмотра

<ItemImage id="view_cell" scale="2" />

Ячейки просмотра фильтруют отображение в [терминалах](terminals.md). Настраиваются в
<ItemLink id="cell_workbench" />.

Например, чтобы терминал показывал только каменные строительные блоки: настройте ячейку на эти
материалы и вставьте в терминал — будут отображаться только они.

Ячейки суммируются: с ячейкой на дубовые доски и ячейкой на булыжник терминал покажет и то, и другое.

## Рецепт

<Recipe id="network/cells/view_cell_storage" />

<Recipe id="network/cells/view_cell" />
