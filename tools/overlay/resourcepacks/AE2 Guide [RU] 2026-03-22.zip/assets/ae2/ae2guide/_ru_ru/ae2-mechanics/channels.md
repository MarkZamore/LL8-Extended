---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: Каналы
  icon: controller
---

# Каналы

[МЭ-сети](me-network-connections.md) Applied Energistics 2 требуют каналы для поддержки [устройств](../ae2-mechanics/devices.md),
использующих сетевое хранилище или другие сетевые службы. Думайте о каналах как об USB-кабелях для всех ваших устройств.
У компьютера ограниченное количество USB-портов, и он может поддерживать лишь столько устройств. Большинство машин,
полноблочных устройств и стандартных кабелей пропускают не более 8 каналов. Можно считать полноблочные устройства
и стандартные кабели пучком из 8 «каналных проводов». Однако [плотные кабели](../items-blocks-machines/cables.md#dense-cable)
поддерживают до 32 каналов. Другие устройства, способные передавать 32 канала — это <ItemLink id="me_p2p_tunnel" />
и [Квантовый сетевой мост](../items-blocks-machines/quantum_bridge.md). Каждый раз, когда устройство занимает канал,
представьте, как один «провод» вынимается из пучка — и этот провод уже недоступен дальше по линии.

<GameScene zoom="7" interactive={true}>
  <ImportStructure src="../assets/assemblies/channel_demonstration_1.snbt" />

  <LineAnnotation color="#33ff33" from="1 .4 .7" to="2.4 .4 .7" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="1 .6 .7" to="2.4 .6 .7" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="1 .4 .6" to="2.6 .4 .6" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="1 .6 .6" to="2.6 .6 .6" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="1 .6 .6" to="2.6 .6 .6" alwaysOnTop={true}/>

  <LineAnnotation color="#33ff33" from="2.4 .6 .7" to="2.4 .6 1.5" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="2.4 .4 .7" to="2.4 .4 1.5" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="2.6 .6 .6" to="2.6 .6 1.5" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="2.6 .4 .6" to="2.6 .4 1.5" alwaysOnTop={true}/>

  <LineAnnotation color="#33ff33" from="2.1 .6 1.5" to="2.4 .6 1.5" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="2.6 .4 1.5" to="2.9 .4 1.5" alwaysOnTop={true}/>

  <LineAnnotation color="#33ff33" from="2.6 .6 1.5" to="2.6 .9 1.5" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="2.4 .1 1.5" to="2.4 .4 1.5" alwaysOnTop={true}/>

  <LineAnnotation color="#33ff33" from="1 .6 .4" to="3.5 .6 .4" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="1 .4 .4" to="3.5 .4 .4" alwaysOnTop={true}/>

  <LineAnnotation color="#33ff33" from="3.5 .6 .4" to="3.5 .9 .4" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="3.5 .1 .4" to="3.5 .4 .4" alwaysOnTop={true}/>

  <LineAnnotation color="#33ff33" from="1 .6 .3" to="1.5 .6 .3" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="1 .4 .3" to="1.5 .4 .3" alwaysOnTop={true}/>

  <LineAnnotation color="#33ff33" from="1.5 .6 .3" to="1.5 .9 .3" alwaysOnTop={true}/>
  <LineAnnotation color="#33ff33" from="1.5 .1 .3" to="1.5 .4 .3" alwaysOnTop={true}/>

  <LineAnnotation color="#ff3333" from="3.5 .5 .5" to="5.5 .5 .5" alwaysOnTop={true}>
  Все 8 каналов в кабеле заняты, накопитель канала не получает.
  </LineAnnotation>

  <LineAnnotation color="#993333" from="1 .5 .5" to="1.25 .5 .5" alwaysOnTop={true}/>
  <LineAnnotation color="#993333" from="1.5 .5 .5" to="1.75 .5 .5" alwaysOnTop={true}/>
  <LineAnnotation color="#993333" from="2 .5 .5" to="2.25 .5 .5" alwaysOnTop={true}/>
  <LineAnnotation color="#993333" from="2.5 .5 .5" to="2.75 .5 .5" alwaysOnTop={true}/>
  <LineAnnotation color="#993333" from="3 .5 .5" to="3.25 .5 .5" alwaysOnTop={true}/>

  <DiamondAnnotation pos="3.6 0.5 0.5" color="#ff0000">
        Все 8 каналов в кабеле заняты, накопитель канала не получает.
    </DiamondAnnotation>

  <IsometricCamera yaw="15" pitch="30" />
</GameScene>

Простой способ увидеть, как используются и маршрутизируются каналы в сети — использовать [умные кабели](../items-blocks-machines/cables.md).
Они отображают пути и загрузку каналов прямо на себе.

Каналы потребляют 1⁄128 AE/т за каждый пройденный узел. Это значит, что при добавлении <ItemLink id="controller" />
в сеть с 8 устройствами и более чем 96 узлами энергопотребление может даже снизиться, так как изменяется
способ распределения каналов.

Важно: **КАНАЛЫ НИКАК НЕ СВЯЗАНЫ С ЦВЕТОМ КАБЕЛЯ**. Цвет кабеля только запрещает соединение кабелей разных цветов между собой.

## Маршрутизация каналов

При использовании <ItemLink id="controller" /> маршрутизация каналов происходит в 3 этапа. Сначала канал идёт
кратчайшим путём через соседние машины к ближайшему [обычному кабелю](../items-blocks-machines/cables.md)
(стеклянному, покрытому или умному). Затем — кратчайшим путём через этот обычный кабель к ближайшему
[плотному кабелю](../items-blocks-machines/cables.md). И наконец — кратчайшим путём через плотный кабель
к <ItemLink id="controller" />.
Если кратчайший путь уже перегружен, некоторые [устройства](devices.md) могут не получить нужные каналы.
Используйте цветные кабели, кабельные якоря и тоннели, чтобы каналы шли именно туда, куда вам нужно.

Например, в следующей сцене некоторые накопители не получают каналы — несмотря на то, что в кабелях есть
достаточно ёмкости, каналы пытаются идти кратчайшим путём, перегружая одни кабели и оставляя другие пустыми.

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="../assets/assemblies/channel_path_length_issue.snbt" />

  <LineAnnotation color="#33ff33" from="3 .5 1.4" to="0.4 0.5 1.4" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#33ff33" from="0.4 .5 1.4" to="0.4 0.5 3.6" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#33ff33" from="0.4 0.5 3.6" to="1.4 0.5 3.6" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#33ff33" from="1.4 0.5 3.6" to="1.4 0.5 5" alwaysOnTop={true} thickness="0.05"/>

  <LineAnnotation color="#33ff33" from="3 0.5 3.6" to="1.6 0.5 3.6" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#33ff33" from="1.6 0.5 3.6" to="1.6 0.5 5" alwaysOnTop={true} thickness="0.05"/>

  <LineAnnotation color="#ff3333" from="3 .5 1.6" to="0.6 .5 1.6" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#ff3333" from="0.6 .5 1.6" to="0.6 .5 3.4" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#ff3333" from="0.6 .5 3.4" to="1.4 .5 3.4" alwaysOnTop={true} thickness="0.05"/>

  <LineAnnotation color="#ff3333" from="3 .5 3.4" to="1.6 .5 3.4" alwaysOnTop={true} thickness="0.05"/>

  <BoxAnnotation color="#dddddd" min="1.2 0.2 3.2" max="1.8 0.8 3.8" alwaysOnTop={true} thickness="0.05">
        Через этот узел пытается пройти более 8 каналов — часть обрезается.
  </BoxAnnotation>

  <IsometricCamera yaw="90" pitch="90" />

</GameScene>

Исправить это можно, более тщательно ограничивая пути, по которым идут каналы. Сети должны иметь древовидную
(или кустообразную) структуру. Петли и неоднозначные пути маршрутизации нужно сводить к минимуму.

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="../assets/assemblies/channel_path_length_issue_fix.snbt" />

  <LineAnnotation color="#33ff33" from="3 .5 1.4" to="0.4 0.5 1.4" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#33ff33" from="0.4 .5 1.4" to="0.4 0.5 5.6" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#33ff33" from="0.4 0.5 5.6" to="1 0.5 5.6" alwaysOnTop={true} thickness="0.05"/>

  <LineAnnotation color="#33ff33" from="3 0.5 3.6" to="1.6 0.5 3.6" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#33ff33" from="1.6 0.5 3.6" to="1.6 0.5 5" alwaysOnTop={true} thickness="0.05"/>

  <IsometricCamera yaw="90" pitch="90" />

</GameScene>

## Одноранговые сети (Ad-Hoc)

Сеть без <ItemLink id="controller" /> считается одноранговой и поддерживает не более 8 устройств, использующих каналы.
Как только превышается 8 устройств, канальные устройства сети отключаются — нужно либо убрать лишние устройства,
либо добавить <ItemLink id="controller" />.

В отличие от сетей с контроллером, [умные кабели](../items-blocks-machines/cables.md) в одноранговых сетях показывают
общее количество задействованных каналов во всей сети, а не количество каналов, проходящих через конкретный кабель.

В одноранговой сети каждое устройство занимает 1 канал на уровне всей сети — это принципиально отличается от
того, как <ItemLink id="controller" /> распределяет каналы по кратчайшему пути.

## Проектирование сети

Как уже упоминалось в разделе [маршрутизации каналов](channels.md#channel-routing), лучшая структура сети —
древовидная: плотные кабели расходятся от контроллера, обычные — от плотных, а [устройства](../ae2-mechanics/devices.md)
группируются по 8 и менее на обычных кабелях.

Пример неправильной структуры:

Следуя путям каналов:

1. Сразу на выходе из контроллера вправо мы упираемся в узкое место из 8 каналов — накопитель ведёт себя
   как обычный кабель. Но поскольку здесь не умный кабель, загрузку увидеть нельзя. Осталось 8 каналов.
2. Накопитель занимает канал. Осталось 7.
3. 2 канала уходят вверх к терминалам. Осталось 5.
4. Идём вправо — интерфейс занимает ещё один канал. Осталось 4.
5. 1 канал уходит вверх к поставщику шаблонов. Осталось 3.
6. Идём вправо — 1 канал уходит вверх к шине импорта. Осталось 2.
7. Кластер поставщиков шаблонов, питающих сборщики, получает только 2 канала — 2 поставщика остаются без каналов.

Корень ошибки — в создании узкого места и отсутствии продуманного распределения каналов.

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="../assets/assemblies/bad_network_structure.snbt" />

<LineAnnotation color="#33ff33" from="6.5 .5 1.5" to="6 .5 1.5" alwaysOnTop={true} thickness="0.4">
  32 канала
</LineAnnotation>

<LineAnnotation color="#33ff33" from="6 .5 1.5" to="5.5 .5 1.5" alwaysOnTop={true} thickness="0.2">
  8 каналов
</LineAnnotation>

<LineAnnotation color="#33ff33" from="5.5 .5 1.5" to="5.5 1.5 1.5" alwaysOnTop={true} thickness="0.1">
  2 канала
</LineAnnotation>

<LineAnnotation color="#33ff33" from="5.5 .5 1.5" to="5.5 .3 1.5" alwaysOnTop={true} thickness="0.071">
  1 канал
</LineAnnotation>

<LineAnnotation color="#33ff33" from="5.5 1.5 1.5" to="5.5 2.5 1.5" alwaysOnTop={true} thickness="0.071">
  1 канал
</LineAnnotation>

<LineAnnotation color="#33ff33" from="5.5 2.5 1.5" to="5.5 2.5 1.1" alwaysOnTop={true} thickness="0.071">
  1 канал
</LineAnnotation>

<LineAnnotation color="#33ff33" from="5.5 .5 1.5" to="4.5 .5 1.5" alwaysOnTop={true} thickness="0.158">
  5 каналов
</LineAnnotation>

<LineAnnotation color="#33ff33" from="4.5 .5 1.5" to="4.5 .3 1.5" alwaysOnTop={true} thickness="0.071">
  1 канал
</LineAnnotation>

<LineAnnotation color="#33ff33" from="4.5 .5 1.5" to="4.5 1.5 1.5" alwaysOnTop={true} thickness="0.071">
  1 канал
</LineAnnotation>

<LineAnnotation color="#33ff33" from="4.5 .5 1.5" to="3.5 .5 1.5" alwaysOnTop={true} thickness="0.122">
  3 канала
</LineAnnotation>

<LineAnnotation color="#33ff33" from="3.5 .5 1.5" to="3.5 2.5 1.5" alwaysOnTop={true} thickness="0.071">
  1 канал
</LineAnnotation>

<LineAnnotation color="#33ff33" from="3.5 2.5 1.5" to="3.7 2.5 1.5" alwaysOnTop={true} thickness="0.071">
  1 канал
</LineAnnotation>

<LineAnnotation color="#33ff33" from="3.5 .5 1.5" to="1.5 .5 1.5" alwaysOnTop={true} thickness="0.1">
  2 канала
</LineAnnotation>

<LineAnnotation color="#33ff33" from="1.5 0.5 1.5" to="1.5 0.3 1.5" alwaysOnTop={true} thickness="0.071">
  1 канал
</LineAnnotation>

<LineAnnotation color="#33ff33" from="1.5 0.5 1.5" to="0.5 0.5 1.5" alwaysOnTop={true} thickness="0.071">
  1 канал
</LineAnnotation>

<LineAnnotation color="#33ff33" from="0.5 0.5 1.5" to="0.5 0.5 0.5" alwaysOnTop={true} thickness="0.071">
  1 канал
</LineAnnotation>

<LineAnnotation color="#ff3333" from="0.5 1.5 1.5" to="0.5 1.3 1.5" alwaysOnTop={true} thickness="0.071">
  нет каналов
</LineAnnotation>

<LineAnnotation color="#ff3333" from="1.5 1.5 0.5" to="1.5 1.3 0.5" alwaysOnTop={true} thickness="0.071">
  нет каналов
</LineAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

---

Пример правильной структуры:

<GameScene zoom="2.5" interactive={true}>
  <ImportStructure src="../assets/assemblies/treelike_network_structure.snbt" />

    <BoxAnnotation color="#dddddd" min="6.9 0 4.9" max="9.1 4 7.1" thickness="0.05">
        Обратите внимание: поставщики шаблонов разделены на отдельные группы по 8.
    </BoxAnnotation>

    <BoxAnnotation color="#dddddd" min="5 4 4" max="8 5 5" thickness="0.05">
        Два обычных кабеля, заполненных каналами, сходятся вместе — нужен плотный кабель.
    </BoxAnnotation>

    <BoxAnnotation color="#dddddd" min="5 0 13" max="8 1 14" thickness="0.05">
        Разные цвета кабелей используются, чтобы соседние кабели не соединялись.
    </BoxAnnotation>


  <IsometricCamera yaw="315" pitch="30" />
</GameScene>

## Режимы каналов

AE2 10.0.0 для Minecraft 1.18 вводит новые параметры изменения поведения каналов. Добавлена новая опция конфигурации
в разделе general (`channels`), а также внутриигровая команда для операторов. Команда `/ae2 channelmode <режим>`
меняет режим, `/ae2 channelmode` показывает текущий. При изменении режима в игре все существующие сети
перезагружаются и немедленно начинают работать в новом режиме.

Это возрождает и улучшает опцию из Minecraft 1.12, предоставляя более гибкие варианты для игроков, которые
хотят чуть более расслабленного геймплея, не отключая механику полностью.

| Настройка  | Описание                                                                                                                                                                                                                                    |
| ---------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `default`  | Стандартный режим с ёмкостью каналов кабелей и одноранговых сетей, описанной в этом руководстве                                                                                                                                             |
| `x2`       | Все ёмкости каналов удвоены (16 в обычном кабеле, 64 в плотном, одноранговые сети поддерживают 16 каналов)                                                                                                                                  |
| `x3`       | Все ёмкости утроены (24 в обычном, 92 в плотном, одноранговые — 24 канала)                                                                                                                                                                  |
| `x4`       | Все ёмкости учетверены (32 в обычном, 128 в плотном, одноранговые — 32 канала)                                                                                                                                                              |
| `infinite` | Все ограничения каналов сняты. Контроллеры по-прежнему *значительно* снижают энергопотребление сети. Умные кабели будут показывать только два состояния: полностью выключено (каналов нет) и полностью включено (1 или более каналов). |
