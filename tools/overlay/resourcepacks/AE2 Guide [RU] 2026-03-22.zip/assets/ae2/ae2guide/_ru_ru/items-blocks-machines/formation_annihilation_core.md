---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Ядра формирования и уничтожения
  icon: formation_core
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:formation_core
- ae2:annihilation_core
---

# Ядра формирования и уничтожения

<Row>
  <ItemImage id="formation_core" scale="4" />
  <ItemImage id="annihilation_core" scale="4" />
</Row>

Основные компоненты [устройств](../ae2-mechanics/devices.md) ввода и вывода AE2. С помощью энергии
<ItemLink id="fluix_crystal" /> и [логического процессора](processors.md) позволяют устройствам
принимать и отдавать предметы, блоки, жидкости и т.п. (Сами по себе функции не несут — только
промежуточный крафт.)

## Рецепты

<RecipeFor id="formation_core" />

<RecipeFor id="annihilation_core" />
