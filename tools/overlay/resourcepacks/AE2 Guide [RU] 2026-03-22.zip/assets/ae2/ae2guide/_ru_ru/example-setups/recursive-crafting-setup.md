---
navigation:
  parent: example-setups/example-setups-index.md
  title: Рекурсивный крафт
  icon: minecraft:netherite_upgrade_smithing_template
---

# Схема рекурсивного крафта

Как описано в [автокрафте](../ae2-mechanics/autocrafting.md), алгоритм планирования не умеет
обрабатывать рецепты, где выход является одним из входов — например, клонирование
<ItemLink id="minecraft:netherite_upgrade_smithing_template" />.

Решение — использовать способность <ItemLink id="level_emitter" /> притворяться
[шаблоном](../items-blocks-machines/patterns.md).

<RecipeFor id="minecraft:netherite_upgrade_smithing_template" />

***

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/recursive_recipe_setup.snbt" />

  <BoxAnnotation color="#dddddd" min="1 0 0" max="2 1 1">
        (1) Интерфейс: хранит нужные дополнительные ингредиенты — алмаз и незеррак.
        <Row><ItemImage id="minecraft:diamond" scale="2" /> <ItemImage id="minecraft:netherrack" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.3 1 0.3" max="2.7 1.3 0.7">
        (2) Излучатель уровня: настроен на шаблон незерита, режим «Испускать редстоун для крафта».
        <Row><ItemImage id="minecraft:netherite_upgrade_smithing_template" scale="2" /> <ItemImage id="crafting_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2 0 0" max="2.3 1 1">
        (3) Шина импорта №1: фильтр на ингредиенты интерфейса. Карта редстоуна, режим «Активна при сигнале».
        <Row>
        <ItemImage id="minecraft:diamond" scale="2" />
        <ItemImage id="minecraft:netherrack" scale="2" />
        <ItemImage id="redstone_card" scale="2" />
        </Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="3 1 1" max="4 1.3 2">
        (4) Шина хранения №1: более высокий приоритет. ОЧЕНЬ ВАЖНО.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="3 0 1" max="4 1 2">
        (5) Молекулярный сборщик: содержит шаблон клонирования и уже 1 шаблон вставлен вручную.
        ![Шаблон](../assets/diagrams/smithing_template_pattern_small.png)
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.7 0 1" max="3 1 2">
        (6) Шина импорта №2: стандартная конфигурация.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 0 1" max="2 1 1.3">
        (7) Шина хранения №2: фильтр на шаблон незерита. Более низкий приоритет.
        <ItemImage id="minecraft:netherite_upgrade_smithing_template" scale="2" />
  </BoxAnnotation>

<DiamondAnnotation pos="0 0.5 0.5" color="#00ff00">
        К основной сети
    </DiamondAnnotation>

  <IsometricCamera yaw="15" pitch="30" />
</GameScene>

## Как работает

1. Излучатель уровня с <ItemLink id="crafting_card" /> притворяется шаблоном — шаблон незерита
   доступен в терминале для автокрафта.
2. При запросе крафта излучатель включается.
3. Шина импорта №1 активируется и тянет ингредиенты из интерфейса.
4. Единственная подходящая шина хранения — на сборщике.
5. Сборщик получает ингредиенты (уже имея 1 шаблон) и производит 2 шаблона.
6. Шина импорта №2 извлекает 1 шаблон.
7. Высокий приоритет шины хранения №1 возвращает шаблон в сборщик.
8. Шина импорта №2 извлекает второй шаблон.
9. Сборщик не принимает второй шаблон — он попадает в шину хранения №2 (низкий приоритет), затем в интерфейс.
10. Интерфейс (без настроенного хранения шаблонов) кладёт его в сеть.

![Шаблон](../assets/diagrams/smithing_template_pattern.png)
