---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: МЭ шина экспорта
  icon: export_bus
  position: 220
categories:
- devices
item_ids:
- ae2:export_bus
---

# Шина экспорта

<GameScene zoom="8" background="transparent">
<ImportStructure src="../assets/blocks/export_bus.snbt" />
</GameScene>

Шина экспорта извлекает предметы и жидкости из [сетевого хранилища](../ae2-mechanics/import-export-storage.md)
и помещает их в соседний инвентарь.

Для снижения нагрузки шина переходит в режим «сна» при отсутствии экспорта, и ускоряется до полной
скорости (4 операции в секунду) при успешном экспорте.

Являются [субчастями кабеля](../ae2-mechanics/cable-subparts.md).

## Фильтрация

По умолчанию шина ничего не экспортирует. Предметы в слотах фильтра формируют белый список.

Предметы и жидкости можно перетаскивать в слоты из JEI/REI. Правый клик с контейнером для жидкости —
задать жидкость как фильтр.

## Улучшения

*   <ItemLink id="capacity_card" /> увеличивает количество слотов фильтра и добавляет настройку порядка экспорта
*   <ItemLink id="speed_card" /> увеличивает количество перемещаемых предметов за операцию
*   <ItemLink id="fuzzy_card" /> позволяет фильтровать по уровню прочности и/или игнорировать NBT
*   <ItemLink id="crafting_card" /> позволяет отправлять запросы [автокрафта](../ae2-mechanics/autocrafting.md)
*   <ItemLink id="redstone_card" /> добавляет управление редстоуном

## Скорость

| Карт ускорения | Предметов за операцию |
|:---------------|:----------------------|
| 0              | 1                     |
| 1              | 8                     |
| 2              | 32                    |
| 3              | 64                    |
| 4              | 96                    |

## Рецепт

<RecipeFor id="export_bus" />
