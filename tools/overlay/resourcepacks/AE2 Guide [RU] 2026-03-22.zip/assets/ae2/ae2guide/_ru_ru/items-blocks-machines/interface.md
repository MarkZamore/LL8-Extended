---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Интерфейс
  icon: interface
  position: 210
categories:
- devices
item_ids:
- ae2:interface
- ae2:cable_interface
---

# Интерфейс

<Row gap="20">
<BlockImage id="interface" scale="8" />
<GameScene zoom="8" background="transparent">
  <ImportStructure src="../assets/blocks/cable_interface.snbt" />
</GameScene>
</Row>

Интерфейс — небольшой сундук и бак для жидкостей, который наполняется из [сетевого хранилища](../ae2-mechanics/import-export-storage.md)
и опустошается в него в зависимости от настроенного запаса в слотах. Всё это происходит за один
игровой тик, поэтому через него можно передавать до 9 стаков за тик — быстрый метод импорта/экспорта
с быстрыми трубами.

Ещё одно достоинство: большинство баков хранит только 1 вид жидкости, а интерфейс — до 9, плюс предметы.
По сути это просто сундук/многожидкостный бак с дополнительными функциями. Если не подключать к сети —
работает как обычное хранилище.

## Как интерфейс работает изнутри

Интерфейс — это сундук/бак с очень быстрыми <ItemLink id="import_bus" /> и <ItemLink id="export_bus" />
и кучей <ItemLink id="level_emitter" />.

<GameScene zoom="3" interactive={true}>
  <ImportStructure src="../assets/assemblies/interface_internals.snbt" />

  <BoxAnnotation color="#dddddd" min="1.3 0.3 1.3" max="9.7 1 1.7">
        Множество излучателей уровня для контроля нужного запаса
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1.3 4 1.3" max="9.7 4.7 1.7">
        Множество излучателей уровня для контроля нужного запаса
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1.3 1.3 1.3" max="9.7 2 1.7">
        Очень быстрые шины импорта — 1 стак за тик
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1.3 3 1.3" max="9.7 3.7 1.7">
        Очень быстрые шины экспорта — 1 стак за тик
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 2 1" max="10 3 2">
        9 отдельных внутренних слотов
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="15" />
</GameScene>

## Особые взаимодействия

<ItemLink id="storage_bus" /> на ненастроенном интерфейсе предоставит всё [сетевое хранилище](../ae2-mechanics/import-export-storage.md)
его сети шине — как если бы вся сеть была одним большим сундуком. Настройка хранения в слотах
интерфейса отключает это.

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/interface_storage.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Поставщики шаблонов на [подсетях](../ae2-mechanics/subnetworks.md) с ненастроенным интерфейсом
пропускают интерфейс и напрямую помещают в хранилище подсети — не заполняя интерфейс партиями,
и не отправляя следующую партию пока в машине нет места.

<GameScene zoom="6" background="transparent">
<ImportStructure src="../assets/assemblies/provider_interface_storage.snbt" />

<BoxAnnotation color="#dddddd" min="2.7 0 1" max="3 1 2">
        Интерфейс (должен быть плоским, не полноблочным)
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 0 0" max="1.3 1 4">
        Шины хранения
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="0 0 0" max="1 1 4">
        Места для подачи шаблонов (несколько машин или несколько сторон)
  </BoxAnnotation>

<IsometricCamera yaw="185" pitch="30" />
</GameScene>

## Варианты

Интерфейсы бывают двух видов: обычный и плоский ([субчасть](../ae2-mechanics/cable-subparts.md)).

*   Обычный интерфейс принимает и отдаёт предметы со всех сторон и обеспечивает сетевое соединение
    со всех сторон.
*   Плоский интерфейс — субчасть кабеля, несколько можно разместить на одном кабеле. Принимает
    и отдаёт через свою лицевую сторону, но не обеспечивает там сетевое соединение.

Переключение между вариантами — в верстаке.

## Настройки

Верхние слоты задают запас хранения. При перетаскивании предмета появляется гаечный ключ для
задания количества.

Правый клик с контейнером для жидкости — задать жидкость как фильтр.

При настройке слота на хранение внешние машины не смогут вставлять что-либо ещё в этот слот.

## Улучшения

*   <ItemLink id="fuzzy_card" /> фильтрация по прочности и/или игнорирование NBT
*   <ItemLink id="crafting_card" /> позволяет отправлять запросы [автокрафта](../ae2-mechanics/autocrafting.md)

## Приоритет

Задаётся гаечным ключом в правом верхнем углу. Интерфейсы с высоким приоритетом получают предметы раньше.

## Рецепты

<Recipe id="network/blocks/interfaces_interface" />

<RecipeFor id="cable_interface" />
