---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Шаблоны
  icon: crafting_pattern
  position: 410
categories:
- tools
item_ids:
- ae2:blank_pattern
- ae2:crafting_pattern
- ae2:processing_pattern
- ae2:smithing_table_pattern
- ae2:stonecutting_pattern
---

# Шаблоны

<ItemImage id="crafting_pattern" scale="4" />

Шаблоны создаются в <ItemLink id="pattern_encoding_terminal" /> из пустых шаблонов и вставляются
в <ItemLink id="pattern_provider" /> или <ItemLink id="molecular_assembler" />.

Существует несколько типов шаблонов:

*   <ItemLink id="crafting_pattern" /> кодирует рецепты верстака. Можно вставить напрямую в
    <ItemLink id="molecular_assembler" /> — он будет крафтить результат при получении ингредиентов.
    Основное применение — в <ItemLink id="pattern_provider" /> рядом со сборщиком.

***

*   <ItemLink id="smithing_table_pattern" /> — как шаблон крафта, но для кузнечного стола.
    Автоматизируется через поставщик и сборщик. Шаблоны крафта, кузницы и камнерезного станка
    можно использовать в одной установке.

***

*   <ItemLink id="stonecutting_pattern" /> — как шаблон крафта, но для камнерезного станка.
    Работает в той же установке.

***

*   <ItemLink id="processing_pattern" /> — источник гибкости автокрафта. Самый обобщённый тип:
    «если поставщик вытолкнет эти ингредиенты, система когда-нибудь получит обратно вот это».
    Так автоматизируется практически любая машина. Системе всё равно, что происходит между выдачей
    ингредиентов и получением результата. Можно написать «1 вишнёвая доска = 1 звезда незера» и убивать
    визера при получении доски — и это сработает.

Несколько поставщиков с одинаковыми шаблонами работают параллельно. Можно задать шаблон «8 булыжников =
8 камня» вместо «1 = 1» — поставщик будет вставлять 8 за операцию.

## Рецепт

<RecipeFor id="blank_pattern" />
