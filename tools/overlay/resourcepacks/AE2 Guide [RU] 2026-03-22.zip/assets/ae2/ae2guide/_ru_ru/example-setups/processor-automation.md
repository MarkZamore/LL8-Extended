---
navigation:
  parent: example-setups/example-setups-index.md
  title: Автоматизация производства процессоров
  icon: logic_processor
---

# Автоматизация производства процессоров

Есть много способов автоматизировать [процессоры](../items-blocks-machines/processors.md). Этот метод
можно реализовать с любыми трубами для предметов, если они поддерживают фильтры.

![Схема потока](../assets/diagrams/processor_flow_diagram.png)

Ниже — реализация только на AE2, с помощью [«трубных» подсетей](pipe-subnet.md).

Поскольку используется <ItemLink id="pattern_provider" />, схема интегрируется в [автокрафт](../ae2-mechanics/autocrafting.md).

## О кодировании шаблонов

Нужный вам шаблон **НЕ СОВПАДЁТ С ТЕМ, ЧТО ПОКАЗЫВАЕТ JEI**. JEI создаёт 2 отдельных шаблона:
один для схем, один для финальной сборки — и шаблон схем включает [пресс](../items-blocks-machines/presses.md).
Нам нужен **1 шаблон**: сырые ресурсы → готовый процессор, без пресса в составе.

---

<GameScene zoom="4" interactive={true}>
  <ImportStructure src="../assets/assemblies/processor_automation.snbt" />

  <BoxAnnotation color="#dddddd" min="5 1 0" max="6 2 1" thickness=".05">
        (1) Поставщик шаблонов: стандартная конфигурация с нужными шаблонами обработки.
        <Row>
            ![Шаблон логики](../assets/diagrams/logic_pattern_small.png)
            ![Шаблон вычислений](../assets/diagrams/calculation_pattern_small.png)
            ![Инженерный шаблон](../assets/diagrams/engineering_pattern_small.png)
        </Row>
  </BoxAnnotation>

<DiamondAnnotation pos="7 1.5 0.5" color="#00ff00">
        К основной сети
    </DiamondAnnotation>

  <IsometricCamera yaw="185" pitch="5" />
</GameScene>

## Шаблоны (от сырья до готового процессора, без прессов)

  ![Шаблон логики](../assets/diagrams/logic_pattern.png)
  ![Шаблон вычислений](../assets/diagrams/calculation_pattern.png)
  ![Инженерный шаблон](../assets/diagrams/engineering_pattern.png)

## Как работает

1. <ItemLink id="pattern_provider" /> подаёт ингредиенты в бочку.
2. Первая [трубная подсеть](pipe-subnet.md) (оранжевая) распределяет кремний, редстоун и нужный
   металл/кристалл/алмаз по соответствующим высекателям.
3. Первые четыре <ItemLink id="inscriber" /> производят печатный кремний и печатные схемы.
4. Вторая и третья подсети (зелёные) перемещают печатные схемы из первых четырёх высекателей в пятый.
5. Пятый <ItemLink id="inscriber" /> собирает [процессор](../items-blocks-machines/processors.md).
6. Четвёртая подсеть (фиолетовая) кладёт процессор в поставщик шаблонов.
