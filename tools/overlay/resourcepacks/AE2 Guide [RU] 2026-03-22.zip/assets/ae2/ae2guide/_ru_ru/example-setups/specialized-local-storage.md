---
navigation:
  parent: example-setups/example-setups-index.md
  title: Специализированное локальное хранилище
  icon: drive
---

# Специализированное локальное хранилище

Используя [особое поведение интерфейса](../items-blocks-machines/interface.md#special-interactions),
[подсеть](../ae2-mechanics/subnetworks.md) может предоставить своё хранилище основной сети, не видя
хранилища основной сети. Используется только 1 [канал](../ae2-mechanics/channels.md).

Полезно для локального хранилища на ферме, чтобы предметы не переполняли основное хранилище.

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/local_storage.snbt" />

<BoxAnnotation color="#dddddd" min="4 0 0" max="5 2 1">
        (1) Способ импорта (в данном случае интерфейс)
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="3 0 0" max="4 1 1">
        (2) Накопитель: ячейки с фильтрами на вывод фермы. Можно добавить карты равного распределения и пустоты.
        <Row><ItemImage id="item_storage_cell_4k" scale="2" /> <ItemImage id="equal_distribution_card" scale="2" /> <ItemImage id="void_card" scale="2" /></Row>
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="3 1 0" max="4 2 0.3">
        (3) Терминал крафта: видит содержимое накопителя подсети, но не основного хранилища.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="2 0 0" max="2.3 1 1">
        (4) Интерфейс №2: стандартная конфигурация.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1.7 0 0" max="2 1 1">
        (5) Шина хранения: высокий приоритет, фильтр на вывод фермы.
  </BoxAnnotation>

<DiamondAnnotation pos="0 0.5 0.5" color="#00ff00">
        К основной сети
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Как работает

* Интерфейс на подсети показывает шине хранения на основной сети содержимое накопителя.
* Высокий приоритет шины → предметы предпочтительно возвращаются в подсеть.
* При заполнении ячеек предметы не переполняют основное хранилище.
* <ItemLink id="void_card" /> удаляет лишнее, <ItemLink id="equal_distribution_card" /> распределяет равномерно.
