---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Поставщик шаблонов
  icon: pattern_provider
  position: 210
categories:
- devices
item_ids:
- ae2:pattern_provider
- ae2:cable_pattern_provider
---

# Поставщик шаблонов

<Row gap="20">
<BlockImage id="pattern_provider" scale="8" />
<BlockImage id="pattern_provider" p:push_direction="up" scale="8" />
<GameScene zoom="8" background="transparent">
  <ImportStructure src="../assets/blocks/cable_pattern_provider.snbt" />
</GameScene>
</Row>

Поставщики шаблонов — основной способ взаимодействия [автокрафта](../ae2-mechanics/autocrafting.md)
с миром. Они выталкивают ингредиенты из [шаблонов](patterns.md) в соседние инвентари, и через них
можно добавлять предметы в сеть. Часто можно сэкономить канал, возвращая вывод машины обратно
в ближайший поставщик вместо использования <ItemLink id="import_bus" />.

Поставщик никогда не содержит ингредиенты в своём инвентаре — он берёт их из
[хранилища крафта](crafting_cpu_multiblock.md#crafting-storage). Извлечь из него нельзя.
Нужно чтобы поставщик вытолкнул в другой инвентарь (например, бочку), и уже оттуда брать трубами.

Поставщик должен вытолкнуть ВСЕ ингредиенты сразу — частичные партии не поддерживаются.
Это свойство можно использовать в своих целях.

На [подсетях](../ae2-mechanics/subnetworks.md) с ненастроенным интерфейсом поставщик пропускает
интерфейс и напрямую помещает в хранилище подсети, не заполняя интерфейс партиями.

Пример: эта установка подаёт и плавимый предмет, и топливо прямо в нужные слоты печи. Так можно
подавать через несколько сторон или в несколько машин.

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/furnace_automation.snbt" />

<BoxAnnotation color="#dddddd" min="1 0 0" max="2 1 1">
        (1) Поставщик шаблонов: направленный вариант (гаечным ключом) с нужными шаблонами обработки.
        ![Шаблон железа](../assets/diagrams/furnace_pattern_small.png)
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 1 0" max="2 1.3 1">
        (2) Интерфейс: в стандартной конфигурации.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 1 0" max="1.3 2 1">
        (3) Шина хранения №1: фильтр на уголь.
        <ItemImage id="minecraft:coal" scale="2" />
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="0 2 0" max="1 2.3 1">
        (4) Шина хранения №2: чёрный список угля (карта-инвертер).
        <Row><ItemImage id="minecraft:coal" scale="2" /><ItemImage id="inverter_card" scale="2" /></Row>
  </BoxAnnotation>

<DiamondAnnotation pos="4 0.5 0.5" color="#00ff00">
        К основной сети
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Несколько поставщиков с одинаковыми шаблонами работают параллельно.

Поставщик распределяет партии по всем своим сторонам, используя все присоединённые машины.

## Варианты

Три варианта: обычный, направленный и плоский ([субчасть](../ae2-mechanics/cable-subparts.md)).

* Обычный — выталкивает со всех сторон, принимает со всех, обеспечивает сетевое соединение со всех сторон.
* Направленный — гаечным ключом задаётся направление. Выталкивает только через выбранную сторону,
  не обеспечивает там сетевое соединение.
* Плоский — субчасть кабеля. Несколько можно поставить на один кабель.

Переключение обычный ↔ плоский — в верстаке.

## Настройки

*   **Режим блокировки** — не отправлять новую партию, пока в машине есть ингредиенты.
*   **Блокировка крафта** — блокировать при редстоун-условиях или до возврата результата.
*   Отображение / скрытие в <ItemLink id="pattern_access_terminal" />.

## Приоритет

При нескольких [шаблонах](patterns.md) для одного предмета используются шаблоны из поставщиков
с высшим приоритетом — если в сети есть нужные ингредиенты.

## Распространённое заблуждение

По какой-то причине люди делают следующее, хотя это не работает:

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../assets/assemblies/provider_misconception_1.snbt" />
  <BoxAnnotation color="#dddddd" min="1 0 3" max="2 1 4">
        Не доменная печь
  </BoxAnnotation>
  <IsometricCamera yaw="95" pitch="5" />
</GameScene>

Кабели — не трубы для предметов. Поставщик не может ничего вытолкнуть в кабель. Он просто работает
как кабель, соединяя шину экспорта с сетью. Поставщик также не «говорит» шине экспорта, что экспортировать.

То, что нужно сделать:

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../assets/assemblies/provider_misconception_3.snbt" />
  <BoxAnnotation color="#dddddd" min="1 0 3" max="2 1 4">
        Не доменная печь
  </BoxAnnotation>
  <IsometricCamera yaw="95" pitch="5" />
</GameScene>

## Использование с молекулярными сборщиками

<ItemLink id="molecular_assembler" /> — как любая другая машина. У него есть инвентарь для вставки,
он выполняет операцию и выталкивает результат в соседние инвентари. Используйте его с поставщиками
как любую другую машину, с одним дополнением:

Сборщики могут получить нужный шаблон от вставленного шаблона, поэтому поставщики умеют передавать
данные о шаблоне вместе с ингредиентами. Просто поставьте сборщик рядом с поставщиком — и поставщик
сможет использовать его для всех шаблонов крафта, кузницы и камнереза.

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/assembler_tower.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

*Ровно 8 поставщиков — максимум каналов через один сборщик, поставщик или обычный кабель.*

## Рецепты

<RecipeFor id="pattern_provider" />

<RecipeFor id="cable_pattern_provider" />
