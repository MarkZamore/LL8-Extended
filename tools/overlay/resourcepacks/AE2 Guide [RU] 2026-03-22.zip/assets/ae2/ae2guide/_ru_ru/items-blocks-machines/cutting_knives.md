---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Режущие ножи
  icon: certus_quartz_cutting_knife
  position: 410
categories:
- tools
item_ids:
- ae2:certus_quartz_cutting_knife
- ae2:nether_quartz_cutting_knife
---

# Режущие ножи

<Row>
  <ItemImage id="certus_quartz_cutting_knife" scale="4" />

  <ItemImage id="nether_quartz_cutting_knife" scale="4" />
</Row>

Режущие ножи используются для создания <ItemLink id="name_press" /> и <ItemLink id="cable_anchor" />.

Чтобы скрафтить именующий пресс, кликните правой кнопкой с ножом и вставьте металлический слиток —
введите нужное имя и извлеките готовую пластину.

## Рецепты

<Row>
  <RecipeFor id="certus_quartz_cutting_knife" />

  <RecipeFor id="nether_quartz_cutting_knife" />
</Row>
