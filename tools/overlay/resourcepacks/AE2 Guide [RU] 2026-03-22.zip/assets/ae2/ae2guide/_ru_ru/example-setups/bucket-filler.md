---
navigation:
  parent: example-setups/example-setups-index.md
  title: Заполнение вёдер
  icon: minecraft:water_bucket
---

# Заполнение вёдер

См. также [Опустошение вёдер](bucket-emptier.md).

Поскольку используется <ItemLink id="pattern_provider" />, схема для [автокрафта](../ae2-mechanics/autocrafting.md).

**Часто это не нужно**, так как замена жидкостей в
[терминале кодирования шаблонов](../items-blocks-machines/terminals.md#pattern-encoding-terminal-ui)
позволяет использовать саму жидкость вместо ведра.

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/bucket_filler.snbt" />

<BoxAnnotation color="#dddddd" min="2 1 0" max="3 2 1">
        (1) Поставщик шаблонов: блокировка «При редстоун-сигнале», нужные шаблоны.
        <Row>
        ![Вода](../assets/diagrams/water_fill_pattern_small.png)
        ![Лава](../assets/diagrams/lava_fill_pattern_small.png)
        </Row>
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="3 1.1 0.1" max="3.2 1.9 0.9">
        (2) Интерфейс: стандартная конфигурация.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="3.1 1.1 0.8" max="3.9 1.9 1">
        (3) Шина хранения №1: стандартная конфигурация.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="4.05 1.05 0.8" max="4.95 1.95 1">
        (4) Плоскость формирования: чёрный список вёдер (карта-инвертер).
        <Row><ItemImage id="minecraft:bucket" scale="2" /><ItemImage id="inverter_card" scale="2" /></Row>
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="3.2 2 1.2" max="3.8 2.2 1.8">
        (5) Шина импорта: чёрный список вёдер (карта-инвертер).
        <Row><ItemImage id="minecraft:bucket" scale="2" /><ItemImage id="inverter_card" scale="2" /></Row>
  </BoxAnnotation>

<DiamondAnnotation pos="0 1.5 0.5" color="#00ff00">
        К основной сети
    </DiamondAnnotation>

  <IsometricCamera yaw="225" pitch="45" />
</GameScene>

## Как работает

1. Поставщик подаёт ингредиенты: ведро — через диспенсер, жидкость — через плоскость формирования.
2. Компаратор видит ведро → включает диспенсер и блокирует поставщика.
3. Диспенсер зачерпывает жидкость, теперь в нём заполненное ведро.
4. Шина импорта (чёрный список вёдер, т.е. тянет только заполненные) извлекает ведро и возвращает в сеть.
5. Компаратор видит пустой диспенсер → разблокирует поставщика.
