---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: Выращивание кварца
  icon: quartz_cluster
---

# Выращивание истинного кварца

## В основном скопировано со страницы «Начало работы»

<GameScene zoom="6" background="transparent">
<ImportStructure src="../assets/assemblies/budding_certus_1.snbt" />
</GameScene>

Бутоны истинного кварца прорастают из [цветущих блоков истинного кварца](../items-blocks-machines/budding_certus.md),
аналогично аметисту. Если сломать недоросший бутон, выпадет одна <ItemLink id="certus_quartz_dust" /> — удача
не влияет. Если сломать полностью выросший кластер, выпадут четыре <ItemLink id="certus_quartz_crystal" />,
а удача увеличит их количество.

Существует 4 уровня цветущих блоков: Безупречный, Несовершенный, Треснутый и Повреждённый. Изначально
их можно найти в [метеоритах](../ae2-mechanics/meteorites.md).

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/budding_blocks.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Каждый раз, когда бутон вырастает на одну стадию, цветущий блок с некоторой вероятностью деградирует
на один уровень, в конечном счёте превращаясь в обычный блок истинного кварца. Восстановить блок
(и создать новые цветущие блоки) можно, бросив его (или обычный блок истинного кварца) в воду вместе
с одним или несколькими <ItemLink id="charged_certus_quartz_crystal" />.

<RecipeFor id="damaged_budding_quartz" />

Безупречные цветущие блоки не деградируют и бесконечно генерируют кварц. Однако их нельзя скрафтить
и нельзя переместить киркой — даже с шёлковым касанием. (Их *можно* переместить с помощью
[пространственного хранилища](../ae2-mechanics/spatial-io.md).)

Сами по себе бутоны растут очень медленно. К счастью, <ItemLink id="growth_accelerator" /> значительно
ускоряет этот процесс, если установить его рядом с цветущим блоком. Это должно быть вашим первым приоритетом.

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/budding_certus_2.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Из-за сложных взаимодействий каждая закрытая сторона цветущего блока снижает суммарную скорость роста,
что в итоге перевешивает эффект дополнительных ускорителей. Результаты практических тестов:

![Предметов/мин при разных соотношениях](../assets/diagrams/certus_farm_speed_chart_1.png)

![Распространённые схемы](../assets/diagrams/certus_farm_speed_chart_2.png)

Если кварца не хватает ещё и на <ItemLink id="energy_acceptor" /> или <ItemLink id="vibration_chamber" />,
можно скрафтить <ItemLink id="crank" /> и установить его на конец ускорителя.

Автоматическую сборку урожая кварца можно найти [здесь](../example-setups/simple-certus-farm.md).
