---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Пространственный пилон
  icon: spatial_pylon
  position: 210
categories:
- devices
item_ids:
- ae2:spatial_pylon
---

# Пространственный пилон

<BlockImage id="spatial_pylon" p:powered_on="true" scale="8" />

Используется в [пространственном хранилище](../ae2-mechanics/spatial-io.md) для генерации
пространственного поля и определения перемещаемого объёма.

Каждая непрерывная линия пилонов использует 1 [канал](../ae2-mechanics/channels.md).

Линии пилонов должны быть не менее 2 блоков в длину.

## Рецепт

<RecipeFor id="spatial_pylon" />
