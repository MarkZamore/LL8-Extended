---
navigation:
  parent: example-setups/example-setups-index.md
  title: Простая ферма кварца
  icon: certus_quartz_crystal
  position: 110
---

# Простая ферма истинного кварца

Как описано в разделе [Выращивание кварца](../ae2-mechanics/certus-growth.md), автоматизация сбора
<ItemLink id="certus_quartz_crystal" /> использует <ItemLink id="annihilation_plane" /> и
<ItemLink id="storage_bus" />. <ItemLink id="growth_accelerator" /> резко ускоряют рост бутонов,
после чего плоскости ломают выросшие <ItemLink id="quartz_cluster" />. Фильтрация достигается
за счёт того, что недоросшие бутоны выдают <ItemLink id="certus_quartz_dust" />, а не ничего.

Ферма полностью автоматически работает с <ItemLink id="flawless_budding_quartz" />, но с несовершенными,
треснутыми и повреждёнными блоками придётся вручную заменять исчерпавшийся блок. Или настроить
[полуавтоматическую](semiauto-certus-farm.md) или [продвинутую](advanced-certus-farm.md) ферму.

Оценку скоростей смотри в [Выращивание кварца](../ae2-mechanics/certus-growth.md).

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/simple_certus_farm.snbt" />

  <BoxAnnotation color="#dddddd" min="3.7 1 1" max="4 2 2">
        (1) Плоскость уничтожения: интерфейса нет, но можно зачаровать удачей.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="3 1 1" max="3.3 2 2">
        (2) Шина хранения №1: фильтр на кристалл истинного кварца.
        <ItemImage id="certus_quartz_crystal" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="3 1 .7" max="2 2 1">
        (3) Шина хранения №2: фильтр на кристалл истинного кварца. Приоритет выше основного хранилища.
        <ItemImage id="certus_quartz_crystal" scale="2" />
  </BoxAnnotation>

<DiamondAnnotation pos="1 0.5 0.5" color="#00ff00">
        К основной сети
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Настройки

* Первая <ItemLink id="annihilation_plane" /> (1) без интерфейса, но можно зачаровать удачей.
* Первая <ItemLink id="storage_bus" /> (2) — фильтр на <ItemLink id="certus_quartz_crystal" />.
* Вторая <ItemLink id="storage_bus" /> (3) — фильтр на <ItemLink id="certus_quartz_crystal" />,
  [приоритет](../ae2-mechanics/import-export-storage.md#storage-priority) выше основного хранилища.

## Как работает

1. <ItemLink id="annihilation_plane" /> пытается сломать то, что перед ней. Сломать может только
   <ItemLink id="quartz_cluster" /> — единственное хранилище в подсети это <ItemLink id="storage_bus" />,
   отфильтрованная на <ItemLink id="certus_quartz_crystal" />.
2. Первая <ItemLink id="storage_bus" /> кладёт кристаллы в бочку.
3. Вторая <ItemLink id="storage_bus" /> открывает основной сети доступ к кристаллам в бочке. Высокий
   приоритет означает, что кристаллы предпочтительно попадают в бочку, а не в основное хранилище.
