---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Шаблон кузнечного стола флюиса
  icon: fluix_upgrade_smithing_template
  position: 410
categories:
- tools
item_ids:
- ae2:fluix_upgrade_smithing_template
---

<ItemImage id="fluix_upgrade_smithing_template" scale="8" />

# Шаблон кузнечного стола флюиса

В отличие от ванильных шаблонов, этот можно скрафтить с нуля.

Необходим для [инструментов из флюиса](fluix_tools.md).

## Рецепт

<RecipeFor id="fluix_upgrade_smithing_template" />
