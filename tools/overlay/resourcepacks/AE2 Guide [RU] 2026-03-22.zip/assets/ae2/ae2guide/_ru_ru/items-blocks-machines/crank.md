---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Рукоять
  icon: crank
  position: 310
categories:
- machines
item_ids:
- ae2:crank
---

# Рукоять

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/crank_on_stuff.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Рукоять используется для питания машин, когда нет доступа к другим источникам энергии (или к
<ItemLink id="energy_acceptor" />). Трудности раннего этапа игры — понимаете, да?

## Рецепт

<RecipeFor id="crank" />
