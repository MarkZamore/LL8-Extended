---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Кабельный якорь
  icon: cable_anchor
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:cable_anchor
---

# Кабельный якорь

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/cable_anchor.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Небольшие декоративные шипы на кабеле, которые можно использовать для предотвращения соединения кабелей,
создания лестниц из кабелей или придания кабелю вида, будто он прикреплён к окружающим стенам.
Также используются при крафте <ItemLink id="facade" />.

Кабельные якоря блокируют соединения на той стороне, к которой прикреплены.

По ним можно карабкаться как по лестнице.

## Рецепт

<RecipeFor id="cable_anchor" />
