---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: МЭ порт ввода/вывода
  icon: io_port
  position: 210
categories:
- devices
item_ids:
- ae2:io_port
---

# МЭ порт ввода/вывода

<BlockImage id="io_port" p:powered="true" scale="8" />

Порт ввода/вывода позволяет быстро заполнять или опустошать [ячейки хранения](../items-blocks-machines/storage_cells.md)
в [сетевое хранилище](../ae2-mechanics/import-export-storage.md) и обратно.

Поворачивается с помощью <ItemLink id="certus_quartz_wrench" />.

## Настройки

*   Порт можно настроить на перемещение ячейки в выходные слоты когда она пуста, полна или когда работа завершена.
*   При вставке <ItemLink id="redstone_card" /> появляются настройки редстоун-условий.
*   В центре интерфейса есть стрелка для выбора направления: из ячейки в сеть или из сети в ячейку.

## Улучшения

*   <ItemLink id="speed_card" /> увеличивает количество перемещаемых предметов за операцию
*   <ItemLink id="redstone_card" /> добавляет управление редстоуном

## Рецепт

<RecipeFor id="io_port" />
