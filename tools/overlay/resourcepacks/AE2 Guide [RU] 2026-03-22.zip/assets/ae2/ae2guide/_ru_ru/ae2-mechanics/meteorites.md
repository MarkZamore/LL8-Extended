---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: Метеориты
  icon: sky_stone_block
---

# Метеориты

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/meteor_interior.snbt" />
</GameScene>

Метеориты — отправная точка использования AE2. Они содержат ключевые материалы:
[цветущие блоки истинного кварца](../items-blocks-machines/budding_certus.md) различных типов
и <ItemLink id="mysterious_cube" /> в центре.

На странице [Начало работы](../getting-started.md) описано, что делать после того, как вы найдёте метеорит.

## Поиск метеоритов

Метеориты достаточно распространены и оставляют огромные кратеры в земле — возможно, вы уже встречали
несколько. Если нет — <ItemLink id="meteorite_compass" /> будет указывать в сторону ближайшего
таинственного куба.

![Кратер от метеорита](../assets/assemblies/meteorite-crater.png)
