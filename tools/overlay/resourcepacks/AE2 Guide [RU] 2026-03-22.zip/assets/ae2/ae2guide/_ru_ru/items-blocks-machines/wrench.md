---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Гаечные ключи
  icon: certus_quartz_wrench
  position: 410
categories:
- tools
item_ids:
- ae2:certus_quartz_wrench
- ae2:nether_quartz_wrench
---

# Гаечные ключи

<Row>
  <ItemImage id="certus_quartz_wrench" scale="4" />
  <ItemImage id="nether_quartz_wrench" scale="4" />
</Row>

Гаечные ключи используются для поворота устройств AE2 (правый клик) и разборки блоков AE2
(Shift+правый клик). [Субчасти](../ae2-mechanics/cable-subparts.md) можно снимать с кабеля, не разрушая
остальное (или снимать кабель, не разрушая субчасти).

Многие блоки AE2 можно поворачивать — даже если об этом не написано в руководстве.

## Рецепты

<Row>
  <RecipeFor id="certus_quartz_wrench" />
  <RecipeFor id="nether_quartz_wrench" />
</Row>
