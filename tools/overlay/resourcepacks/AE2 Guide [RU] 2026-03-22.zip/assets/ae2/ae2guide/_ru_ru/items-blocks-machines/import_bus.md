---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: МЭ шина импорта
  icon: import_bus
  position: 220
categories:
- devices
item_ids:
- ae2:import_bus
---

# Шина импорта

<GameScene zoom="8" background="transparent">
<ImportStructure src="../assets/blocks/import_bus.snbt" />
</GameScene>

Шина импорта извлекает предметы и жидкости из соседнего инвентаря и помещает их в
[сетевое хранилище](../ae2-mechanics/import-export-storage.md).

Для снижения нагрузки шина переходит в «спящий режим» при отсутствии импорта, и ускоряется до полной
скорости (4 операции в секунду) при успешном импорте.

Являются [субчастями кабеля](../ae2-mechanics/cable-subparts.md).

## Фильтрация

По умолчанию шина импортирует всё доступное. Предметы в слотах фильтра формируют белый список.

Предметы и жидкости можно перетаскивать в слоты из JEI/REI. Правый клик с контейнером для жидкости —
задать жидкость как фильтр.

## Улучшения

*   <ItemLink id="capacity_card" /> увеличивает количество слотов фильтра
*   <ItemLink id="speed_card" /> увеличивает количество перемещаемых предметов за операцию
*   <ItemLink id="fuzzy_card" /> фильтрация по прочности и/или игнорирование NBT
*   <ItemLink id="inverter_card" /> переключает фильтр с белого списка на чёрный
*   <ItemLink id="redstone_card" /> добавляет управление редстоуном

## Скорость

| Карт ускорения | Предметов за операцию |
|:---------------|:----------------------|
| 0              | 1                     |
| 1              | 8                     |
| 2              | 32                    |
| 3              | 64                    |
| 4              | 96                    |

## Рецепт

<RecipeFor id="import_bus" />
