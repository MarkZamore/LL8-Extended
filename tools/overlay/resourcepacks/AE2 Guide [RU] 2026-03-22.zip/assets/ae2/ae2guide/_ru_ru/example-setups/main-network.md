---
navigation:
  parent: example-setups/example-setups-index.md
  title: Пример «основной сети»
  icon: controller
---

# Пример «основной сети»

Многие другие схемы ссылаются на «основную сеть». Вот пример функциональной системы:

<GameScene zoom="2.5" interactive={true}>
  <ImportStructure src="../assets/assemblies/small_base_network.snbt" />

    <BoxAnnotation color="#33dd33" min="5 1 10" max="9 7 14" thickness="0.05">
        Большой кластер поставщиков и сборщиков для шаблонов крафта, камнереза и кузницы.
        Шахматный рисунок позволяет поставщикам использовать несколько сборщиков параллельно.
        Группы по 8 — каналы маршрутизируются правильно.
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="13 10 12" max="14 11 14" thickness="0.05">
        Большой контроллер не нужен — огромные кольца в базах других игроков просто для красоты.
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="13 12 13" max="14 13 14" thickness="0.05">
        Ячейка энергии — обязательна для сглаживания пиков потребления.
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="2 1 10" max="4 4 13" thickness="0.05">
        Используйте генератор из другого мода — AE2 создан для модпаков.
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="14 1 2" max="16 5 7" thickness="0.05">
        1-2 больших процессорных блока для крупных заданий и несколько маленьких для параллельных.
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="7.3 1 3.3" max="9.7 4 6" thickness="0.05">
        Ферма кварца.
    </BoxAnnotation>

    <BoxAnnotation color="#33dd33" min="10.3 1 2.3" max="12.7 3.7 5" thickness="0.05">
        Автоматизация бросания в воду.
    </BoxAnnotation>

  <IsometricCamera yaw="135" pitch="15" />
</GameScene>
