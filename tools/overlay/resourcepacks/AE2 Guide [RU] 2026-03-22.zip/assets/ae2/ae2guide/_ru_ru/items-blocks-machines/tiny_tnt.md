---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Крохотный динамит
  icon: tiny_tnt
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:tiny_tnt
---

# Крохотный динамит

<BlockImage id="tiny_tnt" scale="8" />

Маленький динамит для маленьких взрывов. Полезен для создания пар <ItemLink id="quantum_entangled_singularity" />.

В конфиге можно отключить разрушение блоков — тогда сингулярности можно делать без риска гриферства,
если ТНТ и криперы на сервере запрещены.

## Рецепт

<RecipeFor id="tiny_tnt" />
