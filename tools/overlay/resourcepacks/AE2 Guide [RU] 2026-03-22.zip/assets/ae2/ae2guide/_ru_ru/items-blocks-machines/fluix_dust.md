---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Флюисовая пыль
  icon: fluix_dust
  position: 010
categories:
- misc ingredients blocks
- network infrastructure
item_ids:
- ae2:fluix_dust
---

# Флюисовая пыль

<ItemImage id="fluix_dust" scale="4" />

<ItemLink id="fluix_crystal" />, измельчённый в <ItemLink id="inscriber" />. Используется при производстве
нескольких машин и компонентов AE2.

## Рецепт

<RecipeFor id="fluix_dust" />
