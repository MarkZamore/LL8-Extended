---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: Сетевые соединения
  icon: fluix_glass_cable
---

# Сетевые соединения

## Что такое «сеть»?

«Сеть» — это группа [устройств](../ae2-mechanics/devices.md), связанных блоками, способными передавать
[каналы](../ae2-mechanics/channels.md): [кабелями](../items-blocks-machines/cables.md) или полноблочными
машинами и [устройствами](../ae2-mechanics/devices.md)
(<ItemLink id="charger" />, <ItemLink id="interface" />, <ItemLink id="drive" /> и т.д.).
Технически даже один кабель уже является сетью.

## Отступление о расположении устройств

Для [устройств](../ae2-mechanics/devices.md), выполняющих конкретную сетевую функцию (например, <ItemLink id="interface" />,
добавляющий и извлекающий из [сетевого хранилища](../ae2-mechanics/import-export-storage.md);
<ItemLink id="level_emitter" />, читающий содержимое сетевого хранилища;
<ItemLink id="drive" /> как само сетевое хранилище и т.д.)
физическое расположение устройства **не имеет значения**.

Повторю: **физическое расположение устройства не имеет значения**. Важно только, к какой сети подключено
устройство.

## Сетевые соединения

Простой способ определить, что подключено к сети — использовать <ItemLink id="network_tool" />. Он покажет
все компоненты сети; если видите лишнее или не видите нужного — что-то не так.

Например, это — 2 отдельные сети:

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/2_networks_1.snbt" />

  <BoxAnnotation color="#915dcd" min="0 0 0" max="1 2 2">
        Сеть 1
  </BoxAnnotation>

<BoxAnnotation color="#5CA7CD" min="2 0 0" max="3 2 2">
        Сеть 2
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Это тоже 2 отдельные сети, потому что <ItemLink id="quartz_fiber" /> передаёт [энергию](../ae2-mechanics/energy.md),
не создавая сетевого соединения:

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/2_networks_2.snbt" />

  <BoxAnnotation color="#915dcd" min="0 0 0" max="1 2 2">
        Сеть 1
  </BoxAnnotation>

  <BoxAnnotation color="#5CA7CD" min="1.3 0 0" max="3 2 2">
        Сеть 2
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

А вот это — 1 сеть, а не 2. [Квантовый мост](../items-blocks-machines/quantum_bridge.md) работает как
беспроводной [плотный кабель](../items-blocks-machines/cables.md#dense-cable), поэтому оба его конца
находятся в одной сети:

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/actually_1_network.snbt" />

  <BoxAnnotation color="#915dcd" min="0 0 0" max="7 3 3">
        Всё — 1 сеть
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Это тоже 1 сеть — цвет кабеля не влияет на сетевые соединения, только запрещает соединение кабелей
разных цветов между собой. Все цвета соединяются с флюисовыми («бесцветными») кабелями:

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/actually_1_network_2.snbt" />

  <BoxAnnotation color="#915dcd" min="0 0 0" max="4 2 2">
        Всё — 1 сеть
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Соединения в контексте подсетей

[Подсети](../ae2-mechanics/subnetworks.md) используют сетевые соединения (а точнее — их *отсутствие*),
чтобы ограничить доступ [устройств](../ae2-mechanics/devices.md) к другим устройствам.

Подсеть — это просто отдельная сеть.

Например, в [автоматической установке для удачи на рудах](../example-setups/ore-fortuner.md) есть 3 отдельные
сети, каждая из которых выполняет определённую задачу:

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/ore_fortuner.snbt" />

  <BoxAnnotation color="#915dcd" min="0 0 2" max="3 1 3">
        Сеть 1 — работает как трубная подсеть: ограничивает доступ шины импорта, чтобы она «хранила»
        блоки руды через плоскости формирования.
  </BoxAnnotation>

  <BoxAnnotation color="#5CA7CD" min="0 0 0" max="3 1 1">
        Сеть 2 — ещё одна трубная подсеть: ограничивает доступ плоскостей уничтожения, чтобы они
        хранили добытые куски руды в бочке, а не в основной сети. Также не расходует каналы основной сети.
  </BoxAnnotation>

  <BoxAnnotation color="#82CD5C" min="2 0 1" max="4 1 2">
        Сеть 3 — основная сеть с хранилищем и крафтом. Здесь только снабжает энергией и специально
        *не* соединена с двумя подсетями.
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Соединения в контексте P2P

Один из вариантов [P2P-тоннеля](../items-blocks-machines/p2p_tunnels.md) переносит [каналы](channels.md)
вместо предметов, жидкостей или редстоун-сигнала — и это по какой-то причине путает людей. Сеть, на которой
смонтирован тоннель, не связана с сетью, которую тоннель переносит. Они *могут* быть одной сетью, но обычно нет.

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/p2p_channels_network_connection.snbt" />

  <BoxAnnotation color="#915dcd" min="0 0 0" max="1.98 2 1">
        Сеть 1 — переносимая сеть (обычно ваша основная сеть)
  </BoxAnnotation>

  <BoxAnnotation color="#5CA7CD" min="2.02 0 0" max="3.98 1 1">
        Сеть 2 — сеть, обслуживающая МЭ P2P-тоннели (обычно *не* основная сеть)
  </BoxAnnotation>

  <BoxAnnotation color="#915dcd" min="4.02 0 0" max="6 1 1">
        Сеть 1 — переносимая сеть (обычно ваша основная сеть)
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Менее очевидные соединения

В этом случае — всё 1 сеть, потому что <ItemLink id="pattern_provider" />, будучи полноблочным устройством,
работает как кабель, и <ItemLink id="inscriber" /> ведёт себя аналогично. Сетевое соединение проходит
через поставщика и высекатель:

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/pattern_provider_network_connection_1.snbt" />

  <BoxAnnotation color="#915dcd" min="0 0 0" max="4 2 2">
        Всё — 1 сеть
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Чтобы этого избежать (нужно для многих установок автокрафта с [подсетями](../ae2-mechanics/subnetworks.md)),
можно кликнуть по поставщику с <ItemLink id="certus_quartz_wrench" />, сделав его направленным —
тогда он не будет пропускать каналы через одну из сторон:

<Row gap="40">
<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/pattern_provider_network_connection_2.snbt" />

  <BoxAnnotation color="#915dcd" min="0 0 0" max="1.98 2 2">
        Сеть 1
  </BoxAnnotation>

  <BoxAnnotation color="#5CA7CD" min="2.02 0 0" max="4 2 2">
        Сеть 2
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/pattern_provider_directional_connection.snbt" />

  <BoxAnnotation color="#ee3333" min="1 .3 .3" max="1.3 .7 .7">
        Обратите внимание: кабель не соединяется
  </BoxAnnotation>

  <IsometricCamera yaw="255" pitch="30" />
</GameScene>
</Row>

Другие части, не обеспечивающие направленное сетевое соединение — большинство
[субчастей](../ae2-mechanics/cable-subparts.md) [устройств](../ae2-mechanics/devices.md), таких как
<ItemLink id="import_bus" />, <ItemLink id="storage_bus" /> и <ItemLink id="cable_interface" />:

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/subpart_no_connection.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>
