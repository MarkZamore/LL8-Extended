---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Карты улучшений
  icon: speed_card
  position: 410
categories:
- tools
item_ids:
- ae2:basic_card
- ae2:advanced_card
- ae2:redstone_card
- ae2:capacity_card
- ae2:void_card
- ae2:fuzzy_card
- ae2:speed_card
- ae2:inverter_card
- ae2:crafting_card
- ae2:equal_distribution_card
- ae2:energy_card
---

# Карты улучшений

<Row>
  <ItemImage id="redstone_card" scale="2" />
  <ItemImage id="capacity_card" scale="2" />
  <ItemImage id="void_card" scale="2" />
  <ItemImage id="fuzzy_card" scale="2" />
  <ItemImage id="speed_card" scale="2" />
  <ItemImage id="inverter_card" scale="2" />
  <ItemImage id="crafting_card" scale="2" />
  <ItemImage id="equal_distribution_card" scale="2" />
  <ItemImage id="energy_card" scale="2" />
</Row>

Карты улучшений меняют поведение [устройств](../ae2-mechanics/devices.md) и машин AE2: увеличивают
скорость, расширяют фильтр, добавляют редстоун-управление и т.д.

## Компоненты карт

<Row>
  <ItemImage id="basic_card" scale="2" />
  <ItemImage id="advanced_card" scale="2" />
</Row>

Карты крафтятся на основе базовой или продвинутой карты:

<Row>
  <RecipeFor id="basic_card" />
  <RecipeFor id="advanced_card" />
</Row>

## Карта редстоуна

<ItemImage id="redstone_card" scale="2" />

Добавляет редстоун-управление: переключение по высокому/низкому сигналу или по импульсу.

<RecipeFor id="redstone_card" />

## Карта вместимости

<ItemImage id="capacity_card" scale="2" />

Увеличивает количество слотов фильтра в шинах импорта, экспорта, хранения и плоскостях формирования.

<RecipeFor id="capacity_card" />

## Карта уничтожения при переполнении

<ItemImage id="void_card" scale="2" />

Применяется к [ячейкам хранения](storage_cells.md) через <ItemLink id="cell_workbench" />.
Уничтожает предметы при заполнении. Обязательно настройте разделы! С картой равного распределения
уничтожает предметы при заполнении конкретного раздела.

<RecipeFor id="void_card" />

## Карта нечёткого поиска

<ItemImage id="fuzzy_card" scale="2" />

Позволяет фильтровать по уровню прочности и/или игнорировать NBT. Например, экспортировать любые
железные топоры независимо от прочности, или только повреждённые алмазные мечи.

Таблица сравнения прочности:

| 25%           | Кирка 10% | Кирка 30% | Кирка 80% | Кирка 100% |
| ------------- | --------- | --------- | --------- | ---------- |
| Почти сломана | ✅         | \*\*\*\*  | \*\*\*\*  | \*\*\*\*   |
| Полная        | \*\*\*\*  | ✅         | ✅         | ✅          |

| Игнорировать  | Кирка 10% | Кирка 30% | Кирка 80% | Кирка 100% |
| ------------- | --------- | --------- | --------- | ---------- |
| Почти сломана | ✅         | ✅         | ✅         | ✅          |
| Полная        | ✅         | ✅         | ✅         | ✅          |

<RecipeFor id="fuzzy_card" />

## Карта ускорения

<ItemImage id="speed_card" scale="2" />

Ускоряет работу: шины импорта/экспорта перемещают больше за операцию, высекатели и сборщики работают быстрее.

<RecipeFor id="speed_card" />

## Карта-инвертер

<ItemImage id="inverter_card" scale="2" />

Переключает фильтр с белого списка на чёрный.

<RecipeFor id="inverter_card" />

## Карта изготовления

<ItemImage id="crafting_card" scale="2" />

Позволяет устройству отправлять запросы [автокрафта](../ae2-mechanics/autocrafting.md).

<RecipeFor id="crafting_card" />

## Карта равного распределения

<ItemImage id="equal_distribution_card" scale="2" />

Применяется к [ячейкам хранения](storage_cells.md) через <ItemLink id="cell_workbench" />. Делит
ячейку на равные секции по настроенным [разделам](cell_workbench.md) — один тип не занимает всё место.

<RecipeFor id="equal_distribution_card" />

## Карта энергии

<ItemImage id="energy_card" scale="2" />

Добавляет запас энергии переносным терминалам и повышает КПД <ItemLink id="vibration_chamber" />.

<RecipeFor id="energy_card" />
