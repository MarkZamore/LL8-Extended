---
navigation:
  parent: example-setups/example-setups-index.md
  title: Автоматическое применение удачи к рудам
  icon: minecraft:raw_iron
---

# Автоматизация применения удачи к рудам

<ItemLink id="annihilation_plane" /> можно зачаровать любым зачарованием кирки, включая удачу.
Очевидное применение — несколько плоскостей с удачей, которые быстро размещают и ломают руды с помощью
<ItemLink id="formation_plane" /> и <ItemLink id="annihilation_plane" />.

Учтите, что шины импорта «разгоняются» — установка поначалу работает медленно, затем выходит на полную скорость.

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/ore_fortuner.snbt" />

  <BoxAnnotation color="#dddddd" min="2.7 0 2" max="3 1 3">
        (1) Шина импорта: несколько карт ускорения.
        <ItemImage id="speed_card" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="0 0 2" max="2 1 2.3">
        (2) Плоскости формирования: стандартная конфигурация.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="0 0 0.7" max="2 1 1">
        (3) Плоскости уничтожения: зачарованы удачей.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2.7 0 0" max="3 1 1">
        (4) Шина хранения: стандартная конфигурация.
  </BoxAnnotation>

<DiamondAnnotation pos="3.5 0.5 2.5" color="#00ff00">
        Вход
    </DiamondAnnotation>

<DiamondAnnotation pos="3.5 0.5 0.5" color="#00ff00">
        Выход
    </DiamondAnnotation>

<DiamondAnnotation pos="4 0.5 1.5" color="#00ff00">
        К основной сети
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Как работает

1. <ItemLink id="import_bus" /> в зелёной подсети тянет блоки из первой бочки в [сетевое хранилище](../ae2-mechanics/import-export-storage.md).
2. Единственное хранилище в зелёной подсети — <ItemLink id="formation_plane" />, которая размещает блоки.
3. <ItemLink id="annihilation_plane" /> в оранжевой подсети ломает блоки с удачей.
4. <ItemLink id="storage_bus" /> в оранжевой подсети кладёт результаты во вторую бочку.
