---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Карта памяти
  icon: memory_card
  position: 410
categories:
- tools
item_ids:
- ae2:memory_card
---

# Карта памяти

<ItemImage id="memory_card" scale="4" />

Карта памяти используется для копирования и вставки настроек между [устройствами](../ae2-mechanics/devices.md)
AE2, а также для связывания [P2P-тоннелей](p2p_tunnels.md). Может вставлять [карты улучшений](upgrade_cards.md)
в устройства.

- Shift+правый клик — скопировать настройки или создать новую частоту связи P2P.
- Правый клик — вставить настройки, карты улучшений или частоту связи.

## Рецепт

<RecipeFor id="memory_card" />
