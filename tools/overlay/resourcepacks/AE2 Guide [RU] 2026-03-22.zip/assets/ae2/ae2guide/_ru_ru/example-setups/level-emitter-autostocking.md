---
navigation:
  parent: example-setups/example-setups-index.md
  title: Автопополнение через излучатель уровня
  icon: level_emitter
---

# Автопополнение через излучатель уровня

Как поддерживать большое количество одного предмета с автокрафтом по мере нужды?

Вариант с <ItemLink id="export_bus" />, <ItemLink id="level_emitter" /> и <ItemLink id="crafting_card" />.
Чтобы крафтить непрерывно — просто уберите излучатель и карту редстоуна.

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/level_emitter_autostocking.snbt" />

  <BoxAnnotation color="#dddddd" min="1 1 0" max="2 1.3 1">
        (1) Шина экспорта: фильтр на нужный предмет. Карта редстоуна и карта изготовления.
        Режим редстоуна «Активна при сигнале», поведение крафта «Не использовать запасы».
        <Row><ItemImage id="redstone_card" scale="2" /> <ItemImage id="crafting_card" scale="2" /></Row>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="0.7 1 0" max="1 2 1">
        (2) Излучатель уровня: нужный предмет и количество, режим «Излучать ниже лимита».
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 0 0" max="2 1 1">
        (3) Интерфейс: стандартная конфигурация.
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Как работает

1. Если количество предмета ниже заданного — <ItemLink id="level_emitter" /> испускает редстоун.
2. При сигнале (и с <ItemLink id="crafting_card" /> и режимом «не использовать запасы»)
   <ItemLink id="export_bus" /> запрашивает автокрафт и экспортирует результат.
3. Интерфейс (без настроенного хранения) кладёт предмет в сетевое хранилище.
