---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Таинственный куб
  icon: mysterious_cube
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:mysterious_cube
- ae2:not_so_mysterious_cube
---

# Таинственный куб

<BlockImage id="mysterious_cube" scale="8" />

Помните, когда приходилось искать несколько метеоритов для всех прессов? Больше не нужно! Теперь
в метеоритах есть Таинственный куб.

Интересно, что произойдёт, если сломать его (без шёлкового касания)...

Можно также создать копию — Не Такой Уж Таинственный Куб.

## Рецепт

<RecipeFor id="not_so_mysterious_cube" />
