---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Кварцевое волокно
  icon: quartz_fiber
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:quartz_fiber
---

# Кварцевое волокно

<GameScene zoom="8" background="transparent">
<ImportStructure src="../assets/assemblies/quartz_fiber.snbt" />
<IsometricCamera yaw="195" pitch="30" />
</GameScene>

Кварцевое волокно передаёт энергию между [сетями](../ae2-mechanics/me-network-connections.md), не
объединяя их. Это позволяет питать [подсети](../ae2-mechanics/subnetworks.md) без прокладки отдельных
приёмщиков энергии и кабелей питания повсюду. Также может предотвращать соединение кабелей, хотя
разноцветные кабели или <ItemLink id="cable_anchor" /> дешевле и эффективнее.

Являются [субчастями кабеля](../ae2-mechanics/cable-subparts.md).

## Рецепт

<RecipeFor id="quartz_fiber" />
