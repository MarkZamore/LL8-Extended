---
navigation:
  parent: example-setups/example-setups-index.md
  title: Быстрое заполнение и опустошение ячеек
  icon: io_port
---

# Быстрое заполнение и опустошение ячеек

Как быстро опустошить ячейку в сундук/ящик/рюкзак или, наоборот, заполнить ячейку?

Используйте <ItemLink id="io_port" /> и подсеть для ограничения мест назначения.

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/cell_dumper_filler.snbt" />

<BoxAnnotation color="#dddddd" min="1 1 0" max="2 2 1">
        (1) Порт ввода/вывода: направление задаётся стрелкой в интерфейсе. Имеет 3 карты ускорения.
        <ItemImage id="speed_card" scale="2" />
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="0 0.7 0" max="1 1 1">
        (2) Шина хранения: стандартная конфигурация.
  </BoxAnnotation>

<BoxAnnotation color="#33dd33" min="0 1 0" max="1 2 1">
        Сюда кладётся то, что нужно заполнить или опустошить.
  </BoxAnnotation>

<DiamondAnnotation pos="3 0.5 0.5" color="#00ff00">
        К источнику энергии (другая сеть или приёмщик энергии).
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Как работает

**Режим «В сеть»:** Порт выгружает содержимое ячейки. Единственное хранилище — шина хранения,
которая кладёт предметы в подставленный инвентарь.

**Режим «В ячейку»:** Порт заполняет ячейку. Единственное хранилище — шина хранения, которая
тянет предметы из подставленного инвентаря.

Ячейка энергии обеспечивает достаточный буфер для массовой передачи за один тик.
