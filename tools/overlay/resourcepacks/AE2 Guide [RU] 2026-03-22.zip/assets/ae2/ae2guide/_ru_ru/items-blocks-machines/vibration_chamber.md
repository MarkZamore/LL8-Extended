---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Резонирующая камера
  icon: vibration_chamber
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:vibration_chamber
---

# Резонирующая камера

<BlockImage id="vibration_chamber" p:active="true" scale="8" />

Хотя основной способ питания сети — <ItemLink id="energy_acceptor" />, резонирующая камера может
сама генерировать небольшое или среднее количество AE.

По умолчанию производит 40 AE/т.

При заполненном хранилище [энергии](../ae2-mechanics/energy.md) камера снижает интенсивность для
экономии топлива, но полностью не выключается.

## Настройки

*   Переключатель отображения энергии в AE или E/FE

## Улучшения

*   <ItemLink id="energy_card" /> увеличивает КПД камеры на +50%, максимум до +150% (250% от базового)
*   <ItemLink id="speed_card" /> увеличивает скорость сжигания на +50%, максимум до +150%

## Конфиг

В файле common.json в папке ae2 в конфиге:
*   baseEnergyPerFuelTick — базовый КПД без улучшений
*   minEnergyPerGameTick — минимальная генерация (камера всегда медленно сжигает топливо)
*   maxEnergyPerGameTick — максимальная мощность без улучшений

## Рецепт

<RecipeFor id="vibration_chamber" />
