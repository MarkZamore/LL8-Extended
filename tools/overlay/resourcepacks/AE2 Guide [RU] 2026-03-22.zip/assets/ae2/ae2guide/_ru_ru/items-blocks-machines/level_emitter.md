---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Излучатель уровня
  icon: level_emitter
  position: 220
categories:
- devices
item_ids:
- ae2:level_emitter
- ae2:energy_level_emitter
---

# Излучатель уровня

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../assets/blocks/level_emitter.snbt" />
</GameScene>

Излучатель уровня испускает редстоун-сигнал в зависимости от количества предмета в
[сетевом хранилище](../ae2-mechanics/import-export-storage.md).

Также существует версия, реагирующая на количество [энергии](../ae2-mechanics/energy.md) в сети.

Являются [субчастями кабеля](../ae2-mechanics/cable-subparts.md).

В отличие от других [устройств](../ae2-mechanics/devices.md), излучатели уровня **не требуют** [канала](../ae2-mechanics/channels.md).

## Настройки

*   Можно задать режим «больше или равно» / «меньше»
*   При вставке <ItemLink id="crafting_card" /> — режим «испускать сигнал пока предмет крафтится»
    или «испускать сигнал для крафта предмета»

## Улучшения

*   <ItemLink id="fuzzy_card" /> фильтрация по прочности и/или игнорирование NBT
*   <ItemLink id="crafting_card" /> включает функцию крафта

## Функция крафта

При вставке <ItemLink id="crafting_card" /> излучатель переходит в режим крафта с двумя опциями:

**«Испускать сигнал пока предмет крафтится»** — полезно для включения энергоёмких установок только
при их активном использовании.

**«Испускать сигнал для крафта предмета»** — создаёт виртуальный [шаблон](patterns.md) для
[автокрафта](../ae2-mechanics/autocrafting.md). Не требует ингредиентов и не определяет их.
Говорит просто: «если от этого излучателя идёт редстоун, система когда-нибудь получит этот предмет».
Используется для бесконечных ферм и обработки рекурсивных рецептов.
(Реальный шаблон на тот же предмет в поставщиках **не должен** существовать.)

## Рецепт

<RecipeFor id="level_emitter" />

<RecipeFor id="energy_level_emitter" />
