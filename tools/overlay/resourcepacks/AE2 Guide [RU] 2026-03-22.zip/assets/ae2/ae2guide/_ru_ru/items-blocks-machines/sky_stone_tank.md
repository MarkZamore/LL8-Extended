---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Бак из небесного камня
  icon: sky_stone_tank
  position: 310
categories:
- machines
item_ids:
- ae2:sky_stone_tank
---

# Бак из небесного камня

<BlockImage id="sky_stone_tank" scale="8" />

Бак для жидкостей на 16 вёдер. Не сохраняет содержимое при поднятии. Больше нечего добавить.

## Рецепт

<RecipeFor id="sky_stone_tank" />
