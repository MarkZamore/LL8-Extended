---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Кварцевое стекло
  icon: quartz_glass
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:quartz_glass
- ae2:quartz_vibrant_glass
---

# Кварцевое стекло

<BlockImage id="quartz_glass" scale="8" />

Практически прозрачное стекло из <ItemLink id="certus_quartz_dust" />. Используется во многих
машинах и предметах AE2.

Существует вариант — резонирующее кварцевое стекло, испускающее свет.

## Рецепты

<RecipeFor id="quartz_glass" />

<RecipeFor id="quartz_vibrant_glass" />
