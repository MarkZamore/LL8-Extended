---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Приёмщик энергии
  icon: energy_acceptor
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:energy_acceptor
---

# Приёмщик энергии

<Row gap="20">
<BlockImage id="energy_acceptor" scale="8" />

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../assets/blocks/cable_energy_acceptor.snbt" />
</GameScene>
</Row>

Приёмщик энергии конвертирует распространённые виды энергии из других технических модов во внутреннюю
[энергию](../ae2-mechanics/energy.md) AE2 — AE. Хотя <ItemLink id="controller" /> тоже умеет это делать,
стороны контроллера ценны, поэтому приёмщик предпочтительнее.

Коэффициенты конвертации:

*   2 FE = 1 AE (Forge)
*   1 E  = 2 AE (Fabric)

Скорость конвертации полностью зависит от того, сколько AE может хранить сеть — подробности
на [этой странице](../ae2-mechanics/energy.md).

## Варианты

Приёмщики энергии бывают двух видов: обычный и плоский ([субчасть](../ae2-mechanics/cable-subparts.md)).
Это позволяет делать более компактные установки.

Переключение между вариантами — в верстаке.

## Рецепт

<RecipeFor id="energy_acceptor" />

<RecipeFor id="cable_energy_acceptor" />
