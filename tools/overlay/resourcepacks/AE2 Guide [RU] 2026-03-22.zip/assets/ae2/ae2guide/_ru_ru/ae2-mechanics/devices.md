---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: Устройства
  icon: interface
---

# Устройства

«Устройство» — это сетевой компонент AE2, выполняющий какую-либо функцию в сети. Почти все они требуют
канал, с заметным исключением в виде [излучателей уровня](../items-blocks-machines/level_emitter.md).

Примеры:

*   <ItemLink id="interface" />
*   <ItemLink id="import_bus" />
*   <ItemLink id="storage_bus" />
*   <ItemLink id="pattern_provider" />
*   <ItemLink id="drive" />
