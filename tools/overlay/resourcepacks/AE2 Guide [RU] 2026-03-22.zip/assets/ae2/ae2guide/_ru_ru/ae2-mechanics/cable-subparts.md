---
navigation:
  parent: ae2-mechanics/ae2-mechanics-index.md
  title: Субчасти кабеля
icon: fluix_glass_cable
---

# Субчасти кабеля

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/subparts_demonstration.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

В AE2 некоторые [устройства](devices.md) и компоненты можно размещать на кабелях в одном и том же блоке.
Это удобно для компактных установок. Зажав Shift и кликнув правой кнопкой мыши с <ItemLink id="certus_quartz_wrench" />
или <ItemLink id="network_tool" />, можно снять отдельную субчасть (или сам кабель), не разрушая всё остальное
в этом блоке.
