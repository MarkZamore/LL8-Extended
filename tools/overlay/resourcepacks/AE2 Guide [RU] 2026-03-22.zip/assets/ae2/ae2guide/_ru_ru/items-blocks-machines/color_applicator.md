---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Аппликатор цвета
  icon: color_applicator
  position: 410
categories:
- tools
item_ids:
- ae2:color_applicator
---

# Аппликатор цвета

<ItemImage id="color_applicator" scale="4" />

Аппликатор цвета используется для покраски окрашиваемых блоков — [кабелей](cables.md), шерсти, терракоты,
стекла и бетона. Использует [шарики краски](paintballs.md) или красители. Снежки снимают цвет с кабелей
и смывают пятна краски с блоков.

Энергию можно восстановить в <ItemLink id="charger" />.

Аппликаторы цвета работают как [ячейки хранения](storage_cells.md), и удобнее всего заполнять их краской,
вставив аппликатор в слот ячейки в <ItemLink id="chest" />.

Кликните правой кнопкой на цели для нанесения выбранного цвета. Для смены цвета крутите колёсико мыши
с зажатым Shift или кликните правой кнопкой без цели.

## Улучшения

Аппликаторы цвета поддерживают следующие [улучшения](upgrade_cards.md), вставляемые через <ItemLink id="cell_workbench" />:

*   <ItemLink id="equal_distribution_card" /> выделяет одинаковый объём байт ячейки каждому типу,
    чтобы один тип не занял всё место
*   <ItemLink id="void_card" /> уничтожает вставляемые предметы, если ячейка заполнена. Обязательно
    задайте разделы!
*   <ItemLink id="energy_card" /> увеличивает ёмкость батареи

## Рецепт

<RecipeFor id="color_applicator" />
