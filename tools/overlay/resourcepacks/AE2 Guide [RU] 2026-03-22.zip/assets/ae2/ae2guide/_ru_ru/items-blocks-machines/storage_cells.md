---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Ячейки хранения
  icon: item_storage_cell_1k
  position: 410
categories:
- tools
item_ids:
- ae2:item_cell_housing
- ae2:fluid_cell_housing
- ae2:cell_component_1k
- ae2:cell_component_4k
- ae2:cell_component_16k
- ae2:cell_component_64k
- ae2:cell_component_256k
- ae2:item_storage_cell_1k
- ae2:item_storage_cell_4k
- ae2:item_storage_cell_16k
- ae2:item_storage_cell_64k
- ae2:item_storage_cell_256k
- ae2:fluid_storage_cell_1k
- ae2:fluid_storage_cell_4k
- ae2:fluid_storage_cell_16k
- ae2:fluid_storage_cell_64k
- ae2:fluid_storage_cell_256k
---

# Ячейки хранения

<Column>
  <Row>
    <ItemImage id="item_storage_cell_1k" scale="4" />
    <ItemImage id="item_storage_cell_4k" scale="4" />
    <ItemImage id="item_storage_cell_16k" scale="4" />
    <ItemImage id="item_storage_cell_64k" scale="4" />
    <ItemImage id="item_storage_cell_256k" scale="4" />
  </Row>
  <Row>
    <ItemImage id="fluid_storage_cell_1k" scale="4" />
    <ItemImage id="fluid_storage_cell_4k" scale="4" />
    <ItemImage id="fluid_storage_cell_16k" scale="4" />
    <ItemImage id="fluid_storage_cell_64k" scale="4" />
    <ItemImage id="fluid_storage_cell_256k" scale="4" />
  </Row>
</Column>

Ячейки хранения — основной метод хранения в Applied Energistics. Вставляются в
<ItemLink id="drive" /> или <ItemLink id="chest" />.

Подробности о ёмкости в байтах и типах — на странице [Байты и типы](../ae2-mechanics/bytes-and-types.md).

Компоненты хранения можно извлечь из корпуса пустой ячейки Shift+правым кликом.

<Row>
    <Recipe id="upgrade/item_storage_cell_1k_to_4k" />
    Можно улучшать ячейки до более высокого уровня, объединяя их с компонентом более высокого уровня
    в верстаке. Содержимое сохраняется, компонент предыдущего уровня возвращается.
</Row>

## Ёмкость при разном числе типов

| Ячейка                                   | При 1 типе  | При 63 типах |
| ---------------------------------------- | ----------: | -----------: |
| <ItemLink id="item_storage_cell_1k" />   |       8 128 |        4 160 |
| <ItemLink id="item_storage_cell_4k" />   |      32 512 |       16 640 |
| <ItemLink id="item_storage_cell_16k" />  |     130 048 |       66 560 |
| <ItemLink id="item_storage_cell_64k" />  |     520 192 |      266 240 |
| <ItemLink id="item_storage_cell_256k" /> |   2 080 768 |    1 064 960 |

## Разбивка на разделы

Ячейки можно настроить на хранение только определённых предметов — через <ItemLink id="cell_workbench" />.

## Улучшения

*   <ItemLink id="fuzzy_card" /> (недоступно для жидкостных) фильтрация по прочности/NBT
*   <ItemLink id="inverter_card" /> переключает фильтр с белого на чёрный список
*   <ItemLink id="equal_distribution_card" /> равномерное распределение места между типами
*   <ItemLink id="void_card" /> уничтожает предметы при заполнении — полезно для ферм. Задайте разделы!
*   Переносные ячейки принимают <ItemLink id="energy_card" /> для увеличения заряда батареи

## Окраска

Переносные предметные и жидкостные ячейки можно красить как кожаную броню — крафт с красителями.

# Корпуса

<Row>
  <Recipe id="network/cells/item_storage_cell_1k" />
  <Recipe id="network/cells/item_storage_cell_1k_storage" />
</Row>

<Row>
  <RecipeFor id="item_cell_housing" />
  <RecipeFor id="fluid_cell_housing" />
</Row>

# Компоненты хранения

Основа всех ячеек AE2. Каждый уровень — x4 ёмкость, требует 3 предыдущего.

<Column>
  <Row>
    <RecipeFor id="cell_component_1k" />
    <RecipeFor id="cell_component_4k" />
    <RecipeFor id="cell_component_16k" />
  </Row>
  <Row>
    <RecipeFor id="cell_component_64k" />
    <RecipeFor id="cell_component_256k" />
  </Row>
</Column>

# Предметные ячейки хранения

До 63 типов предметов, все стандартные объёмы.

<Column>
  <Row>
    <Recipe id="network/cells/item_storage_cell_1k_storage" />
    <Recipe id="network/cells/item_storage_cell_4k_storage" />
    <Recipe id="network/cells/item_storage_cell_16k_storage" />
  </Row>
  <Row>
    <Recipe id="network/cells/item_storage_cell_64k_storage" />
    <Recipe id="network/cells/item_storage_cell_256k_storage" />
  </Row>
</Column>

## Переносные предметные ячейки

Работают как маленький <ItemLink id="chest" /> в кармане. Заряжаются в <ItemLink id="charger" />.
С увеличением объёма ёмкость типов снижается, а общий объём вдвое меньше стандартных.

<Column>
  <Row>
    <RecipeFor id="portable_item_cell_1k" />
    <RecipeFor id="portable_item_cell_4k" />
    <RecipeFor id="portable_item_cell_16k" />
  </Row>
  <Row>
    <RecipeFor id="portable_item_cell_64k" />
    <RecipeFor id="portable_item_cell_256k" />
  </Row>
</Column>

# Жидкостные ячейки хранения

До 5 типов жидкостей, все стандартные объёмы.

<Column>
  <Row>
    <Recipe id="network/cells/fluid_storage_cell_1k_storage" />
    <Recipe id="network/cells/fluid_storage_cell_4k_storage" />
    <Recipe id="network/cells/fluid_storage_cell_16k_storage" />
  </Row>
  <Row>
    <Recipe id="network/cells/fluid_storage_cell_64k_storage" />
    <Recipe id="network/cells/fluid_storage_cell_256k_storage" />
  </Row>
</Column>

## Переносные жидкостные ячейки

<Column>
  <Row>
    <RecipeFor id="portable_fluid_cell_1k" />
    <RecipeFor id="portable_fluid_cell_4k" />
    <RecipeFor id="portable_fluid_cell_16k" />
  </Row>
  <Row>
    <RecipeFor id="portable_fluid_cell_64k" />
    <RecipeFor id="portable_fluid_cell_256k" />
  </Row>
</Column>

# Творческая ячейка хранения

<Row>
  <ItemImage id="creative_storage_cell" scale="2" />
</Row>

Творческие ячейки **не дают бесконечного хранилища**. Они работают как бесконечный источник и сток
для любого предмета или жидкости, для которых [настроены разделы](cell_workbench.md).
