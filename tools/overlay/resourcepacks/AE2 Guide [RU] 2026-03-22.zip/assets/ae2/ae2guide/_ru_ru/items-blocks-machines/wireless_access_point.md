---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Беспроводная точка доступа
  icon: wireless_access_point
  position: 210
categories:
- devices
item_ids:
- ae2:wireless_booster
- ae2:wireless_access_point
---

# Беспроводная точка доступа

<BlockImage id="wireless_access_point" p:state="has_channel" scale="8" />

Обеспечивает беспроводной доступ через <ItemLink id="wireless_terminal" />.
Дальность действия и потребление энергии определяются количеством установленных
<ItemLink id="wireless_booster" />.

Сеть может иметь любое количество точек доступа с любым количеством усилителей — это позволяет
оптимизировать потребление энергии и дальность.

Требует [канал](../ae2-mechanics/channels.md).

Также используется для привязки [беспроводных терминалов](wireless_terminals.md).

# Беспроводной усилитель

<ItemImage id="wireless_booster" scale="2" />

Используется для увеличения дальности беспроводной точки доступа.

## Рецепты

<RecipeFor id="wireless_access_point" />

<RecipeFor id="wireless_booster" />
