---
navigation:
  parent: example-setups/example-setups-index.md
  title: Автопополнение через интерфейс
  icon: interface
---

# Автопополнение через интерфейс

Как поддерживать определённое количество разных предметов в запасе с автокрафтом по мере нужды?

Один из вариантов — <ItemLink id="interface" /> с <ItemLink id="crafting_card" /> для автоматического
запроса крафта из [автокрафта](../ae2-mechanics/autocrafting.md). Этот метод лучше подходит для
небольшого количества широкого ассортимента предметов.

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/interface_autostocking.snbt" />

<BoxAnnotation color="#dddddd" min="0 0 0" max="2 1 1">
        (1) Интерфейсы: настроены на хранение нужных предметов. Имеют карты изготовления.
        <ItemImage id="crafting_card" scale="2" />
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="0 1 0" max="2 1.3 1">
        (2) Шины хранения: режим «Только извлечение».
  </BoxAnnotation>

<DiamondAnnotation pos="4 0.5 0.5" color="#00ff00">
        К основной сети
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Как работает

1. Если <ItemLink id="interface" /> не может получить достаточно предмета из сетевого хранилища
   (и имеет <ItemLink id="crafting_card" />), он запрашивает автокрафт.
2. <ItemLink id="storage_bus" /> открывает основной сети доступ к содержимому интерфейсов.
