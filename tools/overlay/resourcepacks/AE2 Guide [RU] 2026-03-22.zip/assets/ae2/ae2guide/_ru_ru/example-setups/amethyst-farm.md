---
navigation:
  parent: example-setups/example-setups-index.md
  title: Ферма аметиста
  icon: minecraft:amethyst_shard
---

# Выращивание аметиста

<ItemLink id="growth_accelerator" /> работает с аметистом, но обычные методы фильтрации бутонов через
<ItemLink id="annihilation_plane" /> к аметисту не применимы. В отличие от незрелых бутонов кварца,
незрелые бутоны аметиста ничего не выдают — поэтому плоскость всегда их ломает.

Решение: зачаровать плоскость шёлковым касанием. Тогда незрелые бутоны дают физические блоки, и
их можно фильтровать. Затем <ItemLink id="minecraft:amethyst_cluster" /> нужно снова разместить через
<ItemLink id="formation_plane" /> и сломать без шёлкового касания для получения осколков.

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/amethyst_farm.snbt" />

  <BoxAnnotation color="#dddddd" min="2.7 1 1" max="3 2 2">
        (1) Плоскость уничтожения №1: шёлковое касание.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="2 1 1" max="2.3 2 2">
        (2) Плоскость формирования: фильтр на кластер аметиста.
        <ItemImage id="minecraft:amethyst_cluster" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1.3 0.7 1" max="2 1 2">
        (3) Плоскость уничтожения №2: можно зачаровать удачей.
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 0 1" max="1.3 1 2">
        (4) Шина хранения №1: фильтр на осколок аметиста.
        <ItemImage id="minecraft:amethyst_shard" scale="2" />
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="0 0 .7" max="1 1 1">
        (5) Шина хранения №2: фильтр на осколок аметиста. Приоритет выше основного хранилища.
        <ItemImage id="minecraft:amethyst_shard" scale="2" />
  </BoxAnnotation>

<DiamondAnnotation pos="0 0.5 0.5" color="#00ff00">
        К основной сети
    </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Как работает

1. Первая плоскость с шёлковым касанием ломает кластер аметиста (единственное возможное хранилище —
   плоскость формирования, фильтр на кластер).
2. Плоскость формирования размещает кластер на противоположном блоке.
3. Вторая плоскость ломает кластер, получая осколки аметиста.
4. Первая шина хранения кладёт осколки в бочку.
5. Вторая шина хранения даёт основной сети доступ к осколкам с высоким приоритетом.
