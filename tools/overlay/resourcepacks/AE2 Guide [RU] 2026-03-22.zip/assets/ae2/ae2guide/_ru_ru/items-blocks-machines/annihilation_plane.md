---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Плоскость уничтожения
  icon: annihilation_plane
  position: 210
categories:
- devices
item_ids:
- ae2:annihilation_plane
---

# Плоскость уничтожения

<GameScene zoom="8" background="transparent">
<ImportStructure src="../assets/blocks/annihilation_plane.snbt" />
</GameScene>

Плоскость уничтожения ломает блоки и подбирает предметы. Работает аналогично <ItemLink id="import_bus" />,
помещая предметы в [сетевое хранилище](../ae2-mechanics/import-export-storage.md). Чтобы подобрать предмет,
он должен столкнуться именно с лицевой стороной плоскости — подбор по области не работает.

На плоскость уничтожения можно наложить любые зачарования кирки: можно поставить безумные уровни удачи и
[автоматизировать переработку руд](../example-setups/ore-fortuner.md), если ваша сборка это позволяет.
Шёлковое касание работает как ожидается, эффективность снижает стоимость энергии на взлом блока,
а стойкость даёт шанс не тратить энергию.

Являются [субчастями кабеля](../ae2-mechanics/cable-subparts.md).

**НЕ ЗАБУДЬТЕ РАЗРЕШИТЬ ФЕЙКОВЫХ ИГРОКОВ В НАСТРОЙКАХ ЗАЩИТЫ ЧАНКОВ**

## Фильтрация

Плоскость уничтожения сломает блок или подберёт предмет только если может сохранить выпавшие предметы
в своей сети. Это значит, что для фильтрации *нужно ограничить, что именно может храниться в её сети* —
скорее всего, поместив её в [подсеть](../ae2-mechanics/subnetworks.md). Для этого можно
[разбить на разделы](cell_workbench.md) <ItemLink id="storage_bus" /> или
[ячейку](../items-blocks-machines/storage_cells.md).

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/annihilation_filtering.snbt" />

  <DiamondAnnotation pos="1 0.5 0.5" color="#00ff00">
        Фильтр задаётся по предметам, выпадающим из того, что нужно сломать.
  </DiamondAnnotation>

  <DiamondAnnotation pos=".5 0.5 2.5" color="#00ff00">
        Разбита на разделы по предметам, выпадающим из того, что нужно сломать.
  </DiamondAnnotation>

  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Ещё раз: фильтрация работает *по выпадающим предметам*. Например, чтобы фильтровать только ломание
<ItemLink id="minecraft:amethyst_cluster" />, нужна плоскость с шёлковым касанием — иначе каждая
предыдущая стадия роста не даёт ничего, и плоскость будет ломать её при любых настройках, так как сеть
всегда может «хранить» ничего.

## Рецепт

<RecipeFor id="annihilation_plane" />
