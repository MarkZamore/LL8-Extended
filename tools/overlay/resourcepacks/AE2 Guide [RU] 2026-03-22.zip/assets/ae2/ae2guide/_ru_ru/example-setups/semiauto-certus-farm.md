---
navigation:
  parent: example-setups/example-setups-index.md
  title: Полуавтоматическая ферма кварца
  icon: certus_quartz_crystal
  position: 115
---

# Полуавтоматическая ферма истинного кварца

К сожалению, [простая ферма](simple-certus-farm.md) требует <ItemLink id="flawless_budding_quartz" />
для полностью автоматической работы. Но AE2 умеет размещать и ломать блоки — можно сделать ферму,
которая **сама заменяет исчерпавшийся цветущий кварц** (вам только нужно периодически добавлять
<ItemLink id="flawed_budding_quartz" /> во входную бочку и извлекать <ItemLink id="quartz_block" />).

Для полностью автоматической версии — [Продвинутая ферма](advanced-certus-farm.md).

Ферма состоит из 3 отдельных подсетей.

**СЛОЖНАЯ ПОСТРОЙКА — ВРАЩАЙТЕ КАМЕРУ ДЛЯ ПРОСМОТРА**

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/semiauto_certus_farm.snbt" />

  <BoxAnnotation color="#ddaaaa" min="3.7 2 1" max="4 3 2">
        (1) Плоскость уничтожения №1: можно зачаровать удачей.
  </BoxAnnotation>

  <BoxAnnotation color="#ddaaaa" min="2 2 1" max="2.3 3 2">
        (2) Шина хранения №1: фильтр на кристалл истинного кварца.
        <ItemImage id="certus_quartz_crystal" scale="2" />
  </BoxAnnotation>

  <DiamondAnnotation pos="3 2.5 1.5" color="#ff0000">
    Подсеть разрушения кластеров
  </DiamondAnnotation>

  <BoxAnnotation color="#aaddaa" min="3.7 1 1" max="4 2 2">
        (3) Плоскость уничтожения №2: шёлковое касание обязательно.
  </BoxAnnotation>

  <BoxAnnotation color="#aaddaa" min="2 1 1" max="2.3 2 2">
        (4) Шина хранения №2: фильтр на блок истинного кварца.
        <BlockImage id="quartz_block" scale="2" />
  </BoxAnnotation>

  <DiamondAnnotation pos="3 1.5 1.5" color="#00ff00">
    Подсеть разрушения истощённых блоков
  </DiamondAnnotation>

  <BoxAnnotation color="#ffddaa" min="4 0.7 1" max="5 1 2">
        (5) Плоскость формирования: стандартная конфигурация.
  </BoxAnnotation>

  <BoxAnnotation color="#ffddaa" min="2 0 1" max="2.3 1 2">
        (6) Шина импорта: стандартная конфигурация.
  </BoxAnnotation>

  <DiamondAnnotation pos="3 0.5 1.5" color="#ddcc00">
    Подсеть размещения цветущих блоков
  </DiamondAnnotation>

  <BoxAnnotation color="#aaaadd" min="0.7 2 1" max="1 3 2">
        (7) Шина хранения №3: фильтр на кристалл. Приоритет выше основного хранилища.
        <ItemImage id="certus_quartz_crystal" scale="2" />
  </BoxAnnotation>

  <IsometricCamera yaw="165" pitch="5" />
</GameScene>

## Как работает

**Разрушение кластеров:** Плоскость ломает только кластеры (шина фильтрует на кристалл). Кладёт в бочку.

**Разрушение истощённых блоков:** Плоскость с шёлковым касанием ломает только <ItemLink id="quartz_block" />.
Результат идёт в бочку для ручного обновления (бросьте в воду с заряженным кварцем).

**Размещение цветущих блоков:** Шина импорта берёт блок из входной бочки, плоскость формирования
его размещает.

**В основной сети:** Шина хранения №3 с высоким приоритетом даёт доступ к кристаллам.
