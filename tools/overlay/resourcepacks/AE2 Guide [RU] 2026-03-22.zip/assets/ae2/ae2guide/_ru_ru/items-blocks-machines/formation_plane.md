---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Плоскость формирования
  icon: formation_plane
  position: 210
categories:
- devices
item_ids:
- ae2:formation_plane
---

# Плоскость формирования

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../assets/blocks/formation_plane.snbt" />
</GameScene>

Плоскость формирования размещает блоки и бросает предметы. Работает как однонаправленная
<ItemLink id="storage_bus" /> — размещает или бросает, когда [устройства](../ae2-mechanics/devices.md)
«сохраняют» в неё предметы через [сетевое хранилище](../ae2-mechanics/import-export-storage.md).

<GameScene zoom="8" interactive={true}>
  <ImportStructure src="../assets/assemblies/formation_plane_demonstration.snbt" />
  <IsometricCamera yaw="255" pitch="30" />
</GameScene>

Являются [субчастями кабеля](../ae2-mechanics/cable-subparts.md).

**НЕ ЗАБУДЬТЕ РАЗРЕШИТЬ ФЕЙКОВЫХ ИГРОКОВ В НАСТРОЙКАХ ЗАЩИТЫ ЧАНКОВ**

## Фильтрация

По умолчанию плоскость размещает/бросает всё. Предметы в слотах фильтра формируют белый список.

## Приоритет

Задаётся нажатием на гаечный ключ в правом верхнем углу интерфейса.

## Настройки

*   Плоскость можно настроить на размещение блоков в мире или бросание предметов

## Улучшения

*   <ItemLink id="capacity_card" /> увеличивает количество слотов фильтра
*   <ItemLink id="fuzzy_card" /> фильтрация по прочности и/или игнорирование NBT
*   <ItemLink id="inverter_card" /> переключает фильтр с белого списка на чёрный

## Рецепт

<RecipeFor id="formation_plane" />
