---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Шарики краски
  icon: green_lumen_paint_ball
  position: 410
categories:
- tools
item_ids:
- ae2:white_paint_ball
- ae2:green_paint_ball
- ae2:blue_paint_ball
- ae2:red_paint_ball
- ae2:black_paint_ball
---

# Шарики краски

<Row gap="-8">
  <ItemImage id="white_paint_ball" scale="4" />
  <ItemImage id="orange_paint_ball" scale="4" />
  <ItemImage id="green_paint_ball" scale="4" />
  <ItemImage id="blue_paint_ball" scale="4" />
  <ItemImage id="red_paint_ball" scale="4" />
</Row>

Шарики краски используются в <ItemLink id="color_applicator" /> для покраски блоков — [кабелей](cables.md),
шерсти, терракоты, стекла, бетона. Также стреляют пятнами краски из <ItemLink id="matter_cannon" />.

## Рецепты

8 шариков материи вокруг красителя:

<Column>
  <Row>
    <RecipeFor id="white_paint_ball" />
    <RecipeFor id="orange_paint_ball" />
    <RecipeFor id="green_paint_ball" />
  </Row>
  <Row>
    <RecipeFor id="blue_paint_ball" />
    <RecipeFor id="red_paint_ball" />
    <RecipeFor id="black_paint_ball" />
  </Row>
</Column>

# Светящиеся шарики краски

<Row gap="-8">
  <ItemImage id="white_lumen_paint_ball" scale="4" />
  <ItemImage id="orange_lumen_paint_ball" scale="4" />
  <ItemImage id="green_lumen_paint_ball" scale="4" />
  <ItemImage id="blue_lumen_paint_ball" scale="4" />
  <ItemImage id="red_lumen_paint_ball" scale="4" />
</Row>

Работают как обычные, но пятна от <ItemLink id="matter_cannon" /> светятся. Что-то вроде сигнальной ракеты.

## Рецепты

8 шариков краски вокруг светокаменной пыли:

<Column>
  <Row>
    <RecipeFor id="white_lumen_paint_ball" />
    <RecipeFor id="orange_lumen_paint_ball" />
    <RecipeFor id="green_lumen_paint_ball" />
  </Row>
  <Row>
    <RecipeFor id="blue_lumen_paint_ball" />
    <RecipeFor id="red_lumen_paint_ball" />
    <RecipeFor id="black_lumen_paint_ball" />
  </Row>
</Column>
