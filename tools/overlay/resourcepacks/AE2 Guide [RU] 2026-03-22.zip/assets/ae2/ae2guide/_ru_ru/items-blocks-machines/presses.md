---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Прессы
  icon: silicon_press
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:silicon_press
- ae2:logic_processor_press
- ae2:calculation_processor_press
- ae2:engineering_processor_press
- ae2:name_press
---

# Прессы

В <ItemLink id="inscriber" /> используются 5 разных прессов.

<Row>
  <ItemImage id="silicon_press" scale="4" />
  <ItemImage id="logic_processor_press" scale="4" />
  <ItemImage id="calculation_processor_press" scale="4" />
  <ItemImage id="engineering_processor_press" scale="4" />
</Row>

<ItemImage id="name_press" scale="4" />

## Прессы процессоров

Прессы кремния, логики, вычислений и инженерный используются для производства [процессоров](processors.md).
Выпадают из <ItemLink id="mysterious_cube" /> в [метеорите](../ae2-mechanics/meteorites.md).
Также можно дублировать в <ItemLink id="inscriber" />.

<Column>
  <Row>
    <RecipeFor id="silicon_press" />
    <RecipeFor id="logic_processor_press" />
  </Row>
  <Row>
    <RecipeFor id="calculation_processor_press" />
    <RecipeFor id="engineering_processor_press" />
  </Row>
</Column>

## Именующий пресс

Именующий пресс используется для именования предметов — как наковальня.

Для создания: правый клик с <ItemLink id="certus_quartz_cutting_knife" /> или
<ItemLink id="nether_quartz_cutting_knife" />, вставьте металлический слиток, введите имя и
извлеките готовую пластину. Можно использовать 1 или 2 пластины — две объединяют имена (верхний + нижний слот).
