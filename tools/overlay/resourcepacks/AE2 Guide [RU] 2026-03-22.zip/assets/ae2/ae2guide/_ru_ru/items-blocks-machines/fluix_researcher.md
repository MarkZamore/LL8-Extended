---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Исследователь флюиса (житель)
  icon: minecraft:emerald
  position: 310
categories:
- tools
---

# Исследователь флюиса

<Row>
![Исследователь флюиса](../assets/diagrams/ae2_villager.png)
<BlockImage id="charger" scale="8" />
</Row>

Исследователь флюиса — профессия жителя. Рабочее место — <ItemLink id="charger" />.

## Торговля

Торговля следует ванильной структуре: при каждом уровне открываются случайные 2 торговли
(если уровень содержит больше одной).

| Уровень     | Предмет (предлагает)                                              | Предмет (получает)                                              |
|-------------|-------------------------------------------------------------------|-----------------------------------------------------------------|
| Новичок     | 3 <ItemLink id="minecraft:emerald" />                             | 4 <ItemLink id="certus_quartz_crystal" />                       |
| Новичок     | 2 <ItemLink id="minecraft:emerald" />                             | 1 <ItemLink id="meteorite_compass" />                           |
|             |                                                                   |                                                                 |
| Подмастерье | 3 <ItemLink id="charged_certus_quartz_crystal" />                 | 1 <ItemLink id="minecraft:emerald" />                           |
| Подмастерье | 5 <ItemLink id="silicon" />                                       | 1 <ItemLink id="minecraft:emerald" />                           |
| Подмастерье | 5 <ItemLink id="minecraft:emerald" />                             | 8 <ItemLink id="sky_stone_block" />                             |
|             |                                                                   |                                                                 |
| Умелец      | 2 <ItemLink id="quartz_glass" />                                  | 1 <ItemLink id="minecraft:emerald" />                           |
| Умелец      | 5 <ItemLink id="minecraft:emerald" />                             | 4 <ItemLink id="fluix_crystal" />                               |
|             |                                                                   |                                                                 |
| Эксперт     | 5 <ItemLink id="matter_ball" />                                   | 1 <ItemLink id="minecraft:emerald" />                           |
| Эксперт     | 10 <ItemLink id="minecraft:emerald" />                            | 1 <ItemLink id="silicon_press" />                               |
| Эксперт     | 10 <ItemLink id="minecraft:emerald" />                            | 1 <ItemLink id="logic_processor_press" />                       |
| Эксперт     | 10 <ItemLink id="minecraft:emerald" />                            | 1 <ItemLink id="calculation_processor_press" />                 |
| Эксперт     | 10 <ItemLink id="minecraft:emerald" />                            | 1 <ItemLink id="engineering_processor_press" />                 |
|             |                                                                   |                                                                 |
| Мастер      | 8 <ItemLink id="minecraft:emerald" />                             | 5 <ItemLink id="minecraft:slime_ball" />                        |
