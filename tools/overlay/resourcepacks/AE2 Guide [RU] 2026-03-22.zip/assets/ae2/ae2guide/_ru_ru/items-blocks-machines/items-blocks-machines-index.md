---
navigation:
  title: Предметы, блоки и машины
  position: 50
---

# Предметы, блоки и машины

Список содержимого мода с описанием функций.

## Разные материалы и блоки

<CategoryIndex category="misc ingredients blocks" />

## Сетевая инфраструктура

<CategoryIndex category="network infrastructure" />

## Устройства

<CategoryIndex category="devices" />

## Машины

<CategoryIndex category="machines" />

## Инструменты

<CategoryIndex category="tools" />
