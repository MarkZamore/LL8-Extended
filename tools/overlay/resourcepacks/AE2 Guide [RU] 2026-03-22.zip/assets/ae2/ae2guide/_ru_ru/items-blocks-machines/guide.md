---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Руководство
  icon: guide
categories:
- tools
item_ids:
- ae2:guide
---

# Руководство

<ItemImage id="guide" scale="8" />

### Это руководство, которое вы сейчас читаете — для всех нужд по AE2.

* Откройте боковую панель слева — там оглавление
* На многих страницах есть интерактивные сцены. Если рядом со сценой есть кнопки
  ![Plus](../assets/diagrams/plus.png) и ![Minus](../assets/diagrams/minus.png), можно вращать
  и перемещать камеру. Левый клик и тяга — вращение, правый клик и тяга — перемещение.

## Рецепт

<RecipeFor id="guide" />
