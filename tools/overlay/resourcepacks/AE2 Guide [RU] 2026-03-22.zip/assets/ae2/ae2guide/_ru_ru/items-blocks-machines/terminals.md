---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Терминалы
  icon: crafting_terminal
  position: 210
categories:
- devices
item_ids:
- ae2:terminal
- ae2:crafting_terminal
- ae2:pattern_encoding_terminal
- ae2:pattern_access_terminal
---

# Терминалы

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/terminals.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Терминалы — основной способ взаимодействия МЭ-сети *с вами*. Существует несколько вариантов.

Терминалы наследуют цвет [кабеля](cables.md), к которому прикреплены.

Являются [субчастями кабеля](../ae2-mechanics/cable-subparts.md).

## Правильное размещение терминала

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/assemblies/terminal_placement.snbt" />
  <IsometricCamera yaw="195" pitch="30" />

  <LineAnnotation color="#ff3333" from="2.5 .5 .5" to="4.5 2.5 .5" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#ff3333" from="2.5 2.5 .5" to="4.5 .5 .5" alwaysOnTop={true} thickness="0.05"/>

  <LineAnnotation color="#33ff33" from="-.5 2.5 .5" to="1 .5 .5" alwaysOnTop={true} thickness="0.05"/>
  <LineAnnotation color="#33ff33" from="1 .5 .5" to="1.5 1 .5" alwaysOnTop={true} thickness="0.05"/>
</GameScene>

Терминал и приёмщик энергии — правильно повёрнуто, подключено к сети, и занимает меньше места.

<a name="terminal-ui"></a>

# Поиск в терминале

Строка поиска поддерживает RegEx. Например, «gtceu:.*ore» найдёт все руды из Gregtech.

# Терминал

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/blocks/terminal.snbt" />
  <IsometricCamera yaw="180" />
</GameScene>

Базовый терминал — просмотр и доступ к [сетевому хранилищу](../ae2-mechanics/import-export-storage.md)
и запрос [автокрафта](../ae2-mechanics/autocrafting.md).

## Интерфейс

Центральная часть — доступ к хранилищу:

*   Левый клик — взять стак, правый клик — взять полстака.
*   Для [автокрафтабельных](../ae2-mechanics/autocrafting.md) предметов — «взять блок» (обычно средний клик) открывает запрос количества. Можно вводить формулы вроде `3*64/2` или `=32` для крафта до нужного количества.
*   Shift замораживает отображение предметов.
*   Правый клик ведром — залить жидкость, левый клик жидкостью с пустым ведром — взять.

Левая часть — кнопки сортировки, фильтрации по виду (предметы/жидкости/крафтабельные), изменения высоты.

Справа — слоты для <ItemLink id="view_cell" />.

Кнопка молотка (правый верхний угол центральной части) — статус [автокрафта](../ae2-mechanics/autocrafting.md).

## Рецепт

<RecipeFor id="terminal" />

<a name="crafting-terminal-ui"></a>

# Терминал крафта

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/blocks/crafting_terminal.snbt" />
  <IsometricCamera yaw="180" />
</GameScene>

Как обычный терминал, но с сеткой крафта, автоматически пополняемой из [сетевого хранилища](../ae2-mechanics/import-export-storage.md).
Осторожно с Shift+кликом на результат!

Обновите терминал до терминала крафта как можно скорее.

## Рецепт

<RecipeFor id="crafting_terminal" />

<a name="pattern-encoding-terminal-ui"></a>

# Терминал кодирования шаблонов

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/blocks/pattern_encoding_terminal.snbt" />
  <IsometricCamera yaw="180" />
</GameScene>

Как обычный терминал, но с интерфейсом кодирования [шаблонов](patterns.md). Сетка похожа на терминал
крафта, но крафт не выполняется.

Он должен быть у вас наряду с терминалом крафта.

## Интерфейс

Слот для <ItemLink id="blank_pattern" />, большая стрелка кодирования, слот для уже закодированного
шаблона (для редактирования).

4 вкладки: Крафт, Обработка, Кузница, Камнерез.

**Режим крафта:**
*   Левый клик / перетаскивание из JEI/REI для заполнения ингредиентов.
*   Замена материалов — только при необходимости.
*   Замена жидкостей — использование жидкостей вместо вёдер.

**Режим обработки:**
*   Задание входов и выходов.
*   Правый клик с контейнером для жидкости — задать жидкость.
*   Слоты прокручиваются — до 81 входа и 26 побочных выходов.

## Рецепт

<RecipeFor id="pattern_encoding_terminal" />

<a name="pattern-access-terminal-ui"></a>

# Терминал доступа к шаблонам

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../assets/blocks/pattern_access_terminal.snbt" />
  <IsometricCamera yaw="180" />
</GameScene>

Решает конкретную проблему: в плотной башне из <ItemLink id="pattern_provider" /> и
<ItemLink id="molecular_assembler" /> к поставщикам физически не добраться. Терминал даёт доступ
ко всем поставщикам шаблонов в сети.

## Интерфейс

Настройки высоты и отображаемых поставщиков. Каждая строка соответствует конкретному поставщику.
Поставщики сортируются по подключённым блокам или заданному имени (наковальня или <ItemLink id="name_press" />).

## Рецепт

<RecipeFor id="pattern_access_terminal" />
