---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Блок истинного кварца
  icon: quartz_block
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:quartz_block
---

# Блок истинного кварца

<BlockImage id="quartz_block" scale="8" />

Блок-хранилище для <ItemLink id="certus_quartz_crystal" />. Используется для создания
[цветущих блоков](budding_certus.md) или [декоративных блоков](decorative_certus.md).

## Рецепт

<RecipeFor id="quartz_block" />
