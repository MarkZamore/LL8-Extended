---
navigation:
  parent: example-setups/example-setups-index.md
  title: Опустошение вёдер
  icon: minecraft:bucket
---

# Опустошение вёдер

См. также [Заполнение вёдер](bucket-filler.md).

Поскольку используется <ItemLink id="pattern_provider" />, схема для [автокрафта](../ae2-mechanics/autocrafting.md).

Иногда нужна жидкость, но получить её можно только в ведре. Ванильный диспенсер справляется:

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/bucket_emptier.snbt" />

<BoxAnnotation color="#dddddd" min="2 1 0" max="3 2 1">
        (1) Поставщик шаблонов: блокировка «При редстоун-сигнале», режим блокировки вкл., нужные шаблоны.
        <Row>
        ![Вода](../assets/diagrams/water_empty_pattern_small.png)
        ![Лава](../assets/diagrams/lava_empty_pattern_small.png)
        </Row>
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="2.1 2 0.1" max="2.9 2.2 0.9">
        (2) Интерфейс: стандартная конфигурация.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="3.1 2 1.1" max="3.9 2.2 1.9">
        (3) Шина хранения №1: стандартная конфигурация.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="4.05 1.05 0.8" max="4.95 1.95 1">
        (4) Плоскость уничтожения: без настроек.
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="3.2 1.2 0.8" max="3.8 1.8 1">
        (5) Шина импорта: фильтр на вёдра.
        <ItemImage id="minecraft:bucket" scale="2" />
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="3 1.1 0.1" max="3.2 1.9 0.9">
        (6) Шина хранения №2: стандартная конфигурация.
  </BoxAnnotation>

<DiamondAnnotation pos="0 1.5 0.5" color="#00ff00">
        К основной сети
    </DiamondAnnotation>

  <IsometricCamera yaw="225" pitch="45" />
</GameScene>

## Как работает

1. Поставщик подаёт ведро в интерфейс (фактически напрямую через шины хранения в диспенсер).
2. Компаратор обнаруживает ведро в диспенсере → одновременно включает диспенсер и блокирует поставщика.
3. Диспенсер выливает жидкость, теперь в нём пустое ведро.
4. Шина импорта тянет пустое ведро и кладёт через шину хранения в поставщик, возвращая в сеть.
5. Компаратор видит пустой диспенсер → разблокирует поставщика.
