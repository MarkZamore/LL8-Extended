---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Сингулярности
  icon: singularity
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:singularity
- ae2:quantum_entangled_singularity
---

# Сингулярность

<ItemImage id="singularity" scale="4" />

Очень компактный шарик материи.

Производится из 256 000 предметов или вёдер в <ItemLink id="condenser" /> в режиме сингулярности.

## Сингулярность квантовой запутанности

<ItemImage id="quantum_entangled_singularity" scale="4" />

Требуется для создания соединения между двумя [квантовыми мостами](quantum_bridge.md) — всегда
производятся парами. Для создания соединения поместите по одной сингулярности из пары в
<ItemLink id="quantum_link" /> каждой стороны.

Изготавливаются реакцией <ItemLink id="minecraft:ender_pearl" /> или <ItemLink id="ender_dust" />
с <ItemLink id="singularity" />. Достаточно любой взрывной силы.

<RecipeFor id="quantum_entangled_singularity" />

***Подойдёт почти любой взрыв — даже от крипера.***

Всегда производятся парами, но требуют всего одну <ItemLink id="singularity" />.

Рекомендуется давать им имена через наковальню сразу при создании.
