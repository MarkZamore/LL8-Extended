---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Пространственный порт ввода/вывода
  icon: spatial_io_port
  position: 210
categories:
- devices
item_ids:
- ae2:spatial_io_port
---

# Пространственный порт ввода/вывода

<BlockImage id="spatial_io_port" p:powered="true" scale="8" />

Используется в [пространственном хранилище](../ae2-mechanics/spatial-io.md) для удержания
[пространственной ячейки](spatial_cells.md) и управления операцией.

Ячейку можно вставлять и извлекать через воронки или шины AE2 для автоматизации.

## Рецепт

<RecipeFor id="spatial_io_port" />
