---
navigation:
  title: Введение в EnderDrives
  position: 60
---

# EnderDrives!

EnderDrives предлагает принципиально иной способ хранения предметов. Диски связываются между собой
по заданной частоте. Все диски с одинаковой частотой и областью видимости используют одно общее
хранилище — независимо от того, кто их создал. В вашей AE2-системе, другом измерении или системе
другого игрока — содержимое синхронизировано глобально.

Полный список предоставляемых блоков и предметов — на страницах руководства ниже:

## EnderDrives

<CategoryIndex category="enderdrives"></CategoryIndex>

## TapeDrives

<CategoryIndex category="tapedrives"></CategoryIndex>

Нашли проблему? Чего-то не хватает?
Сообщите здесь:
[GitHub EnderDrives](https://github.com/STS15/enderdrives)
