---
navigation:
  parent: enderdrives_intro/enderdrives_intro-index.md
  title: Ячейки хранения Ender
  icon: enderdrives:ender_disk_1k
categories:
  - enderdrives
item_ids:
  - enderdrives:ender_disk_1k
  - enderdrives:ender_disk_4k
  - enderdrives:ender_disk_16k
  - enderdrives:ender_disk_64k
  - enderdrives:ender_disk_256k
  - enderdrives:ender_disk_creative
---

# Ender Drives

Ender Drives — мощные накопители с глобально синхронизированным хранилищем между МЭ-системами,
измерениями и разными игроками через систему частот.

<Row gap="10">
  <Column><ItemImage id="enderdrives:ender_disk_1k" /></Column>
  <Column><ItemLink id="enderdrives:ender_disk_1k" /></Column>
</Row>
<Row gap="10">
  <Column><ItemImage id="enderdrives:ender_disk_4k" /></Column>
  <Column><ItemLink id="enderdrives:ender_disk_4k" /></Column>
</Row>
<Row gap="10">
  <Column><ItemImage id="enderdrives:ender_disk_16k" /></Column>
  <Column><ItemLink id="enderdrives:ender_disk_16k" /></Column>
</Row>
<Row gap="10">
  <Column><ItemImage id="enderdrives:ender_disk_64k" /></Column>
  <Column><ItemLink id="enderdrives:ender_disk_64k" /></Column>
</Row>
<Row gap="10">
  <Column><ItemImage id="enderdrives:ender_disk_256k" /></Column>
  <Column><ItemLink id="enderdrives:ender_disk_256k" /></Column>
</Row>

---

## Как это работает

Каждый Ender Drive настраивается тремя параметрами: частотой, областью видимости и режимом.
- **Частота**: все диски с одинаковой частотой используют одно общее хранилище.
- **Область видимости**: определяет, кто может получить доступ (Глобальная, Личная, Команда).
- **Режим**: управляет направлением потока предметов (Двунаправленный, Только вход, Только выход).

Все диски с одинаковой частотой и областью видимости обращаются к **одному виртуальному инвентарю**,
где бы они ни находились.

---

## Ограничение по типам

В отличие от обычных накопителей AE2, у Ender Drives ограничение только по количеству типов.
Максимальное количество предметов каждого типа: 2^63 − 1 (~9,2 квинтиллиона). Но будьте осторожны:
энергопотребление растёт с количеством хранимых предметов!

Предел типов зависит от сервера. Проверьте его командой `/autobenchmark` (при открытом терминале
с диском на приватной частоте). Среднее значение — около 275 000 типов.

---

## Режимы работы

- ![](../pic/transport_bidirectional_alt.png) **Двунаправленный** _(по умолчанию)_
  Стандартное поведение МЭ-накопителя. Свободная вставка и извлечение.

- ![](../pic/transport_input_alt.png) **Только вход**
  Предметы можно добавлять, но не извлекать. Для буферов или синхронизации входящих потоков.

- ![](../pic/transport_output_alt.png) **Только выход**
  Предметы можно извлекать, но не добавлять. Для выходных буферов или доступа только на чтение.

---

## Область видимости и приватность

- **Глобальная** _(по умолчанию)_: публичная. Любой игрок с той же частотой имеет доступ.

- **Личная**: привязана к вашему UUID. Только вы создаёте диски для этой частоты. Другие
  пользователи вашей МЭ-системы по-прежнему могут получить доступ к хранилищу.

- **Команда**: общая для FTB-команды. Все участники используют одну частоту.
