---
navigation:
  title: "Аддон: Ars Énergistique"
  position: 150
---

# Ars Énergistique

Ars Énergistique соединяет два мира: магию [Ars Nouveau](https://www.curseforge.com/minecraft/mc-mods/ars-nouveau)
и логистику Applied Energistics 2.

Мод добавляет возможность:
- Хранить **Источник** (Source) в МЭ-сети как полноценный ресурс
- Конвертировать Источник в **AE-энергию** для питания сети
- Транспортировать Источник и **снаряды заклинаний** через P2P-тоннели
- Напрямую работать с МЭ-сетью из стола переписчика и котла Вики

## Содержание

<CategoryIndex category="arseng" />
