---
navigation:
  parent: arseng-index.md
  title: Переносные ячейки источника
  icon: arseng:portable_source_cell_1k
  position: 40
categories:
- arseng
item_ids:
- arseng:portable_source_cell_1k
- arseng:portable_source_cell_4k
- arseng:portable_source_cell_16k
- arseng:portable_source_cell_64k
- arseng:portable_source_cell_256k
---

# Переносные ячейки источника

<Row>
  <ItemImage id="arseng:portable_source_cell_1k" scale="4" />
  <ItemImage id="arseng:portable_source_cell_4k" scale="4" />
  <ItemImage id="arseng:portable_source_cell_16k" scale="4" />
  <ItemImage id="arseng:portable_source_cell_64k" scale="4" />
  <ItemImage id="arseng:portable_source_cell_256k" scale="4" />
</Row>

Переносные ячейки источника — это карманный резервуар Источника. Открываются прямо из инвентаря
как <ItemLink id="ae2:chest" /> в кармане, но хранят **Источник**, а не предметы.

Полезны для зарядки предметов Ars Nouveau вдали от базы, переноски запаса Источника на
экспедицию или подпитки удалённых установок без прокладки отдельной МЭ-сети.

## Отличия от обычных ячеек

Переносные ячейки не вставляются в накопитель — они работают только как автономный
переносной резервуар. Зарядить их Источником можно, поместив рядом с кувшином источника
или другим источником, который может в них заливать.

## Рецепт

Крафтится на верстаке без формы:

- <ItemLink id="ae2:chest" /> (МЭ сундук)
- Компонент хранения AE2 нужного уровня (например <ItemLink id="ae2:cell_component_1k" />)
- <ItemLink id="ae2:energy_cell" /> (обеспечивает питание)
- <ItemLink id="arseng:source_cell_housing" />

Компоненты можно вернуть разборкой пустой ячейки (Shift+ПКМ).
