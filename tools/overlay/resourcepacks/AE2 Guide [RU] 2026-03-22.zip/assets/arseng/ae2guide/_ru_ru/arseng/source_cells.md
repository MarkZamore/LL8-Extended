---
navigation:
  parent: arseng-index.md
  title: Ячейки источника
  icon: arseng:source_storage_cell_1k
  position: 30
categories:
- arseng
item_ids:
- arseng:source_cell_housing
- arseng:source_storage_cell_1k
- arseng:source_storage_cell_4k
- arseng:source_storage_cell_16k
- arseng:source_storage_cell_64k
- arseng:source_storage_cell_256k
---

# Ячейки источника

<Row>
  <ItemImage id="arseng:source_storage_cell_1k" scale="4" />
  <ItemImage id="arseng:source_storage_cell_4k" scale="4" />
  <ItemImage id="arseng:source_storage_cell_16k" scale="4" />
  <ItemImage id="arseng:source_storage_cell_64k" scale="4" />
  <ItemImage id="arseng:source_storage_cell_256k" scale="4" />
</Row>

Ячейки источника хранят **Источник** (Source) внутри МЭ-сети. Вставляются в стандартный
<ItemLink id="ae2:drive" /> или <ItemLink id="ae2:chest" /> как любые ячейки AE2.

## Принцип хранения

Хранение работает на тех же принципах, что и у обычных ячеек AE2. Ёмкость измеряется в байтах.
Источник — это **единственный тип** данных в ячейке, поэтому проблем с «заполнением типов»
нет: вся ёмкость ячейки используется для хранения Источника.

Счётчик заряда в тултипе показывает использованные/всего байт аналогично предметным ячейкам.

## Улучшения

Ячейки поддерживают установку через <ItemLink id="ae2:cell_workbench" />:

- <ItemLink id="ae2:void_card" /> — уничтожает излишек Источника, если ячейка заполнена.
  Полезно при автоматических фермах Источника, чтобы они не останавливались из-за переполнения.

## Корпус ячейки источника

<ItemImage id="arseng:source_cell_housing" scale="4" />

Для создания ячеек нужен специальный корпус. Крафтится в **Волшебном аппарате**:

- **Реагент:** <ItemLink id="ae2:item_cell_housing" />
- **На пьедесталах:** 2× эссенция манипуляции + 2× камень Источника + 4× золотой слиток
- **Стоимость:** бесплатно

## Рецепты ячеек

Крафтятся на верстаке без формы:
`корпус ячейки источника` + `компонент хранения AE2 нужного уровня`

Компоненты можно вернуть разборкой пустой ячейки (Shift+ПКМ).
