---
navigation:
  parent: arseng-index.md
  title: ME Source Converter
  icon: arseng:source_acceptor
  position: 10
categories:
- arseng
item_ids:
- arseng:source_acceptor
- arseng:cable_source_acceptor
---

# ME Source Converter

The ME Source Converter converts Source from Ars Nouveau into AE energy for your ME network.

**Conversion rate:** 1 Source = 16 AE (configurable via `ae_per_source`)

Acts as an `ISourceCap` for any Ars Nouveau machine. Idle power usage: 0 AE/t.

Available as a full block or flat cable subpart.

## Recipe

Crafted in the **Enchanting Apparatus**:

- **Reagent:** ME Energy Acceptor
- **Pedestals:** 4× Source Gem Block + 4× Gold Block
- **Source cost:** 10,000
