---
navigation:
  parent: arseng-index.md
  title: P2P Tunnels
  icon: arseng:source_p2p_tunnel
  position: 50
categories:
- arseng
item_ids:
- arseng:source_p2p_tunnel
- arseng:spell_p2p_tunnel
---

# P2P Tunnels

## Source P2P Tunnel

Transfers **Source** from input to outputs through the ME network.

- Input: receive-only. Output: send-only.
- Multiple outputs: Source is **distributed evenly** (remainder goes to first outputs).
- Each output has a buffer of **1,000 Source** (configurable via `output_p2p_buffer`), saved to NBT.
- Costs AE energy per unit of Source transported.

## Spell P2P Tunnel

Physically **teleports spell projectiles** through the ME network.

- When a projectile hits the input face → teleported to a random output.
- Speed after redirect is recalculated from Accelerate/Decelerate augments.
- After 3 redirects, all nearby players (10 blocks) receive the **Prismatic** advancement.
- Power drain: 0.5 AE/tick idle.
