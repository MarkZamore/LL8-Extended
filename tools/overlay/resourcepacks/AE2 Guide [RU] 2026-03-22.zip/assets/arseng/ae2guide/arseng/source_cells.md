---
navigation:
  parent: arseng-index.md
  title: Source Storage Cells
  icon: arseng:source_storage_cell_1k
  position: 30
categories:
- arseng
item_ids:
- arseng:source_cell_housing
- arseng:source_storage_cell_1k
- arseng:source_storage_cell_4k
- arseng:source_storage_cell_16k
- arseng:source_storage_cell_64k
- arseng:source_storage_cell_256k
---

# Source Storage Cells

Source storage cells store **Source** inside an ME network. Insert them into a ME Drive or ME Chest.

Cells store a single key type (Source), so all capacity is used for Source with no type overhead.

Supports the **Overflow Destruction Card** via Cell Workbench.

## Source Cell Housing

Crafted in the **Enchanting Apparatus**:

- **Reagent:** ME Item Cell Housing
- **Pedestals:** 2× Manipulation Essence + 2× Source Gem + 4× Gold Ingot
- **Source cost:** 0

## Cell Recipes

Crafted shapeless: Source Cell Housing + AE2 storage component of the desired tier.

Components can be recovered by shift-right-clicking an empty cell.
