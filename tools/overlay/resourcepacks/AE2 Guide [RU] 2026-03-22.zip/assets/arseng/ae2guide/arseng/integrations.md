---
navigation:
  parent: arseng-index.md
  title: Ars Nouveau Integrations
  icon: arseng:me_source_jar
  position: 60
categories:
- arseng
---

# Ars Nouveau Integrations

## Scribes Table

The Scribes Table can now pull ingredients directly from nearby ME networks within a **13×5×13** area (6 blocks in each direction, 2 up/down). No need to drop items on the floor — it extracts from ME storage automatically.

## Wixie Cauldron

The Wixie Cauldron now reads crafting patterns from adjacent **Pattern Providers**. Any pattern whose output the Cauldron can craft is added to its recipe list, enabling full AE2 autocrafting integration.
