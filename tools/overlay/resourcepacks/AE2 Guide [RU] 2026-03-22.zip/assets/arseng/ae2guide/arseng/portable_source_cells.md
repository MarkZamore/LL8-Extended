---
navigation:
  parent: arseng-index.md
  title: Portable Source Cells
  icon: arseng:portable_source_cell_1k
  position: 40
categories:
- arseng
item_ids:
- arseng:portable_source_cell_1k
- arseng:portable_source_cell_4k
- arseng:portable_source_cell_16k
- arseng:portable_source_cell_64k
- arseng:portable_source_cell_256k
---

# Portable Source Cells

Portable Source cells are pocket Source reservoirs. Open directly from your inventory like a ME Chest, but storing Source instead of items.

Useful for carrying Source to charge Ars Nouveau items away from base.

## Recipe

Crafted shapeless: ME Chest + AE2 storage component + ME Energy Cell + Source Cell Housing.

Components can be recovered by shift-right-clicking an empty cell.
