---
navigation:
  parent: arseng-index.md
  title: ME Source Jar
  icon: arseng:me_source_jar
  position: 20
categories:
- arseng
item_ids:
- arseng:me_source_jar
---

# ME Source Jar

The ME Source Jar is a bidirectional bridge between ME Source storage and Ars Nouveau machines.
It looks like a regular Source Jar to any Ars Nouveau machine, but draws from and stores into the entire ME network.

Requires a **channel** to operate. Without a channel it returns 0 and does not transfer Source.

Network connections: top, bottom, and back face.

## Recipe

Crafted in the **Enchanting Apparatus**:

- **Reagent:** Source Jar
- **Pedestals:** 1× Manipulation Essence + 1× ME Interface
- **Source cost:** 0
