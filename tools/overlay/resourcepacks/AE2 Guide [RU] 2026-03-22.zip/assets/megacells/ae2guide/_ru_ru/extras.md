---
navigation:
  title: Дополнения MEGA
  icon: mega_interface
  parent: index.md
  position: 060
categories:
  - megacells
item_ids:
  - mega_interface
  - cell_dock
  - portable_cell_workbench
---

# MEGA Cells: Дополнения

## MEGA Интерфейс

<Row>
  <BlockImage id="mega_interface" scale="4" />
  <GameScene zoom="4" background="transparent">
    <ImportStructure src="assets/assemblies/cable_mega_interface.snbt" />
  </GameScene>
</Row>

**MEGA Интерфейс** — версия <ItemLink id="ae2:interface" /> с удвоенной ёмкостью: вдвое больше слотов, ввода/вывода и пропускной способности.

<RecipeFor id="mega_interface" />
<RecipeFor id="cable_mega_interface" />

## Переносной верстак для ячеек

<ItemImage id="portable_cell_workbench" scale="4" />

**Переносной верстак для ячеек** — *компактная* версия <ItemLink id="ae2:cell_workbench" />, умещающаяся в руке и способная настраивать любые ячейки хранения как обычно.

<RecipeFor id="portable_cell_workbench" />

## Держатель ячейки

<GameScene zoom="8" background="transparent">
  <ImportStructure src="assets/assemblies/cell_dock.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

**Держатель ME-ячейки** — компактная версия <ItemLink id="ae2:chest" />, вмещающая одну ячейку хранения. Без встроенного терминала, зато существует в форме [кабельного элемента](ae2:ae2-mechanics/cable-subparts.md) — несколько держателей помещаются в одном блоке кабеля. Удобен для временного буфера в компактных подсетях.

<RecipeFor id="cell_dock" />

## «Классические цвета ячеек»

MEGA включает дополнительный ресурспак с возможностью выбора.

![Classic Cell Colours resource pack](assets/diagrams/cell_colours_pack.png)

До Minecraft 1.21 ячейки хранения следовали 5-цветной схеме: от красновато-коричневого (1k) через жёлтый, зелёный, синий до сиреневого (256k). MEGA продолжала эту традицию: от тёмно-красного (1M) до глубокого фиолетового (256M).

![Old cell textures](assets/diagrams/cell_colours_old.png)

После обновления текстур в AE2 post-1.20.x ячейки получили новую палитру: синий→зелёный для AE2, жёлтый→красный→розовый для MEGA. Для поклонников старого стиля доступен встроенный ресурспак.

![AE2 cell colours](assets/diagrams/cell_colours_ae2.png)
![MEGA cell colours](assets/diagrams/cell_colours_mega.png)
