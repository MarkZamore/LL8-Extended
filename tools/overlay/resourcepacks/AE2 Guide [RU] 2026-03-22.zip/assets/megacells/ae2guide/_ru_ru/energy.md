---
navigation:
  title: Энергия MEGA
  icon: greater_energy_card
  parent: index.md
  position: 030
categories:
  - megacells
item_ids:
  - mega_energy_cell
  - greater_energy_card
---

# MEGA Cells: Энергия

## Сверхплотная энергетическая ячейка

<BlockImage id="mega_energy_cell" scale="4" />

*Сверхплотная энергетическая ячейка* вмещает в 8 раз больше, чем <ItemLink id="ae2:dense_energy_cell" />, и в 64 раза больше, чем стандартная <ItemLink id="ae2:energy_cell" /> — до 12,8 *миллионов* AE. Идеально для масштабных [Spatial IO](ae2:ae2-mechanics/spatial-io.md) операций, требующих огромного буфера энергии, и всё в одном компактном блоке!

<RecipeFor id="mega_energy_cell" />

## Улучшенная карточка энергии

<ItemImage id="greater_energy_card" scale="3" />

Сверхплотную ячейку можно использовать для крафта улучшенной версии <ItemLink id="ae2:energy_card" />, обеспечивающей ещё больший энергетический буфер для беспроводных устройств и переносных ячеек. Обычные устройства AE2 поддерживают её так же, как стандартную карточку. Однако для [переносных ячеек MEGA](storage.md#мega-переносные-ячейки) *только* улучшенная карточка энергии увеличит ёмкость батареи.

<RecipeFor id="greater_energy_card" />
