---
navigation:
  title: "Дополнение: MEGA Cells"
  position: 80
item_ids:
  - accumulation_processor
  - accumulation_processor_press
  - printed_accumulation_processor
  - sky_steel_ingot
  - sky_steel_block
---

# MEGA Cells

![MEGA Cells logo](assets/logo.png)

## Введение

**MEGA Cells** — дополнение для Applied Energistics 2, предоставляющее уровни хранения от **1M** до **256M**, а также специализированные ячейки и дополнительные инструменты.

## Начало работы

<Row>
  <ItemImage id="sky_steel_ingot" scale="4" />
  <ItemImage id="accumulation_processor" scale="4" />
</Row>

Для достижения новых высот хранения нужны новые материалы. Главный ресурс — <ItemLink id="ae2:sky_stone_block" />, который нужно переплавить в сплав **Небесной стали** вместе с железом и <ItemLink id="ae2:charged_certus_quartz_crystal" />. Для металлургии нужна не вода, а значительно более горячая жидкость.

<Row>
  <Recipe id="transform/sky_steel_ingot" />
</Row>

Из небесной стали собирается новый тип процессора — **Накопительный процессор**. Он служит «основой» почти каждого устройства MEGA — стандартных ячеек большой ёмкости и специализированных инструментов.

<Row>
  <RecipeFor id="accumulation_processor_press" />
  <RecipeFor id="printed_accumulation_processor" />
  <RecipeFor id="accumulation_processor" />
</Row>

С этого момента вы готовы к дальнейшему развитию в «*MEGA Corp.*» и раскрытию полного потенциала вашего хранилища ME.

## Дополнительная информация

<SubPages />
