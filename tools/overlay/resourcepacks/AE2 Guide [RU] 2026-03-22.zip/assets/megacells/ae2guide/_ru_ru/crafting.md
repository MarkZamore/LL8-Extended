---
navigation:
  title: Автокрафт MEGA
  icon: 256m_crafting_storage
  parent: index.md
  position: 020
categories:
  - megacells
item_ids:
  - mega_crafting_unit
  - 1m_crafting_storage
  - 4m_crafting_storage
  - 16m_crafting_storage
  - 64m_crafting_storage
  - 256m_crafting_storage
  - mega_crafting_accelerator
  - mega_crafting_monitor
  - mega_pattern_provider
  - cable_mega_pattern_provider
---

# MEGA Cells: Автокрафт

<GameScene zoom="6" background="transparent">
  <ImportStructure src="assets/assemblies/crafting_cpu.snbt" />
  <IsometricCamera yaw="195" pitch="10" />
</GameScene>

## MEGA [Крафтовые CPU](ae2:items-blocks-machines/crafting_cpu_multiblock.md)

<Row>
  <BlockImage id="mega_crafting_unit" scale="4" />
  <BlockImage id="1m_crafting_storage" scale="4" />
  <BlockImage id="4m_crafting_storage" scale="4" />
  <BlockImage id="16m_crafting_storage" scale="4" />
  <BlockImage id="64m_crafting_storage" scale="4" />
  <BlockImage id="256m_crafting_storage" scale="4" />
</Row>

Как и ячейки хранения, MEGA предоставляет расширенные уровни памяти для крафтовых CPU. Для их размещения требуется собственная версия <ItemLink id="ae2:crafting_unit" />, зато в чёрном исполнении они выглядят *чертовски круто*.

<RecipeFor id="mega_crafting_unit" />
<RecipeFor id="1m_crafting_storage" />
<RecipeFor id="4m_crafting_storage" />
<RecipeFor id="16m_crafting_storage" />
<RecipeFor id="64m_crafting_storage" />
<RecipeFor id="256m_crafting_storage" />

MEGA также предоставляет собственный аналог <ItemLink id="ae2:crafting_accelerator" />, но с преимуществом: каждый блок добавляет *ЧЕТЫРЕ* потока сопроцессора вместо одного.

<BlockImage id="mega_crafting_accelerator" scale="4" />
<RecipeFor id="mega_crafting_accelerator" />

Для полного комплекта есть и аналог <ItemLink id="ae2:crafting_monitor" />. Функционально он не отличается от обычного, но дополняет остальные блоки для единого стиля.

<BlockImage id="mega_crafting_monitor" scale="4" />
<RecipeFor id="mega_crafting_monitor" />

## MEGA Поставщик шаблонов

<Row>
  <BlockImage id="mega_pattern_provider" scale="4" />
  <GameScene zoom="4" background="transparent">
    <ImportStructure src="assets/assemblies/cable_mega_pattern_provider.snbt" />
  </GameScene>
</Row>

**MEGA Поставщик шаблонов** — партнёр <ItemLink id="ae2:pattern_provider" /> с удвоенной ёмкостью: до 18 шаблонов. Ограничение: поддерживает только [**шаблоны обработки**](ae2:items-blocks-machines/patterns.md) и не совместим с <ItemLink id="ae2:molecular_assembler" />.

<Row>
  <RecipeFor id="mega_pattern_provider" />
  <RecipeFor id="cable_mega_pattern_provider" />
</Row>
