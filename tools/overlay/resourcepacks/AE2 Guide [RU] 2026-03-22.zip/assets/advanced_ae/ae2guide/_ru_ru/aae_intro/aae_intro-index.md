---
navigation:
  title: Введение в Advanced AE
  position: 70
---

# Advanced AE!

Advanced AE улучшает работу с ME-системой и расширяет возможности для позднего этапа игры. Мод позволяет настроить поставщики шаблонов на отправку предметов к конкретным граням целевых машин, а также создавать мультиблочные компьютеры, способные выполнять неограниченное количество крафтов одновременно, разделяя сопроцессоры!

![PEGui1](../pic/aae_intro.png)

Полный список блоков и предметов — на страницах гайда:

## Продвинутые устройства

<CategoryIndex category="advanced devices"></CategoryIndex>

## Продвинутые предметы

<CategoryIndex category="advanced items"></CategoryIndex>

Нашли баг? Не хватает функции?
Сообщите здесь:
[Advanced AE на GitHub](https://github.com/pedroksl/AdvancedAE)
