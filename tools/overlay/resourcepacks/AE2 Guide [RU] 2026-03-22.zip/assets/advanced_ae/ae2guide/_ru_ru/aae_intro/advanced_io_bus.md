---
navigation:
  parent: aae_intro/aae_intro-index.md
  title: Продвинутая шина ввода-вывода
  icon: advanced_ae:advanced_io_bus_part
categories:
  - advanced items
item_ids:
  - advanced_ae:advanced_io_bus_part
---

# Продвинутая шина ввода-вывода

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_advanced_io_bus.snbt"></ImportStructure>
</GameScene>

Продвинутая шина ввода-вывода — мощный инструмент для работы с внешними инвентарями. Создаётся слиянием <ItemLink id="advanced_ae:import_export_bus_part"/> и <ItemLink id="advanced_ae:stock_export_bus_part"/>. Наследует функции обоих. Базовая скорость в 8 раз выше, чем у <ItemLink id="ae2:export_bus"/>. Разгоняется постепенно, но на полной скорости работает очень быстро.

## Экспорт

Экспортирует предметы согласно фильтру строго до заданного количества и останавливается. В левой части интерфейса есть настройка регулировки запаса.

## Импорт

Импортирует всё, что не задано в фильтре для экспорта. Операции импорта и экспорта считаются раздельно — шина не зависает на одном типе операции. В режиме регулировки приоритет отдаётся импорту всего, что превышает установленный запас. Оставшиеся операции используются для импорта нефильтрованных предметов.

<RecipeFor id="advanced_ae:advanced_io_bus_part"/>
