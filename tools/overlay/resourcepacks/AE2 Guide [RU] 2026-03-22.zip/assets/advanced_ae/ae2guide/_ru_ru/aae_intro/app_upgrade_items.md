---
navigation:
  parent: aae_intro/aae_intro-index.md
  title: Улучшения усовершенствованного поставщика шаблонов
  icon: advanced_ae:adv_pattern_provider_upgrade
categories:
  - advanced items
item_ids:
  - advanced_ae:adv_pattern_provider_upgrade
  - advanced_ae:adv_pattern_provider_capacity_upgrade
---

# Улучшения усовершенствованного поставщика шаблонов

Позволяют улучшить поставщики шаблонов без необходимости перекладывать шаблоны и карточки улучшений.

## Улучшение усовершенствованного поставщика шаблонов

<ItemImage id="advanced_ae:adv_pattern_provider_upgrade" scale="3"></ItemImage>

Применяется к обычным поставщикам шаблонов AE2 и удлинённым поставщикам ExtendedAE. При применении устройство обновляется до усовершенствованной версии с сохранением количества слотов. Это значит, что вложения в улучшение обычных поставщиков до удлинённых не пропадут.

## Улучшение ёмкости усовершенствованного поставщика шаблонов

<ItemImage id="advanced_ae:adv_pattern_provider_capacity_upgrade" scale="3"></ItemImage>

Улучшение ёмкости позволяет преобразовать обычный поставщик шаблонов напрямую в усовершенствованный с 36 слотами.
