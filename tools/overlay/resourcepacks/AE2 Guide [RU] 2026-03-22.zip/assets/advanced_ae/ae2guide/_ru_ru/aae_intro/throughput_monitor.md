---
navigation:
  parent: aae_intro/aae_intro-index.md
  title: ME Монитор пропускной способности
  icon: advanced_ae:throughput_monitor
categories:
  - advanced items
item_ids:
  - advanced_ae:throughput_monitor
  - advanced_ae:throughput_monitor_configurator
---

# ME Монитор пропускной способности

<GameScene zoom="8" background="transparent">
<ImportStructure src="../structure/throughput_monitors.snbt"></ImportStructure>
<IsometricCamera yaw="195" pitch="30" />
</GameScene>

Монитор пропускной способности — разновидность монитора. Обладает всеми функциями <ItemLink id="ae2:storage_monitor" />, плюс измеряет скорость изменения количества выбранного предмета/жидкости и отображает значение в единицах в секунду.

Канал **не** требуется.

## Управление

*   ПКМ с предметом в руке или двойной ПКМ с ёмкостью для жидкостей — установить отслеживаемый предмет/жидкость.
*   ПКМ пустой рукой — сбросить настройку.
*   Shift + ПКМ пустой рукой — заблокировать монитор.

## Конфигуратор монитора пропускной способности

<ItemImage id="advanced_ae:throughput_monitor_configurator" scale="4"></ItemImage>

Инструмент для переключения режима отображения. ПКМ по монитору с конфигуратором в руке переключает между тремя режимами:

* Предметов в тик
* Предметов в секунду
* Предметов в минуту

Примечание: после смены режима показания могут быть нестабильны — подождите немного перед тем, как им доверять.
