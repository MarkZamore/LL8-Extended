---
navigation:
  parent: aae_intro/aae_intro-index.md
  title: Шина экспорта запасов
  icon: advanced_ae:stock_export_bus_part
categories:
  - advanced items
item_ids:
  - advanced_ae:stock_export_bus_part
---

# Шина экспорта запасов

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_stock_export_bus.snbt"></ImportStructure>
</GameScene>

Шина экспорта запасов экспортирует предметы из фильтра строго до заданного количества. Она отслеживает текущее содержимое целевого инвентаря и не добавляет сверх нормы. Для настройки откройте интерфейс, перетащите нужный предмет в слот фильтра и установите количество колёсиком мыши (средняя кнопка). Шина не извлекает лишнее — если предметов стало больше нормы, она просто ждёт.
