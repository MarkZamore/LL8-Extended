---
navigation:
  parent: aae_intro/aae_intro-index.md
  title: Квантовый компьютер
  icon: advanced_ae:quantum_core
categories:
  - advanced devices
item_ids:
  - advanced_ae:quantum_unit
  - advanced_ae:quantum_core
  - advanced_ae:quantum_structure
  - advanced_ae:quantum_accelerator
  - advanced_ae:quantum_multi_threader
  - advanced_ae:quantum_storage_128
  - advanced_ae:quantum_storage_256
  - advanced_ae:data_entangler
---

# Квантовый компьютер

Квантовый компьютер — особый вид крафтового компьютера. Способен выполнять неограниченное количество крафтовых запросов одновременно, пока хватает памяти для крафта.

<GameScene zoom="2" background="transparent">
  <ImportStructure src="../structure/quantum_computer_multiblock.snbt"></ImportStructure>
</GameScene>

## Квантовое ядро

<BlockImage id="advanced_ae:quantum_core" p:powered="true" p:formed="true" scale="4"></BlockImage>

Квантовое ядро — сердце квантового компьютера. Само по себе имеет 256M памяти для крафта и 8 потоков сопроцессора. Единственный блок, способный самостоятельно образовать сформированный квантовый компьютер. При использовании как отдельного компьютера питание подаётся через верхнюю или нижнюю сторону. В мультиблоке возможности значительно расширяются.

## Квантовые хранилища

<Row gap="20">
<BlockImage id="advanced_ae:quantum_storage_128" scale="4"></BlockImage>
<BlockImage id="advanced_ae:quantum_storage_256" scale="4"></BlockImage>
</Row>

Расширяют память квантового ядра, увеличивая количество одновременных задач. Доступны версии на 128M и 256M.

## Квантовый запутыватель данных

<BlockImage id="advanced_ae:data_entangler" scale="4"></BlockImage>

Особый блок, воздействующий на все хранилища в мультиблоке. Позволяет хранилищам записывать данные в нескольких измерениях, умножая их ёмкость на 4. В одном мультиблоке может быть не более одного.

## Квантовый акселератор

<BlockImage id="advanced_ae:quantum_accelerator" scale="4"></BlockImage>

Добавляет 8 потоков сопроцессора к мультиблоку. Все крафты квантового компьютера разделяют все сопроцессоры — чем больше акселераторов, тем лучше.

## Квантовый многопоточник

<BlockImage id="advanced_ae:quantum_multi_threader" scale="4"></BlockImage>

Аналогично запутывателю данных, воздействует на все акселераторы в мультиблоке и умножает количество их потоков на 4. В одном мультиблоке может быть не более одного.

## Квантовая структура

<Row gap="20">
<BlockImage id="advanced_ae:quantum_structure" scale="4"></BlockImage>
<BlockImage id="advanced_ae:quantum_structure" p:formed="true" p:powered="true" scale="4"></BlockImage>
</Row>

Блоки каркаса квантового компьютера, объединяющие всё вместе.

## Мультиблок

Правила построения мультиблочного квантового компьютера:
- Максимальный размер — 7×7×7 (внешние размеры);
- Внутри не должно быть пустот. Их можно заполнить <ItemLink id="advanced_ae:quantum_unit" /> без каких-либо бонусов;
- Ровно одно <ItemLink id="advanced_ae:quantum_core" />;
- Не более одного <ItemLink id="advanced_ae:data_entangler" />;
- Не более одного <ItemLink id="advanced_ae:quantum_multi_threader" />;
- Все блоки внешнего слоя — <ItemLink id="advanced_ae:quantum_structure" />;
- Ни один блок внутри не может быть <ItemLink id="advanced_ae:quantum_structure" />.

## Серверные настройки

Многие параметры настраиваются на сервере:
- Максимальный размер мультиблока;
- Количество сопроцессоров в каждом акселераторе;
- Максимальное количество многопоточников;
- Множитель потоков многопоточника;
- Максимальное количество запутывателей данных;
- Множитель памяти запутывателя данных.

Текущие лимиты можно посмотреть в подсказках предметов.
