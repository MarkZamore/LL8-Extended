---
navigation:
  parent: aae_intro/aae_intro-index.md
  title: Квантовый броневой комплект
  icon: advanced_ae:quantum_helmet
categories:
  - advanced items
item_ids:
  - advanced_ae:quantum_helmet
  - advanced_ae:quantum_chestplate
  - advanced_ae:quantum_leggings
  - advanced_ae:quantum_boots
  - advanced_ae:quantum_upgrade_base
  - advanced_ae:walk_speed_card
  - advanced_ae:sprint_speed_card
  - advanced_ae:step_assist_card
  - advanced_ae:jump_height_card
  - advanced_ae:lava_immunity_card
  - advanced_ae:flight_card
  - advanced_ae:water_breathing_card
  - advanced_ae:auto_feeding_card
  - advanced_ae:auto_stock_card
  - advanced_ae:magnet_card
  - advanced_ae:hp_buffer_card
  - advanced_ae:evasion_card
  - advanced_ae:regeneration_card
  - advanced_ae:strength_card
  - advanced_ae:attack_speed_card
  - advanced_ae:luck_card
  - advanced_ae:reach_card
  - advanced_ae:swim_speed_card
  - advanced_ae:night_vision_card
  - advanced_ae:flight_drift_card
  - advanced_ae:recharging_card
  - advanced_ae:portable_workbench_card
  - advanced_ae:pick_craft_card
---

# Квантовый броневой комплект

<Row gap="10">
<ItemImage id="advanced_ae:quantum_helmet" components="ae2:stored_energy=2.0E8d" scale="4"></ItemImage>
<ItemImage id="advanced_ae:quantum_chestplate" components="ae2:stored_energy=3.0E8d" scale="4"></ItemImage>
<ItemImage id="advanced_ae:quantum_leggings" components="ae2:stored_energy=2.5E8d" scale="4"></ItemImage>
<ItemImage id="advanced_ae:quantum_boots" components="ae2:stored_energy=2.0E8d" scale="4"></ItemImage>
</Row>

<ItemGrid>
<ItemIcon id="advanced_ae:quantum_helmet" components="ae2:stored_energy=2.0E8d"></ItemIcon>
<ItemIcon id="advanced_ae:quantum_chestplate" components="ae2:stored_energy=3.0E8d"></ItemIcon>
<ItemIcon id="advanced_ae:quantum_leggings" components="ae2:stored_energy=2.5E8d"></ItemIcon>
<ItemIcon id="advanced_ae:quantum_boots" components="ae2:stored_energy=2.0E8d"></ItemIcon>
</ItemGrid>

Хотели бы носить свою AE-систему буквально на себе? Квантовый броневой комплект — высокотехнологичное снаряжение, подключающееся к AE2-системе для удобного доступа ко всему на ходу. По умолчанию это энергетический костюм с защитой на уровне незеритовой брони. Он способен использовать буфер для создания энергетического щита, поглощающего урон. Ботинки нивелируют урон от падения, нагрудник устраняет штраф добычи в полёте. Но настоящая мощь раскрывается при установке улучшений!

<br/>

## Привязка брони

Каждый элемент брони можно привязать к сети отдельно, вставив его в <ItemLink id="ae2:wireless_access_point" />. Это открывает различные перки в зависимости от элемента и установленных карточек. Для работы дополнительных функций нужно находиться в зоне действия привязанной точки доступа.

<br/>

## Установка улучшений

Наденьте броню, затем откройте меню настройки клавишей (по умолчанию N).

![QAGUI](../pic/quantum_armor_config.png)

Здесь можно добавлять и удалять улучшения, включать/отключать их и настраивать параметры.

<br/>

## Базовая карточка улучшения

<ItemImage id="advanced_ae:quantum_upgrade_base" scale="2"></ItemImage>

<ItemLink id="advanced_ae:quantum_upgrade_base" /> сама по себе ничего не делает, но используется как ингредиент для всех карточек улучшений.

<br/>

## Карточка автокормления

<ItemImage id="advanced_ae:auto_feeding_card" scale="2"></ItemImage>

<ItemLink id="advanced_ae:auto_feeding_card" /> позволяет выбрать предметы для автоматического питания игрока. Перетащите нужные предметы в слоты фильтра — при привязке к сети броня будет автоматически искать их в системе и кормить игрока при голоде.

<br/>

## Карточка автопополнения

<ItemImage id="advanced_ae:auto_stock_card" scale="2"></ItemImage>

<ItemLink id="advanced_ae:auto_stock_card" /> также требует привязки к сети и нахождения в зоне точки доступа. Позволяет настроить несколько стеков предметов, которые всегда будут поддерживаться в инвентаре игрока в заданном количестве.

<br/>

## Карточки скорости

<Row gap="10">
<ItemImage id="advanced_ae:walk_speed_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:sprint_speed_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:swim_speed_card" scale="2"></ItemImage>
</Row>

* <ItemLink id="advanced_ae:walk_speed_card" />
* <ItemLink id="advanced_ae:sprint_speed_card" />
* <ItemLink id="advanced_ae:swim_speed_card" />

Улучшают скорость передвижения. Все имеют настраиваемые значения, влияют на движение в приседании и полёте. Можно использовать для замедления — удобно при других эффектах ускорения.

<br/>

## Карточки прыжка

<Row gap="10">
<ItemImage id="advanced_ae:jump_height_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:step_assist_card" scale="2"></ItemImage>
</Row>

* <ItemLink id="advanced_ae:jump_height_card" />
* <ItemLink id="advanced_ae:step_assist_card" />

Изменяют вертикальное движение: настраиваемая высота прыжка и автоподъём на блоки.

<br/>

## Карточки полёта

<Row gap="10">
<ItemImage id="advanced_ae:flight_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:flight_drift_card" scale="2"></ItemImage>
</Row>

### Карточка полёта

<ItemLink id="advanced_ae:flight_card" /> включает творческий полёт. Скорость настраивается через слайдер. Суммируется с карточками скорости ходьбы/бега.

### Карточка инерции полёта

<ItemLink id="advanced_ae:flight_drift_card" /> работает только при установленной карточке полёта. Добавляет слайдер для настройки инерции: меньшее значение — быстрее остановка. При значении 0 остановка мгновенная.

<br/>

## Карточка зарядки ME

<ItemImage id="advanced_ae:recharging_card" scale="2"></ItemImage>

<ItemLink id="advanced_ae:recharging_card" /> включает беспроводную зарядку элемента брони от ME-сети. Требует привязки и нахождения в зоне точки доступа. В нагруднике также заряжает предметы в слотах инвентаря.

<br/>

## Карточка переносного верстака

<ItemImage id="advanced_ae:portable_workbench_card" scale="2"></ItemImage>

<ItemLink id="advanced_ae:portable_workbench_card" /> добавляет переносной верстак для ячеек. Открывается настроенной клавишей и работает идентично блочной версии.

<br/>

## Карточка быстрого крафта

<ItemImage id="advanced_ae:pick_craft_card" scale="2"></ItemImage>

<ItemLink id="advanced_ae:pick_craft_card" /> добавляет новую возможность: нажатие клавиши запускает автокрафт блока, на который смотрит игрок. Требует привязки к сети и наличия подходящего шаблона. Появится запрос количества — далее процесс идёт как обычный автокрафт.

<br/>

## Карточки утилит

<Row gap="10">
<ItemImage id="advanced_ae:night_vision_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:lava_immunity_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:water_breathing_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:magnet_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:camo_card" scale="2"></ItemImage>
</Row>

* <ItemLink id="advanced_ae:night_vision_card" />
* <ItemLink id="advanced_ae:lava_immunity_card" />
* <ItemLink id="advanced_ae:water_breathing_card" />
* <ItemLink id="advanced_ae:magnet_card" />
* <ItemLink id="advanced_ae:camo_card" />

Ночное зрение, иммунитет к лаве, дыхание под водой, магнит и маскировка. У магнита есть экран настройки фильтра предметов и дальности притяжения.

<br/>

## Защитные карточки

<Row gap="10">
<ItemImage id="advanced_ae:hp_buffer_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:regeneration_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:evasion_card" scale="2"></ItemImage>
</Row>

* <ItemLink id="advanced_ae:hp_buffer_card" /> — увеличивает максимальное здоровье
* <ItemLink id="advanced_ae:regeneration_card" /> — увеличивает скорость регенерации
* <ItemLink id="advanced_ae:evasion_card" /> — шанс полного иммунитета к любому урону

<br/>

## Атакующие карточки

<Row gap="10">
<ItemImage id="advanced_ae:strength_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:attack_speed_card" scale="2"></ItemImage>
</Row>

* <ItemLink id="advanced_ae:strength_card" />
* <ItemLink id="advanced_ae:attack_speed_card" />

Увеличивают урон в ближнем бою и скорость атаки.

<br/>

## Карточки характеристик

<Row gap="10">
<ItemImage id="advanced_ae:luck_card" scale="2"></ItemImage>
<ItemImage id="advanced_ae:reach_card" scale="2"></ItemImage>
</Row>

* <ItemLink id="advanced_ae:luck_card" /> — увеличивает удачу для лучшего лута
* <ItemLink id="advanced_ae:reach_card" /> — увеличивает дальность взаимодействия с блоками (настраивается)

<br/>

## Ещё впереди

Броневой комплект выпущен как базовая версия — планируется много новых функций!
