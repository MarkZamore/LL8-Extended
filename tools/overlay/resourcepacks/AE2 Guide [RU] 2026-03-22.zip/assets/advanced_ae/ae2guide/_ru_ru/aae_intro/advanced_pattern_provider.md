---
navigation:
  parent: aae_intro/aae_intro-index.md
  title: ME Усовершенствованный поставщик шаблонов
  icon: advanced_ae:adv_pattern_provider
categories:
  - advanced devices
item_ids:
  - advanced_ae:adv_pattern_provider
  - advanced_ae:small_adv_pattern_provider
  - advanced_ae:adv_pattern_provider_part
  - advanced_ae:small_adv_pattern_provider_part
---

# ME Усовершенствованный поставщик шаблонов

<Row gap="20">
<BlockImage id="advanced_ae:adv_pattern_provider" scale="8"></BlockImage>
<BlockImage id="advanced_ae:adv_pattern_provider" p:push_direction="up" scale="8"></BlockImage>
<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_app_part.snbt"></ImportStructure>
</GameScene>
</Row>

ME Усовершенствованный поставщик шаблонов — новый тип <ItemLink id="ae2:pattern_provider" />, который улучшает стандартную версию или <ItemLink id="extendedae:ex_pattern_provider" />, добавляя возможность настроить грань, на которую отправляется каждый конкретный ингредиент шаблона. Это позволяет автоматизировать машины с несколькими входами — одним блоком, без труб!

*Привет тебе, Mekanism.*

Для использования этой функции нужно вставить <ItemLink id="advanced_ae:adv_processing_pattern" />, созданный путём обработки обычного шаблона в <ItemLink id="advanced_ae:adv_pattern_encoder" />.

Также доступна расширенная версия, вмещающая до 36 шаблонов.

![AAEGui](../pic/app_gui.png)
