---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Нарезчик микросхем
    icon: extendedae:circuit_cutter
categories:
- extended devices
item_ids:
- extendedae:circuit_cutter
---

# Нарезчик микросхем

<Row gap="20">
<BlockImage id="extendedae:circuit_cutter" scale="8"></BlockImage>
</Row>

Устали от медленного гравировщика? Нарезчик микросхем нарежет блоки материалов прямо в [печатные схемы](ae2:items-blocks-machines/processors.md), работая до 9 раз быстрее гравировщика.

**Внимание: стеклянные грани без портов не подключаются к сети.**
