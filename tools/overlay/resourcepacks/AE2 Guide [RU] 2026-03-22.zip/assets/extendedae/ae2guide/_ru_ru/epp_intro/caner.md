---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME Консервировщик
    icon: extendedae:caner
categories:
- extended devices
item_ids:
- extendedae:caner
---

# ME Консервировщик

<BlockImage id="extendedae:caner" scale="8"></BlockImage>

ME Консервировщик — машина для наполнения контейнеров: жидкостями, газом Mekanism, маной Botania и даже энергией!

Первый слот — то, чем наполняем, второй — что наполняем.

Потребляет энергию: 80 AE за операцию.

![GUI](../pic/caner_gui.png)

По умолчанию поддерживает только жидкости. Для других типов нужно установить соответствующее дополнение.

### Поддерживаемые дополнения:
- Applied Flux
- Applied Mekanistics
- Applied Botanics Addon

## Автокрафт с ME Консервировщиком

К сети и подаче энергии подключаются только верхняя и нижняя стороны.

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../structure/caner_example.snbt"></ImportStructure>
</GameScene>

Простая схема с ME Консервировщиком. Он автоматически выбрасывает заполненный предмет при получении ингредиентов от <ItemLink id="ae2:pattern_provider" />.

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../structure/caner_auto.snbt"></ImportStructure>
</GameScene>

Шаблон должен содержать только то, чем наполняем, и контейнер. Примеры:

Наполнить ведро водой:

![P1](../pic/fill_water.png)

Зарядить Energy Tablet (требуется Applied Flux):

![P1](../pic/fill_energy.png)

## Слив

ME Консервировщик также умеет сливать содержимое контейнеров в режиме слива. Для этого нужно поменять входы и выходы в шаблоне местами.
