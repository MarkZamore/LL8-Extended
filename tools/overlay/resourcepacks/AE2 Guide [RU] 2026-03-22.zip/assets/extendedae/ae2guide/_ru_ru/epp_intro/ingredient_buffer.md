---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME Буфер ингредиентов
    icon: extendedae:ingredient_buffer
categories:
- extended devices
item_ids:
- extendedae:ingredient_buffer
---

# ME Буфер ингредиентов

<BlockImage id="extendedae:ingredient_buffer" scale="8"></BlockImage>

Блок хранения, вмещающий до 36 различных типов содержимого: предметов, жидкостей и т.д.
