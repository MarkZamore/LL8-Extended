---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME Шина экспорта по моду
    icon: extendedae:mod_export_bus
categories:
- extended devices
item_ids:
- extendedae:mod_export_bus
---

# ME Шина экспорта по моду

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_mod_export_bus.snbt"></ImportStructure>
</GameScene>

ME Шина экспорта по моду — это <ItemLink id="ae2:export_bus" />, которую можно фильтровать по названию или ID мода.

Для фильтрации нескольких модов разделяйте их ID запятой.

![PIC](../pic/mod_bus_name2.png)
