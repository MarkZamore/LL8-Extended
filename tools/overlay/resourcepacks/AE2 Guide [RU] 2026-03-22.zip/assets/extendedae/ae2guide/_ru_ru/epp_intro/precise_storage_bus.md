---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME Точная шина хранения
    icon: extendedae:precise_storage_bus
categories:
- extended devices
item_ids:
- extendedae:precise_storage_bus
---

# ME Точная шина хранения

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_precise_storage_bus.snbt"></ImportStructure>
</GameScene>

ME Точная шина хранения — это <ItemLink id="ae2:storage_bus" /> с числовым фильтром: принимает предметы только до заданного лимита.

![GUI](../pic/pre_storage_bus.png)
