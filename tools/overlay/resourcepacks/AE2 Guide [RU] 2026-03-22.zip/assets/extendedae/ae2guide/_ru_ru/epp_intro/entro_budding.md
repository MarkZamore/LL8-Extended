---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Будирующий Entro-флюикс
    icon: extendedae:entro_budding_fully
categories:
- entro system
item_ids:
- extendedae:entro_budding_fully
- extendedae:entro_budding_mostly
- extendedae:entro_budding_half
- extendedae:entro_budding_hardly
- extendedae:entro_cluster_small
- extendedae:entro_cluster_medium
- extendedae:entro_cluster_large
- extendedae:entro_cluster
---

# Будирующий Entro-флюикс

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../structure/budding_entro.snbt"></ImportStructure>
  <IsometricCamera yaw="195" pitch="30"></IsometricCamera>
</GameScene>

Источник <ItemLink id="extendedae:entro_crystal" />. Получить будирующий Entro-флюикс можно, введя <ItemLink id="extendedae:entro_seed" /> в <ItemLink id="ae2:fluix_block" />.

Механизм роста Entro-почек схож с [цертусовым кварцем](ae2:items-blocks-machines/budding_certus.md). Однако деградация Entro-флюикса неизбежна — в конечном счёте он превратится в <ItemLink id="ae2:quartz_block" />.
Теоретически из одного полного блока без зачарования «Удача» можно получить ~10 <ItemLink id="extendedae:entro_crystal" />.

При разрушении будирующий Entro-флюикс **всегда** роняет одну единицу <ItemLink id="extendedae:entro_dust" />, в каком бы состоянии он ни был.
Недовыросшая почка роняет <ItemLink id="extendedae:entro_shard" />.
