---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME Активная плоскость формирования
    icon: extendedae:active_formation_plane
categories:
- extended devices
item_ids:
- extendedae:active_formation_plane
---

# ME Активная плоскость формирования

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_active_formation_plane.snbt"></ImportStructure>
</GameScene>

ME Активная плоскость формирования — это <ItemLink id="ae2:formation_plane" />, которая активно размещает блоки или выбрасывает предметы.

Не требует настройки подсети. Работает как <ItemLink id="ae2:export_bus" />, но вместо выгрузки в сундук — размещает блок в мире.
