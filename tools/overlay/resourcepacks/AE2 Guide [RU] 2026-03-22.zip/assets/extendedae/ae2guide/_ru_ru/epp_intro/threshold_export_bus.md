---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME Пороговая шина экспорта
    icon: extendedae:threshold_export_bus
categories:
- extended devices
item_ids:
- extendedae:threshold_export_bus
---

# ME Пороговая шина экспорта

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_threshold_export_bus.snbt"></ImportStructure>
</GameScene>

ME Пороговая шина экспорта работает, когда количество предмета в сети превышает или опускается ниже заданного порога.

## Пример

![GUI](../pic/thr_bus_gui1.png)

Порог меди — 128. Шина экспортирует медь, когда её в сети больше 128.

![GUI](../pic/thr_bus_gui2.png)

Тот же порог, но режим НИЖЕ: экспортирует медь, когда её в сети меньше 128.
