---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Кристалл Entro
    icon: extendedae:entro_crystal
categories:
- entro system
item_ids:
- extendedae:entro_crystal
---

# Кристалл Entro

<Row>
<ItemImage id="extendedae:entro_crystal" scale="4"></ItemImage>
</Row>

*«Кристаллы Entro проявляют сильнейшее измерительное сродство после введения эндер-пыли во флюикс-кристаллы и способны резонировать сквозь пространство-время.»*

Основной ингредиент для большинства предметов и машин ExtendedAE. Введите <ItemLink id="extendedae:entro_seed" /> в <ItemLink id="ae2:fluix_block" />, чтобы создать [будирующий Entro-флюикс](./entro_budding.md), затем собирайте Entro-кластеры для получения кристаллов.
