---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME Шина хранения по тегу
    icon: extendedae:tag_storage_bus
categories:
- extended devices
item_ids:
- extendedae:tag_storage_bus
---

# ME Шина хранения по тегу

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_tag_storage_bus.snbt"></ImportStructure>
</GameScene>

ME Шина хранения по тегу — это <ItemLink id="ae2:storage_bus" />, фильтруемая по тегам предметов или жидкостей с поддержкой базовых логических операторов.

Примеры:

- Принимать только сырую руду

c:raw_materials/*

- Принимать все слитки и самоцветы

c:ingots/* | c:gems/*
