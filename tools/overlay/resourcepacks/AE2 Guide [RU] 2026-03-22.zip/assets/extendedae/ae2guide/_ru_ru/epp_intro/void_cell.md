---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME Ячейка уничтожения
    icon: extendedae:void_cell
categories:
- extended items
item_ids:
- extendedae:void_cell
---

# ME Ячейка уничтожения

Карманный конденсатор в виде ячейки накопителя.

<ItemImage id="extendedae:void_cell" scale="4"></ItemImage>

Перед использованием ячейку нужно настроить на <ItemLink id="ae2:cell_workbench" />. Она уничтожает всё, что попадает под фильтр, или преобразует в <ItemLink id="ae2:matter_ball" /> / <ItemLink id="ae2:singularity" />, как <ItemLink id="ae2:condenser" />.

ПКМ для открытия настроек.

![GUI](../pic/void_cell.png)
