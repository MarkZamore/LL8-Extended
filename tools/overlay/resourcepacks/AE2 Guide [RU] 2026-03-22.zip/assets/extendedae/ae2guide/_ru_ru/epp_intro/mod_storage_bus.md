---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME Шина хранения по моду
    icon: extendedae:mod_storage_bus
categories:
- extended devices
item_ids:
- extendedae:mod_storage_bus
---

# ME Шина хранения по моду

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_mod_storage_bus.snbt"></ImportStructure>
</GameScene>

ME Шина хранения по моду — это <ItemLink id="ae2:storage_bus" />, которую можно фильтровать по названию или ID мода.

Для фильтрации нескольких модов разделяйте их ID запятой.

![PIC](../pic/mod_bus_name.png)
