---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Семя Entro
    icon: extendedae:entro_seed
categories:
- entro system
item_ids:
- extendedae:entro_seed
---

# Семя Entro

<Row>
<ItemImage id="extendedae:entro_seed" scale="4"></ItemImage>
</Row>

Семена содержат мощную Entro-энергию. ПКМ по <ItemLink id="ae2:fluix_block" /> с семенем в руке превратит его в [будирующий Entro-флюикс](./entro_budding.md).
Можно также использовать <ItemLink id="extendedae:crystal_assembler" /> для введения семени, но это даёт [будирование](./entro_budding.md) более низкого grade по сравнению с ручным способом.
