---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME Бесконечная ячейка
    icon: extendedae:infinity_water_cell
categories:
- extended items
item_ids:
- extendedae:infinity_water_cell
- extendedae:infinity_cobblestone_cell
---

# ME Бесконечная ячейка

Простой источник воды и булыжника в форме ячейки хранения.

<Row>
<ItemImage id="extendedae:infinity_water_cell" scale="4"></ItemImage>
<ItemImage id="extendedae:infinity_cobblestone_cell" scale="4"></ItemImage>
</Row>

Вмещают 2,1 миллиарда предметов/жидкостей. Из них можно бесконечно извлекать воду или булыжник, а также закачивать их обратно.
