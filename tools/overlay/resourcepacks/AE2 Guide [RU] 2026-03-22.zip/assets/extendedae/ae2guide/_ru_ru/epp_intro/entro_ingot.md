---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Слиток Entro
    icon: extendedae:entro_ingot
categories:
- entro system
item_ids:
- extendedae:entro_ingot
---

# Слиток Entro

<Row>
<ItemImage id="extendedae:entro_ingot" scale="4"></ItemImage>
</Row>

*«Кристалл Entro слишком хрупок для использования в раме машины, но его сплав с золотым слитком улучшает пластичность.»*

Используется для крафта <ItemLink id="extendedae:machine_frame" /> и ряда других компонентов ExtendedAE.
