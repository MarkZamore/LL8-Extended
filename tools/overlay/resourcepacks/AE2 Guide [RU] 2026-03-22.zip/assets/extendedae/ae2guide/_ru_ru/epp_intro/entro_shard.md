---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Осколок Entro
    icon: extendedae:entro_shard
categories:
- entro system
item_ids:
- extendedae:entro_shard
---

# Осколок Entro

<Row>
<ItemImage id="extendedae:entro_shard" scale="4"></ItemImage>
</Row>

Выпадает при разрушении [почки Entro](./entro_budding.md) до её полного роста. 8 осколков можно скрафтить обратно в <ItemLink id="extendedae:entro_crystal" />.
