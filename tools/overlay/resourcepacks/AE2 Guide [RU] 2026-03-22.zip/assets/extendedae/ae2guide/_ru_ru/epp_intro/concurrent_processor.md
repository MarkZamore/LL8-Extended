---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Конкурентный процессор
    icon: extendedae:concurrent_processor
categories:
- extended foundation
item_ids:
- extendedae:concurrent_processor
- extendedae:concurrent_processor_press
- extendedae:concurrent_processor_print
---

# Конкурентный процессор

<Row>
<ItemImage id="extendedae:concurrent_processor" scale="4"></ItemImage>
<ItemImage id="extendedae:concurrent_processor_press" scale="4"></ItemImage>
<ItemImage id="extendedae:concurrent_processor_print" scale="4"></ItemImage>
</Row>

Конкурентный процессор используется в многопоточных машинах, позволяя им обрабатывать несколько задач одновременно.
