---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Кристальный сборщик
    icon: extendedae:crystal_assembler
categories:
- extended foundation
item_ids:
- extendedae:crystal_assembler
---

# Кристальный сборщик

<Row>
<BlockImage id="extendedae:crystal_assembler" scale="8"></BlockImage>
</Row>

Большинство устройств ExtendedAE слишком сложны для крафтового стола — для их создания понадобится Кристальный сборщик.

**Внимание: грань с экраном не подключается к сети.**

Также умеет выполнять некоторые рецепты трансформации в мире, например синтез флюикса.
