---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME Шина экспорта по тегу
    icon: extendedae:tag_export_bus
categories:
- extended devices
item_ids:
- extendedae:tag_export_bus
---

# ME Шина экспорта по тегу

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_tag_export_bus.snbt"></ImportStructure>
</GameScene>

ME Шина экспорта по тегу — это <ItemLink id="ae2:export_bus" />, которую можно фильтровать по тегам предметов или жидкостей.

Правила фильтрации аналогичны <ItemLink id="extendedae:tag_storage_bus" />.
