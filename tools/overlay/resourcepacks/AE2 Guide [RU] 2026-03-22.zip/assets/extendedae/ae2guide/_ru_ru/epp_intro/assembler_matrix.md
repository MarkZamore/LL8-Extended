---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Матрица сборщиков
    icon: extendedae:assembler_matrix_frame
categories:
- extended devices
item_ids:
- extendedae:assembler_matrix_frame
- extendedae:assembler_matrix_wall
- extendedae:assembler_matrix_glass
- extendedae:assembler_matrix_pattern
- extendedae:assembler_matrix_crafter
- extendedae:assembler_matrix_speed
---

# Матрица сборщиков

<Row>
<BlockImage id="extendedae:assembler_matrix_frame" p:formed="true" p:powered="true" scale="5"></BlockImage>
<BlockImage id="extendedae:assembler_matrix_wall" scale="5"></BlockImage>
<BlockImage id="extendedae:assembler_matrix_glass" scale="5"></BlockImage>
</Row>
<Row>
<BlockImage id="extendedae:assembler_matrix_pattern" scale="5"></BlockImage>
<BlockImage id="extendedae:assembler_matrix_crafter" scale="5"></BlockImage>
<BlockImage id="extendedae:assembler_matrix_speed" scale="5"></BlockImage>
</Row>

Матрица сборщиков — мультиблочная структура, объединяющая <ItemLink id="ae2:molecular_assembler" /> и <ItemLink id="ae2:pattern_provider" />.
При наличии достаточного количества <ItemLink id="ae2:crafting_accelerator" /> в сети она может выполнять множество заданий на крафт одновременно, экономя каналы.

## Структура

<GameScene zoom="3" background="transparent" interactive={true}>
  <ImportStructure src="../structure/assembler_matrix.snbt"></ImportStructure>
</GameScene>

Прямоугольный параллелепипед, длина рёбер от 3 до 7 блоков.
- Рёбра — из рамок матрицы сборщиков.
- Грани — из стен или стёкол матрицы.
- Внутренность — из ядер шаблонов, крафта или скорости.

Матрица должна содержать хотя бы одно ядро шаблонов и одно ядро крафта.
Она должна быть полностью заполнена и не может быть полой.
При правильной сборке и подаче питания линии на рамках станут синими.

## Ядра матрицы

Существует 3 вида ядер:

- **Ядро шаблонов**

Матрица принимает шаблоны только из ядер шаблонов. Каждое ядро предоставляет 36 слотов.

- **Ядро крафта**

Матрица распределяет задания на крафт между ядрами крафта. Каждое ядро выполняет до 8 заданий одновременно.

- **Ядро скорости**

Аналог <ItemLink id="ae2:speed_card" /> для матрицы. 5 ядер скорости обеспечивают полную скорость работы.
Установка более 5 ядер скорости не даёт дополнительного ускорения.

## Интерфейс

ПКМ по собранной и работающей матрице открывает её интерфейс.

![GUI](../pic/assembler_matrix.png)

В нём можно добавлять и искать шаблоны, а также просматривать количество текущих заданий на крафт.
