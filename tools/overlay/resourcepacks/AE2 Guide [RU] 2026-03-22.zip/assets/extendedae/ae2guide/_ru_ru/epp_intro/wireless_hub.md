---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME Беспроводной концентратор
    icon: extendedae:wireless_hub
categories:
- extended devices
item_ids:
- extendedae:wireless_hub
---

# ME Беспроводной концентратор

<Row gap="20">
<BlockImage id="extendedae:wireless_hub" scale="6"></BlockImage>
</Row>

ME Беспроводной концентратор работает точно так же, как <ItemLink id="extendedae:wireless_connect" />, но поддерживает одновременное подключение до 8 концентраторов/коннекторов.

## Настройка подключений

В концентраторе 8 портов. При связывании через <ItemLink id="extendedae:wireless_tool" /> свободный порт определяется автоматически.

Если все порты заняты, перед установкой нового подключения нужно вручную освободить порт кнопкой «X».
