---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME Расширенный накопитель
    icon: extendedae:ex_drive
categories:
- extended devices
item_ids:
- extendedae:ex_drive
---

# ME Расширенный накопитель

<Row gap="20">
<BlockImage id="extendedae:ex_drive" scale="8"></BlockImage>
</Row>

ME Расширенный накопитель — это <ItemLink id="ae2:drive" /> с увеличенным инвентарём. Вмещает 20 ячеек хранения.
