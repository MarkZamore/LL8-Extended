---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME Пороговый эмиттер уровня
    icon: extendedae:threshold_level_emitter
categories:
- extended devices
item_ids:
- extendedae:threshold_level_emitter
---

# ME Пороговый эмиттер уровня

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_threshold_level_emitter.snbt"></ImportStructure>
</GameScene>

Работает как RS-триггер. Отключает сигнал редстоуна, когда количество предмета в сети опускается ниже нижнего порога, и включает, когда превышает верхний.

Например, нижний порог — 100, верхний — 150.

Изначально сеть пуста — эмиттер неактивен.

Когда количество предмета превысит 150, эмиттер начнёт посылать сигнал редстоуна.

При снижении количества ниже 150 сигнал продолжает идти.

Когда количество упадёт ниже 100 — эмиттер отключится.
