---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Расширенный гравировщик
    icon: extendedae:ex_inscriber
categories:
- extended devices
item_ids:
- extendedae:ex_inscriber
---

# Расширенный гравировщик

<Row gap="20">
<BlockImage id="extendedae:ex_inscriber" scale="8"></BlockImage>
</Row>

Расширенный гравировщик — улучшенная версия <ItemLink id="ae2:inscriber" />.

Выполняет 4 задания одновременно.

Имеет кнопку смены максимального размера стека, как и обычный гравировщик.

При использовании с <ItemLink id="ae2:pattern_provider" /> рекомендуется установить размер стека равным 1, чтобы избежать возможных проблем.
