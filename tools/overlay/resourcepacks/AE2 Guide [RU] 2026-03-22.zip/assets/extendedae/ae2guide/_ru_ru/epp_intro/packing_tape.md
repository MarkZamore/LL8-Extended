---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME Упаковочная лента
    icon: extendedae:me_packing_tape
categories:
- extended items
item_ids:
- extendedae:me_packing_tape
- extendedae:package
---

# ME Упаковочная лента

ME Упаковочная лента упаковывает ME-устройства в мире в предмет «Упакованное устройство».

<Row>
<ItemImage id="extendedae:me_packing_tape" scale="4"></ItemImage>
<ItemImage id="extendedae:package" scale="4"></ItemImage>
</Row>

## Упаковка

Shift + ПКМ по ME-устройству с лентой в руке — вы получите упакованный предмет. Все настройки и содержимое устройства сохранятся. Очень удобно при переносе ME-сети.

Лента поддерживает только устройства из списка ниже (список настраивается).

### Поддерживаемые устройства по умолчанию

|                                      Устройство                                       |                                 Название                                  |
|:---------------------------------------------------------------------------------:|:---------------------------------------------------------------------:|
|    <ItemImage id="extendedae:ex_interface_part" scale="3"></ItemImage>     |    <ItemLink id="extendedae:ex_interface_part"></ItemLink>     |
| <ItemImage id="extendedae:ex_pattern_provider_part" scale="3"></ItemImage> | <ItemLink id="extendedae:ex_pattern_provider_part"></ItemLink> |
|       <ItemImage id="extendedae:ex_interface" scale="3"></ItemImage>       |       <ItemLink id="extendedae:ex_interface"></ItemLink>       |
|   <ItemImage id="extendedae:ex_pattern_provider" scale="3"></ItemImage>    |   <ItemLink id="extendedae:ex_pattern_provider"></ItemLink>    |
|            <ItemImage id="ae2:cable_interface" scale="3"></ItemImage>             |            <ItemLink id="ae2:cable_interface"></ItemLink>             |
|         <ItemImage id="ae2:cable_pattern_provider" scale="3"></ItemImage>         |         <ItemLink id="ae2:cable_pattern_provider"></ItemLink>         |
|               <ItemImage id="ae2:interface" scale="3"></ItemImage>                |               <ItemLink id="ae2:interface"></ItemLink>                |
|            <ItemImage id="ae2:pattern_provider" scale="3"></ItemImage>            |            <ItemLink id="ae2:pattern_provider"></ItemLink>            |
|                 <ItemImage id="ae2:drive" scale="3"></ItemImage>                  |                 <ItemLink id="ae2:drive"></ItemLink>                  |

## Распаковка

Нажмите ПКМ с упакованным предметом в руке так же, как если бы вы ставили блок или кабельную часть — устройство восстановится из упаковки.
