---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Блок Entro
    icon: extendedae:entro_block
categories:
- entro system
item_ids:
- extendedae:entro_block
---

# Блок Entro

<Row>
<BlockImage id="extendedae:entro_block" scale="8"></BlockImage>
</Row>

Блок для компактного хранения <ItemLink id="extendedae:entro_crystal" />.
