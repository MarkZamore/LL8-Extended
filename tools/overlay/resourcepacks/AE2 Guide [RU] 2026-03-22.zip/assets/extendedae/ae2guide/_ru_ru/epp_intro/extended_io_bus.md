---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME Расширенные шины экспорта/импорта
    icon: extendedae:ex_import_bus_part
categories:
- extended devices
item_ids:
- extendedae:ex_import_bus_part
- extendedae:ex_export_bus_part
---

# ME Расширенные шины импорта/экспорта

<Row gap="20">
<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_ex_import_bus.snbt"></ImportStructure>
</GameScene>
<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_ex_export_bus.snbt"></ImportStructure>
</GameScene>
</Row>

ME Расширенные шины импорта/экспорта работают быстрее обычных <ItemLink id="ae2:import_bus" />/<ItemLink id="ae2:export_bus" />
(по умолчанию множитель скорости ×8, настраивается).

Также имеют больше слотов для улучшений.
