---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Расширенный молекулярный сборщик
    icon: extendedae:ex_molecular_assembler
categories:
- extended devices
item_ids:
- extendedae:ex_molecular_assembler
---

# Расширенный молекулярный сборщик

<Row gap="20">
<BlockImage id="extendedae:ex_molecular_assembler" scale="8"></BlockImage>
</Row>

Расширенный молекулярный сборщик — улучшенная версия <ItemLink id="ae2:molecular_assembler" />.

Выполняет 8 заданий одновременно (при наличии <ItemLink id="ae2:crafting_accelerator" /> в сети) и работает в 2 раза быстрее обычного.

Принимает задания только от <ItemLink id="ae2:pattern_provider" /> — вставить шаблон напрямую нельзя.
