---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME Увеличенный интерфейс
    icon: extendedae:oversize_interface
categories:
- extended devices
item_ids:
- extendedae:oversize_interface
- extendedae:oversize_interface_part
---

# ME Увеличенный интерфейс

<Row gap="20">
<BlockImage id="extendedae:oversize_interface" scale="8"></BlockImage>
<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_oversize_interface.snbt"></ImportStructure>
</GameScene>
</Row>

ME Увеличенный интерфейс имеет столько же слотов, что и <ItemLink id="extendedae:ex_interface" />, но каждый слот вмещает в ×16 больше предметов (настраивается). Итого 1024 (64×16) предмета на слот.

Для некоторых предметов из других модов множитель можно изменить в конфиге.
