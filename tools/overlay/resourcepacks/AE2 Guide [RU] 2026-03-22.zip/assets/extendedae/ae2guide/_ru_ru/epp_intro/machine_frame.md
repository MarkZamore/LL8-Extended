---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Расширенная рама машины
    icon: extendedae:machine_frame
categories:
- extended foundation
item_ids:
- extendedae:machine_frame
---

# Начало пути в ExtendedAE

<Row>
<BlockImage id="extendedae:machine_frame" scale="8"></BlockImage>
</Row>

Собрав достаточно <ItemLink id="extendedae:entro_crystal" />, вы наконец сможете скрафтить первую расширенную раму машины.
Рамы — основа ExtendedAE, большинство блочных машин мода требуют их для крафта.
