---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME Умная плоскость аннигиляции
    icon: extendedae:smart_annihilation_plane
categories:
- extended devices
item_ids:
- extendedae:smart_annihilation_plane
---

# ME Умная плоскость аннигиляции

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_smart_annihilation_plane.snbt"></ImportStructure>
</GameScene>

ME Умная плоскость аннигиляции — это <ItemLink id="ae2:annihilation_plane" />, которая ломает блоки или подбирает предметы по фильтру конфигурации.

Не требует настройки подсети. Работает как <ItemLink id="ae2:import_bus" />, но вместо извлечения из сундука — ломает блок в мире.
