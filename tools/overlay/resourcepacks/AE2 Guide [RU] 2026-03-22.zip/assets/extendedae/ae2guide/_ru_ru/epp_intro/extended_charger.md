---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Расширенное зарядное устройство
    icon: extendedae:ex_charger
categories:
- extended devices
item_ids:
- extendedae:ex_charger
---

# Расширенное зарядное устройство

<Row gap="20">
<BlockImage id="extendedae:ex_charger" scale="8"></BlockImage>
</Row>

Расширенное зарядное устройство — улучшенная версия <ItemLink id="ae2:charger" />.

Заряжает 4 предмета одновременно.
