---
navigation:
    title: Введение в Extended AE
    position: 60
---

# Расширь свою ME сеть!

Extended AE возвращает возможности AE из версий 1.7.10/1.12.2 в современную AE.

[Extended AE на GitHub](https://github.com/GlodBlock/ExtendedAE)

## Система Entro-кристаллов
<CategoryIndex category="entro system"></CategoryIndex>

## Расширенная база
<CategoryIndex category="extended foundation"></CategoryIndex>

## Расширенные устройства
<CategoryIndex category="extended devices"></CategoryIndex>

## Расширенные предметы
<CategoryIndex category="extended items"></CategoryIndex>
