---
navigation:
  parent: epp_intro/epp_intro-index.md
  title: Кварцевая смесь
  icon: extendedae:quartz_blend
categories:
  - extended foundation
item_ids:
  - extendedae:quartz_blend
---

# Кварцевая смесь

<Row>
<ItemImage id="extendedae:quartz_blend" scale="4"></ItemImage>
</Row>

Смесь кварца, угля и песка. При плавке даёт больше <ItemLink id="ae2:silicon" />, чем прямая плавка кварцевой пыли.
