---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Улучшения ME-устройств
    icon: extendedae:pattern_provider_upgrade
categories:
- extended items
item_ids:
- extendedae:pattern_provider_upgrade
- extendedae:interface_upgrade
- extendedae:io_bus_upgrade
- extendedae:pattern_terminal_upgrade
- extendedae:drive_upgrade
- extendedae:wireless_connector_upgrade
---

# Улучшения ME-устройств

Позволяют заменить обычные ME-устройства их расширенными версиями без разрушения.

<Row>
<ItemImage id="extendedae:pattern_provider_upgrade" scale="4"></ItemImage>
<ItemImage id="extendedae:interface_upgrade" scale="4"></ItemImage>
<ItemImage id="extendedae:io_bus_upgrade" scale="4"></ItemImage>
<ItemImage id="extendedae:pattern_terminal_upgrade" scale="4"></ItemImage>
<ItemImage id="extendedae:drive_upgrade" scale="4"></ItemImage>
<ItemImage id="extendedae:wireless_connector_upgrade" scale="4"></ItemImage>
</Row>

Shift + ПКМ по устройству с улучшением в руке — устройство заменится расширенной версией. Все настройки и содержимое сохранятся.

<GameScene zoom="6" background="transparent">
  <ImportStructure src="../structure/upgrade_show_1.snbt"></ImportStructure>
  <BoxAnnotation color="#ffffff" min="1 0 0" max="4 1 1">
        Обычные поставщики шаблонов. Можно улучшить с помощью улучшения поставщика шаблонов.
        <ItemImage id="extendedae:pattern_provider_upgrade" scale="2"></ItemImage>
  </BoxAnnotation>
</GameScene>
<GameScene zoom="6" background="transparent">
  <ImportStructure src="../structure/upgrade_show_2.snbt"></ImportStructure>
  <BoxAnnotation color="#ffffff" min="1 0 0" max="4 1 1">
        Расширенные поставщики шаблонов сохраняют все настройки и шаблоны оригинала.
  </BoxAnnotation>
</GameScene>

## Таблица улучшений

|                                   Улучшение                                    |                           Обычное устройство                            |                              Расширенное устройство                               |
|:----------------------------------------------------------------------------:|:------------------------------------------------------------------:|:--------------------------------------------------------------------------:|
|  <ItemImage id="extendedae:pattern_provider_upgrade" scale="3"></ItemImage>  |    <ItemImage id="ae2:pattern_provider" scale="3"></ItemImage>     |   <ItemImage id="extendedae:ex_pattern_provider" scale="3"></ItemImage>    |
|  <ItemImage id="extendedae:pattern_provider_upgrade" scale="3"></ItemImage>  | <ItemImage id="ae2:cable_pattern_provider" scale="3"></ItemImage>  | <ItemImage id="extendedae:ex_pattern_provider_part" scale="3"></ItemImage> |
|     <ItemImage id="extendedae:interface_upgrade" scale="3"></ItemImage>      |        <ItemImage id="ae2:interface" scale="3"></ItemImage>        |       <ItemImage id="extendedae:ex_interface" scale="3"></ItemImage>       |
|     <ItemImage id="extendedae:interface_upgrade" scale="3"></ItemImage>      |     <ItemImage id="ae2:cable_interface" scale="3"></ItemImage>     |    <ItemImage id="extendedae:ex_interface_part" scale="3"></ItemImage>     |
|       <ItemImage id="extendedae:io_bus_upgrade" scale="3"></ItemImage>       |       <ItemImage id="ae2:import_bus" scale="3"></ItemImage>        |    <ItemImage id="extendedae:ex_import_bus_part" scale="3"></ItemImage>    |
|       <ItemImage id="extendedae:io_bus_upgrade" scale="3"></ItemImage>       |       <ItemImage id="ae2:export_bus" scale="3"></ItemImage>        |    <ItemImage id="extendedae:ex_export_bus_part" scale="3"></ItemImage>    |
|  <ItemImage id="extendedae:pattern_terminal_upgrade" scale="3"></ItemImage>  | <ItemImage id="ae2:pattern_access_terminal" scale="3"></ItemImage> |  <ItemImage id="extendedae:ex_pattern_access_part" scale="3"></ItemImage>  |
|       <ItemImage id="extendedae:drive_upgrade" scale="3"></ItemImage>        |          <ItemImage id="ae2:drive" scale="3"></ItemImage>          |         <ItemImage id="extendedae:ex_drive" scale="3"></ItemImage>         |
| <ItemImage id="extendedae:wireless_connector_upgrade" scale="3"></ItemImage> | <ItemImage id="extendedae:wireless_connect" scale="3"></ItemImage> |       <ItemImage id="extendedae:wireless_hub" scale="3"></ItemImage>       |
