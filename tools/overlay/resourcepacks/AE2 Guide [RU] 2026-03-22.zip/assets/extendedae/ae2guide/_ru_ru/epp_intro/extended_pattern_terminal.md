---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME Удлинённый терминал доступа к шаблонам
    icon: extendedae:ex_pattern_access_part
categories:
- extended devices
item_ids:
- extendedae:ex_pattern_access_part
- extendedae:wireless_ex_pat
---

# ME Удлинённый терминал доступа к шаблонам

ME Удлинённый терминал доступа к шаблонам предоставляет 3 дополнительных возможности по сравнению с <ItemLink id="ae2:pattern_access_terminal" />.

<Row gap="20">
<GameScene zoom="6" background="transparent">
<ImportStructure src="../structure/cable_ex_pattern_terminal.snbt"></ImportStructure>
<IsometricCamera yaw="180"></IsometricCamera>
</GameScene>
<ItemImage id="extendedae:wireless_ex_pat" scale="4"></ItemImage>
</Row>

## Улучшенный поиск шаблонов

Поиск шаблонов по названию ингредиентов или результатов.

![EPA1](../pic/epa_gui1.png)

## Подсветка шаблонов

Иногда найти нужный шаблон сложно, так как они отображаются группами. Удлинённый терминал умеет подсвечивать совпадающий шаблон прямо в интерфейсе.

![EPA2](../pic/epa_gui2.png)

## Подсветка поставщика шаблонов в мире

Неудобно искать застрявший поставщик шаблонов при большом крафте. Терминал умеет подсвечивать нужный поставщик прямо в мире.

![EPA3](../pic/epa_gui3.png)
