---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME Беспроводной коннектор
    icon: extendedae:wireless_connect
categories:
- extended devices
item_ids:
- extendedae:wireless_connect
- extendedae:wireless_tool
---

# ME Беспроводной коннектор

<Row gap="20">
<BlockImage id="extendedae:wireless_connect" scale="6"></BlockImage>
<ItemImage id="extendedae:wireless_tool" scale="6"></ItemImage>
</Row>

ME Беспроводной коннектор соединяет две сети как <ItemLink id="ae2:quantum_link" />, но с ограниченной дальностью и без возможности работы между измерениями. Поддерживает только соединение один-к-одному. Для соединений многие-ко-многим используйте <ItemLink id="extendedae:wireless_hub" />.

## Связывание коннекторов

Нажмите инструментом настройки беспроводной связи (ME Wireless Setup Kit) на два коннектора поочерёдно — они свяжутся.

Shift + нажатие очищает текущую настройку инструмента.

При успешной связи текстура коннектора изменится.

Несвязанные коннекторы:

<GameScene zoom="5" background="transparent">
  <ImportStructure src="../structure/wireless_connector_off.snbt"></ImportStructure>
</GameScene>

Связанные коннекторы:

<GameScene zoom="5" background="transparent">
  <ImportStructure src="../structure/wireless_connector_on.snbt"></ImportStructure>
</GameScene>

## Цвет

Коннекторы можно окрашивать, как кабели. Коннекторы и кабели одного цвета соединяются только между собой.

Для окраски используйте <ItemLink id="ae2:color_applicator" />.

Пример разводки коннекторов:

<GameScene zoom="3" background="transparent" interactive={true}>
  <ImportStructure src="../structure/wireless_connector_setup.snbt"></ImportStructure>
</GameScene>

## Потребление энергии

Чем дальше коннекторы друг от друга — тем больше энергии они потребляют. Зависимость нелинейная, при большом расстоянии потребление резко возрастает.

<ItemLink id="ae2:energy_card" /> снижает потребление: каждая карточка уменьшает его на 10%.
