---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: Пыль Entro
    icon: extendedae:entro_dust
categories:
- entro system
item_ids:
- extendedae:entro_dust
---

# Пыль Entro

<Row>
<ItemImage id="extendedae:entro_dust" scale="4"></ItemImage>
</Row>

Получается при измельчении <ItemLink id="extendedae:entro_crystal" /> или разрушении [будирующего Entro-флюикса](./entro_budding.md).

Используется для крафта некоторых машин ExtendedAE и <ItemLink id="extendedae:entro_ingot" />.
