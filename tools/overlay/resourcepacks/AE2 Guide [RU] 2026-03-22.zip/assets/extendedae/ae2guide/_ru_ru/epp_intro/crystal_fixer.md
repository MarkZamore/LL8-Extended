---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME Восстановитель кристаллов
    icon: extendedae:crystal_fixer
categories:
- extended devices
item_ids:
- extendedae:crystal_fixer
---

# ME Восстановитель кристаллов

<BlockImage id="extendedae:crystal_fixer" scale="8"></BlockImage>

ME Восстановитель кристаллов восстанавливает деградировавшие блоки будирующего цертусового кварца и повышает их grade.

Требует <ItemLink id="ae2:charged_certus_quartz_crystal" /> и энергию. ПКМ с кристаллом в руке для загрузки.

<Row gap="20">
<GameScene zoom="4" background="transparent">
  <ImportStructure src="../structure/crystal_fixer.snbt"></ImportStructure>
</GameScene>
</Row>
