---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME Точная шина экспорта
    icon: extendedae:precise_export_bus
categories:
- extended devices
item_ids:
- extendedae:precise_export_bus
---

# ME Точная шина экспорта

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_precise_export_bus.snbt"></ImportStructure>
</GameScene>

ME Точная шина экспорта экспортирует предметы/жидкости строго заданным количеством. Экспорт происходит только если контейнер может принять весь объём целиком.

## Пример

![GUI](../pic/pre_bus_gui1.png)

Настройка: экспортировать по 3 булыжника за операцию. Экспорт прекращается, когда в сети остаётся менее 3 булыжников.

![GUI](../pic/pre_bus_gui2.png)

Также прекращает экспорт, если контейнер не вмещает весь объём. Сундук вмещает только 2 булыжника — экспорт остановлен.
