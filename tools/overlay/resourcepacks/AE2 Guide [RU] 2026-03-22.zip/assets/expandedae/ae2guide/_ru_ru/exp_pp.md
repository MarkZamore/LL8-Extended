---
navigation:
  parent: expandedae-index.md
  title: Расширенный поставщик шаблонов
  icon: exp_pattern_provider
  position: 0
categories:
  - expandedae
item_ids:
  - expandedae:exp_pattern_provider
  - expandedae:exp_pattern_provider_part
---

# Расширенный поставщик шаблонов

<GameScene zoom="4" background="transparent">
  <ImportStructure src="structures/exp_pp.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

### Расширенный поставщик шаблонов — увеличенная версия обычного поставщика, доступная как в виде полного блока, так и кабельной части.
### Вмещает до 72 шаблонов.
![exp_pp_screen.png](assets/exp_pp_screen.png)

## Рецепты

<Row>
  <RecipesFor id="exp_pattern_provider" />
  <RecipesFor id="exp_pattern_provider_part" />
</Row>
