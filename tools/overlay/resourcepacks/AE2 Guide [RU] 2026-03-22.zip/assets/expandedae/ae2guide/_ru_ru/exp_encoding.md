---
navigation:
  parent: expandedae-index.md
  title: Расширенный терминал кодирования шаблонов
  icon: exp_encoding_terminal
  position: 7
categories:
  - expandedae
item_ids:
- expandedae:exp_encoding_terminal
- expandedae:wireless_exp_encoding_terminal
---

<GameScene zoom="4" background="transparent">
  <ImportStructure src="structures/exp_encoding.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

## Расширенный терминал кодирования шаблонов — улучшение стандартного терминала со следующими возможностями:
 - Shift + клик при кодировании шаблона перемещает его сразу в инвентарь
 - Кнопки умножения прямо в терминале

![pattern_mult_screen.png](assets/pattern_mult_screen.png)
