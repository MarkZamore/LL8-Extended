---
navigation:
  parent: expandedae-index.md
  title: Карточки улучшений
  icon: auto_complete_card
  position: 5
categories:
  - expandedae
item_ids:
- expandedae:auto_complete_card
- expandedae:pattern_refiller_card
---

## На данный момент мод добавляет две карточки улучшений:
- **Карточка автозавершения**: улучшение для поставщиков шаблонов — автоматически отменяет задание крафта после отправки шаблона. _Примечание: не работает с шаблонами крафта, будьте осторожны._
<ItemImage id="auto_complete_card" />
- **Карточка пополнения шаблонов**: улучшение для <ItemLink id="wireless_exp_encoding_terminal" /> и <ItemLink id="ae2wtlib:wireless_universal_terminal" />, автоматически пополняющее слот пустых шаблонов в расширенном терминале кодирования.

_Примечание: карточка проверяет необходимость пополнения только при нажатии кнопки кодирования — это наиболее экономное решение по ресурсам._
<ItemImage id="pattern_refiller_card" />
