---
navigation:
  title: "Дополнение: ExpandedAE"
  position: 150
---

# ExpandedAE

<GameScene zoom="4" background="transparent">
  <ImportStructure src="structures/expandedae.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

Дополнение к [*Applied Energistics 2*](https://github.com/AppliedEnergistics/Applied-Energistics-2), расширяющее мод и возвращающее удобные возможности из старых версий AE2.
